%% Pulmonary
clear; close all

% gradient-free
load('/PulmonaryModel/InferenceErrors_GradientFree.mat')

Errors_GF = ErrorSimSpace(1:300,:);

figure(100);clf(100)
tiledlayout(1,3, "TileSpacing", "compact");
%
nexttile
plot(ErrorSimSpace(:,2),ErrorSimSpace(:,3),'.');hold on;plot(ErrorSimSpace(:,2),ErrorSimSpace(:,2),'-r')
xlim([0 2.5]); ylim([0 2.5])
xlabel('HF');ylabel('LF')
sgtitle('Gradient-free (Pulmonary)')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,2),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 1]); ylim([0 1])
xlabel('MF');ylabel('HF')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,3),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 3.5]); ylim([0 3.5])
xlabel('MF');ylabel('LF')
set(gca,'fontsize',12)
%
%
figure(101);clf(101)
tiledlayout(1,3, "TileSpacing", "compact");
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 3]); ylim([0,160])
set(gca,'fontsize',12)
xlabel('MF');ylabel('OF')
sgtitle('Gradient-free (Pulmonary)')
%
nexttile
plot(ErrorSimSpace(:,2),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,2),ErrorSimSpace(:,2),'-r')
xlim([0,1.4]); ylim([0,160])
xlabel('HF');ylabel('OF')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,3),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,3),ErrorSimSpace(:,3),'-r')
xlim([0 6]); ylim([0 120])
xlabel('LF');ylabel('OF')
set(gca,'fontsize',12)

%
clearvars -except Errors_GF
% gradient-based
load('/PulmonaryModel/InferenceErrors_GradientBased.mat')

Errors_GB = ErrorSimSpace(1:300,:);

figure(1000);clf(1000)
tiledlayout(1,3, "TileSpacing", "compact"); % a 2x2 plot: first col is GPs, second col is PCE
%
nexttile
plot(ErrorSimSpace(:,2),ErrorSimSpace(:,3),'.');hold on;plot(ErrorSimSpace(:,2),ErrorSimSpace(:,2),'-r')
xlim([0 7]); ylim([0 7])
xlabel('HF');ylabel('LF')
sgtitle('Gradient-based (Pulmonary)')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,2),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 2]); ylim([0 2])
xlabel('MF');ylabel('HF')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,3),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 3.5]); ylim([0 3.5])
xlabel('MF');ylabel('LF')
set(gca,'fontsize',12)
%
%
figure(1001);clf(1001)
tiledlayout(1,3, "TileSpacing", "compact"); % a 2x2 plot: first col is GPs, second col is PCE
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 3]); ylim([0,100])
xlabel('MF');ylabel('OF')
set(gca,'fontsize',12)
sgtitle('Gradient-based (Pulmonary)')
%
nexttile
plot(ErrorSimSpace(:,2),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,2),ErrorSimSpace(:,2),'-r')
xlim([0,10]); ylim([0,100])
xlabel('HF');ylabel('OF')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,3),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,3),ErrorSimSpace(:,3),'-r')
xlim([0 20]); ylim([0 100])
xlabel('LF');ylabel('OF')
set(gca,'fontsize',12)
%
%
%
%%%% Plot Errors_GB against Errors_GF to show the former larger than the latter (for HF and LF)
figure(11);clf(11)
tiledlayout(2,3, "TileSpacing", "compact"); % a 2x2 plot: first col is GPs, second col is PCE
%
subplot(2,3,4)
plot(Errors_GF(:,2),Errors_GB(:,2),'.');hold on;plot(Errors_GF(:,2),Errors_GF(:,2),'-r')
xlim([0 5]); ylim([0 5])
xlabel('gradient-free');ylabel('gradient-based')
if nd==5
    title('HF (Systemic)')
else
    title('HF (Pulmonary)')
end
set(gca,'fontsize',12)
%
subplot(2,3,5)
plot(Errors_GF(:,3),Errors_GB(:,3),'.');hold on;plot(Errors_GF(:,3),Errors_GF(:,3),'-r')
xlim([0 5]); ylim([0 5])
xlabel('gradient-free');ylabel('gradient-based')
if nd==5
    title('LF (Systemic)')
else
    title('LF (Pulmonary)')
end
set(gca,'fontsize',12)
%
subplot(2,3,6)
plot(Errors_GF(:,4),Errors_GB(:,4),'.');hold on;plot(Errors_GF(:,4),Errors_GF(:,4),'-r')
xlim([0 50]); ylim([0 50])
xlabel('gradient-free');ylabel('gradient-based')
if nd==5
    title('OF (Systemic)')
else
    title('OF (Pulmonary)')
end
set(gca,'fontsize',12)

%% Systemic
clear;
% gradient-based
load('/SystemicModel/InferenceErrors_GradientBased.mat')

Errors_GB = ErrorSimSpace(1:300,:);

figure(1);clf(1)
tiledlayout(1,3, "TileSpacing", "compact"); % a 2x2 plot: first col is GPs, second col is PCE
%
nexttile
plot(ErrorSimSpace(:,2),ErrorSimSpace(:,3),'.');hold on;plot(ErrorSimSpace(:,2),ErrorSimSpace(:,2),'-r')
xlim([0 20]); ylim([0 20])
xlabel('HF');ylabel('LF')
sgtitle('Gradient-based (Systemic)')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,2),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 20]); ylim([0 20])
xlabel('MF');ylabel('HF')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,3),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 20]); ylim([0 20])
xlabel('MF');ylabel('LF')
set(gca,'fontsize',12)
%
%
figure(2);clf(2)
tiledlayout(1,3, "TileSpacing", "compact"); % a 2x2 plot: first col is GPs, second col is PCE
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 30]); ylim([0,50])
set(gca,'fontsize',12)
xlabel('MF');ylabel('OF')
sgtitle('Gradient-based (Systemic)')
%
nexttile
plot(ErrorSimSpace(:,2),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,2),ErrorSimSpace(:,2),'-r')
xlim([0,30]); ylim([0,50])
xlabel('HF');ylabel('OF')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,3),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,3),ErrorSimSpace(:,3),'-r')
xlim([0 30]); ylim([0 50])
xlabel('LF');ylabel('OF')
set(gca,'fontsize',12)

%
clearvars -except Errors_GB
% gradient-free
load('/SystemicModel/InferenceErrors_GradientFree.mat')

Errors_GF = ErrorSimSpace(1:300,:);

figure(10);clf(10)
tiledlayout(1,3, "TileSpacing", "compact"); % a 2x2 plot: first col is GPs, second col is PCE
%
nexttile
plot(ErrorSimSpace(:,2),ErrorSimSpace(:,3),'.');hold on;plot(ErrorSimSpace(:,2),ErrorSimSpace(:,2),'-r')
xlim([0 20]); ylim([0 20])
xlabel('HF');ylabel('LF')
sgtitle('Gradient-free (Systemic)')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,2),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 10]); ylim([0 10])
xlabel('MF');ylabel('HF')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,3),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 20]); ylim([0 20])
xlabel('MF');ylabel('LF')
set(gca,'fontsize',12)
%
%
figure(11);clf(11)
tiledlayout(1,3, "TileSpacing", "compact"); % a 2x2 plot: first col is GPs, second col is PCE
%
nexttile
plot(ErrorSimSpace(:,1),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,1),ErrorSimSpace(:,1),'-r')
xlim([0 20]); ylim([0,50])
xlabel('MF');ylabel('OF')
set(gca,'fontsize',12)
sgtitle('Gradient-free (Systemic)')
%
nexttile
plot(ErrorSimSpace(:,2),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,2),ErrorSimSpace(:,2),'-r')
xlim([0,20]); ylim([0,50])
xlabel('HF');ylabel('OF')
set(gca,'fontsize',12)
%
nexttile
plot(ErrorSimSpace(:,3),ErrorSimSpace(:,4),'.');hold on;plot(ErrorSimSpace(:,3),ErrorSimSpace(:,3),'-r')
xlim([0,20]); ylim([0,50])
xlabel('LF');ylabel('OF')
set(gca,'fontsize',12)
%
%
%
%%%% Plot Errors_GB against Errors_GF to show the former larger than the latter (for HF and LF)
figure(11);hold on
%
subplot(2,3,1)
plot(Errors_GF(:,2),Errors_GB(:,2),'.');hold on;plot(Errors_GF(:,2),Errors_GF(:,2),'-r')
xlim([0 10]); ylim([0 10])
xlabel('gradient-free');ylabel('gradient-based')
if nd==5
    title('HF (Systemic)')
else
    title('HF (Pulmonary)')
end
set(gca,'fontsize',12)
%
subplot(2,3,2)
plot(Errors_GF(:,3),Errors_GB(:,3),'.');hold on;plot(Errors_GF(:,3),Errors_GF(:,3),'-r')
xlim([0 30]); ylim([0 30])
xlabel('gradient-free');ylabel('gradient-based')
if nd==5
    title('LF (Systemic)')
else
    title('LF (Pulmonary)')
end
set(gca,'fontsize',12)
%
subplot(2,3,3)
plot(Errors_GF(:,4),Errors_GB(:,4),'.');hold on;plot(Errors_GF(:,4),Errors_GF(:,4),'-r')
xlim([0 50]); ylim([0 50])
xlabel('gradient-free');ylabel('gradient-based')
if nd==5
    title('OF (Systemic)')
else
    title('OF (Pulmonary)')
end
set(gca,'fontsize',12)