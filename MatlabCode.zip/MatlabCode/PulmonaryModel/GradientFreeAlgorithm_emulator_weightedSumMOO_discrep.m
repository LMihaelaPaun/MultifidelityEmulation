function OptimHistory = GradientFreeAlgorithm_emulator_weightedSumMOO_discrep(param0, truePressure, extra_p)
% this is a gradient-free optimiser (original form), only works for HF or
% LF emulators, not multifidelity

gp_regr_pressure = extra_p{1};
x_regr = extra_p{2};
y_regr_pressure = extra_p{3};
NC_pressure_fid = extra_p{4};
coeff_pressure = extra_p{5};
mu_pressure = extra_p{6};
mean_y_pressure = extra_p{7};
std_y_pressure = extra_p{8};
switchEm = extra_p{9};
HF = extra_p{10};
mdl = extra_p{11};
l = extra_p{12};
u = extra_p{13};
sc = extra_p{14};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient-free
   
% gradient-free optimiser
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-6, 'TolX',1e-6);

[x,fval] = fminsearchbnd(@(x)GetObjFct(x), param0, l./sc, u./sc, options);

    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
                
        if switchEm ~= 1 % we do not do switching based on KNN prediction, only HF or LF

            if HF==1 % HF
                NC = NC_pressure_fid(2); %HF
            else % LF
                NC = NC_pressure_fid(1); %LF
            end
            
            E = NaN(size(param,1), NC);
            
            for i=1:NC
                % Make predictions of every PC score using gp models
                
                E(:,i) = gp_pred(gp_regr_pressure{i}, x_regr, y_regr_pressure(:,i), param);
            end
            
            pressure = (E.*std_y_pressure(1:NC)+mean_y_pressure(1:NC)) * coeff_pressure(:,1:NC)' + mu_pressure;
            
            r_pressure = truePressure - pressure;
            
            % RSS
            ObjFct = sum(r_pressure.^2,2);
            
        end
    end

end