function [ObjFct,pressure] = GetRSS_1signal(param, truePressure, extra_p, GP_type)

% GP_type --> 1:GP-time; 2:GP-PCA

if GP_type==1
    
    gp_pressure = extra_p{1};
    gp1_pressure = extra_p{2};
    gp2_pressure = extra_p{3};
    
    input_train = extra_p{4};
    x1 = extra_p{5};
    x2 = extra_p{6};
    outputPressure_train = extra_p{7};
    mean_y_pressure = extra_p{8};
    std_y_pressure = extra_p{9};
    ntp = extra_p{10};
    
    % Get objective function
    nd = size(param,2);
    input_test = NaN(ntp,nd+1);
    count=0;
    for j=1:ntp
        count=count+1;
        input_test(count,:) = [param x2(j)];
    end
    
    %
    E = gp_pred(gp_pressure, input_train, outputPressure_train, ...
        gp1_pressure, gp2_pressure, x1, x2, input_test);
    
    pressure = E.*std_y_pressure+mean_y_pressure;
    
else %GP-PCA
    
    gp_regr_pressure = extra_p{1};
    x_regr = extra_p{2};
    y_regr_pressure = extra_p{3};
    NC_pressure = extra_p{4};
    coeff_pressure = extra_p{5};
    mu_pressure = extra_p{6};
    mean_y_pressure = extra_p{7};
    std_y_pressure = extra_p{8};
    
    E = NaN(size(param,1), NC_pressure);
    
    for i=1:NC_pressure
        % Make predictions of every PC score using gp models
        
        E(:,i) = gp_pred(gp_regr_pressure{i}, x_regr, y_regr_pressure(:,i), param);
    end
    
    pressure = (E.*std_y_pressure+mean_y_pressure) * coeff_pressure(:,1:NC_pressure)' + mu_pressure;
    
end

r_pressure = truePressure - pressure;

% RSS
ObjFct = sum(r_pressure.^2,2);

end
