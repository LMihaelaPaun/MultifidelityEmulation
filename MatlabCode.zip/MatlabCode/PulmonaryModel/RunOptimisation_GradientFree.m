% main script to run optimisation with a gradient-free algorithm for 4 emulators:
% multifidelity, high-fidelity, low-fidelity and objective function

clear; close all

% add path to the original GPstuff toolbox
addpath(genpath('/GPstuff-4.7'))

addpath('/CommonFunctions')

%% Set some quantities

ntp = 512; % no of time points in the multivariate output

num_ves = 27;   % Number of large vessels in the tree

art     = 1:15; % Arteries
ven     = 16:27;% Veins

%% generate fs(thetaStar): the data
% Generate true data: 300 data sets

nd = 4;

X = sobolset(nd, 'Skip',2e13,'Leap',0.3e14);

nDS = size(X,1);

thetaStar = NaN(nDS,nd);

l = [9e4 0.83 20 20];
u = [3e5 0.89 50 50];

sc = max(abs(l),abs(u));

for i=1:nd
    thetaStar(:,i) = l(i) + (u(i)-l(i)) * X(1:nDS,i);
end

delete(gcp('nocreate'))
parpool('local', 48)

SimPressure_thetaStar = NaN(nDS,ntp);

% generate the inference data sets
parfor iDS=1:nDS
    
    file_id = iDS;
    
    clean_pressureData = Run_fluidsModel(thetaStar(iDS,:), file_id, num_ves, art, ven, ntp);
    
    SimPressure_thetaStar(iDS,:) = clean_pressureData;
    
end

%% Load data covering whole space (10000 points), theta and fs(theta) to construct classifier

load('/SignalsForEmulator_10000s_4D.mat')

theta=x;

nTheta = n;

% this is fs(theta), covering the whole domain to obtain OF for theta:
% nTheta values in this case
SimPressure_theta = NaN(nTheta,ntp);
for j=1:nTheta
    SimPressure_theta(j,:) = clean_pressure{j};
end


ErrorSimSpace = NaN(nDS,4);
ErrorParSpace = NaN(nDS,4);

PercGoodCases = NaN(nDS,1);
KNNcorrectClassifRate = NaN(nDS,1);

for iDS=1:nDS
    
    %% Get RSS_sim
    
    RSS_sim = NaN(nTheta,1);
    
    for j=1:nTheta
        % residuals
        r_press = (SimPressure_thetaStar(iDS,:) - SimPressure_theta(j,:));
        
        % RSS
        RSS_sim(j) = sum(r_press.^2, 'all');
        
    end
    
    % Now build emulator for objective function
    x_regrRSS = theta(1:1000,:)./sc; % the same 1000 training points as emulators for LF and HF models
    
    mean_yRSS = mean(RSS_sim(1:1000));
    std_yRSS = std(RSS_sim(1:1000));
    
    % Scale y_regr
    y_regrRSS = (RSS_sim(1:1000)-mean_yRSS)./std_yRSS; % mean 0 and std 1 of of y
    
    % Fit GP
    gp_regrRSS = GPmodel(x_regrRSS, y_regrRSS, [1 0.1*ones(1,nd) 1e-04]);
    
    %     E = gp_pred(gp_regrRSS, x_regrRSS, y_regrRSS, x_regrRSS);
    % figure;hold on;plot(E,y_regrRSS,'.');plot(E,E,'-r')
    %
    % x_regrRSS_test = theta(1001:end,:)./sc;
    % y_regrRSS_test = (RSS_sim(1001:end)-mean_yRSS)./std_yRSS;
    %
    % E = gp_pred(gp_regrRSS, x_regrRSS, y_regrRSS, x_regrRSS_test);
    % figure;hold on;plot(E,y_regrRSS_test,'.');plot(E,E,'-r')
    
    %% Get RSS_em
    
    RSS_em = NaN(2,nTheta);
    EmPressure_theta = cell(2,1);
    
    for emulatorAccuracyIdx = 1:2 % 1: LF, 2: HF
        
        % load emulators (obtained by running FitFidelityEmulators_GP_PCA.m)
        if emulatorAccuracyIdx == 1
            load('GP_PCA_Emulator_LF_4D.mat')
        else
            load('GP_PCA_Emulator_HF_4D.mat')
        end
        %     end
        
        GP_type = 2; % GP-PCA
        
        extra_p = {gp_regr_pressure,x_regr,y_regr_pressure,NC_pressure,...
            coeff_pressure,mu_pressure,mean_y_pressure,std_y_pressure};
        
        % Get RSS values for emulator
        [RSS_em(emulatorAccuracyIdx,:),EmPressure_theta{emulatorAccuracyIdx}] = ...
            GetRSS_1signal(theta./sc, SimPressure_thetaStar(iDS,:), extra_p, GP_type);
        
    end
    
    %% Get RSS_diff
    
    RSS_diff = NaN(2,nTheta);
    
    for emAccIdx=1:2
        RSS_diff(emAccIdx,:) = abs(RSS_sim'-RSS_em(emAccIdx,:));
    end
    
    RSS_diff = log(RSS_diff);
    
    
    
    %% Next use a classifier to learn the labels (1:HF, 0:LF) which gives which fidelity emulator we should use:
    %(HF emulator or LF). The classifier will predict the label for unseen
    %(test) parameter values, which is essential in inference, where we
    % wouldn't call simulator for new parameter values
    % possible classifiers: k-nearest neighbours (KNN), GPs, support vector machine (SVM)
    
    % K-nearest neighbours (KNN)
    
    % x_class: 5D parameter set
    k=100;
    
    x_class = theta(1:nTheta-k,:);
    
    x_class_test = theta(nTheta-k+1:end,:);
    
    % y_class: binary data
    y_class = zeros(nTheta-k,1);
    y_class(RSS_diff(1,1:nTheta-k)>RSS_diff(2,1:nTheta-k)) = 1; % cases when |OF_sim-OF_LF|>|OF_sim-OF_HF|, as desired (good instances)
    
    PercGoodCases(iDS) = sum(y_class)/(nTheta-k);
    
    y_class_test = zeros(k,1);
    y_class_test(RSS_diff(1,nTheta-k+1:end)>RSS_diff(2,nTheta-k+1:end)) = 1; % cases when |OF_sim-OF_LF|>|OF_sim-OF_HF|, as desired (good instances)
    
    % predict labels for test data
    nNeigh = 5; %
    
    mdl = fitcknn(x_class,y_class,'NumNeighbors',nNeigh,'Standardize',1,...
        'Distance','mahalanobis');
    label = predict(mdl,x_class_test);
    
    % compare prediction to actual label
    %     figure(20);clf(20);plot(1:k,label-y_class_test,'.r'); %should be all zero if label correctly predicted
    KNNcorrectClassifRate(iDS) = numel(find((label-y_class_test)==0))/k; % correct classification rate
    
    %% Next run optimisation
    
    NC_pressure_fid = [2,5]; %LF model: 2 PCs, HF model: 5 PCs
    
    truePressure = SimPressure_thetaStar(iDS,:);
    
    % different initialisations
    Xinit = sobolset(nd, 'Skip',2e12,'Leap',0.183e15);
    
    ninit = size(Xinit,1);
    
    par0 = NaN(ninit,nd);
    
    for i=1:nd
        par0(:,i) = l(i) + (u(i)-l(i)) * Xinit(1:ninit,i);
    end
    
    % compare to true theta
    WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));
    
    % Switching emulators?
    for switchEm = 1:2; % 1: switch between LF and HF emulators based on KNN classifier, 2: do not switch, use HF emulator only
        
        if switchEm==1
            
            HF = NaN;
            
            extra_p = {gp_regr_pressure,x_regr,y_regr_pressure,NC_pressure_fid,coeff_pressure,mu_pressure,...
                mean_y_pressure,std_y_pressure,switchEm,HF,mdl,l,u,sc};
            
            parfor i = 1:48%ninit
                % algorithm adapted for multifidelity inference
                history(i) = GradientFreeAlgorithm_emulator_weightedSumMOO_discrepTEST(par0(i,:)./sc, truePressure, extra_p);
            end
            
            
        else
            
            HF = 1;
            
            extra_p = {gp_regr_pressure,x_regr,y_regr_pressure,NC_pressure_fid,coeff_pressure,mu_pressure,...
                mean_y_pressure,std_y_pressure,switchEm,HF,mdl,l,u,sc};
            
            parfor i = 1:48%ninit
                % original algorithm
                history(i) = GradientFreeAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, truePressure, extra_p);
            end
            
        end
        
        
        
        parfor i=1:48
            
            clean_pressureData = Run_fluidsModel(history(i).x(end,:) .*sc, 1000+iDS+i, num_ves, art, ven, ntp);
            
            PressureALL{i} = clean_pressureData; % first pressure only;
            
            OFALL(i) = sum((truePressure-(PressureALL{i})').^2);
            
        end
        
        Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
        FinalXvalue = history(Idx).x(end,:) .*sc;
        
        if switchEm==1
            FinalXvalue_switch = FinalXvalue; FinalYvalue_switch = min(OFALL);
        else
            FinalXvalue_HF = FinalXvalue; FinalYvalue_HF = min(OFALL);
        end
        
        ErrorSimSpace(iDS,switchEm) = OFALL(Idx);
        ErrorParSpace(iDS,switchEm) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);
    end
    
    % Now also run for LF model
    switchEm = 2; % do not switch between emulators
    HF = 0; % use LF
    % update extra_p
    extra_p = {gp_regr_pressure,x_regr,y_regr_pressure,NC_pressure_fid,coeff_pressure,mu_pressure,...
        mean_y_pressure,std_y_pressure,switchEm,HF,mdl,l,u,sc};
    
    parfor i = 1:48%ninit
        history(i) = GradientFreeAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, truePressure, extra_p);
    end
    
    parfor i=1:48
        
        clean_pressureData = Run_fluidsModel(history(i).x(end,:) .*sc, 1000+iDS+i, num_ves, art, ven, ntp);
        
        PressureALL{i} = clean_pressureData; % first pressure only;
        
        OFALL(i) = sum((truePressure-(PressureALL{i})').^2);
        
    end
    
    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;
    
    FinalXvalue_LF = FinalXvalue; FinalYvalue_LF = min(OFALL);
    
    ErrorSimSpace(iDS,3) = OFALL(Idx);
    ErrorParSpace(iDS,3) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);
    
    % Next also run for direct emulator of OF
    extra_pOF = {gp_regrRSS,x_regrRSS,y_regrRSS,mean_yRSS,std_yRSS,l,u,sc};
    
    parfor i = 1:48
        history(i) = GradientFreeAlgorithm_emulator_OFonly(par0(i,:)./sc, extra_pOF);
    end
    
    parfor i=1:48
        
        clean_pressureData = Run_fluidsModel(history(i).x(end,:) .*sc, 1000+iDS+i, num_ves, art, ven, ntp);
        
        PressureALL{i} = clean_pressureData; % first pressure only;
        
        OFALL(i) = sum((truePressure-(PressureALL{i})').^2);
        
    end
    
    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;
    
    FinalXvalue_OF = FinalXvalue; FinalYvalue_OF = min(OFALL);
    
    ErrorSimSpace(iDS,4) = OFALL(Idx);
    ErrorParSpace(iDS,4) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);
    
    % MF: ErrorSimSpace(iDS,1)
    % HF: ErrorSimSpace(iDS,2)
    % LF: ErrorSimSpace(iDS,3)
    % OF: ErrorSimSpace(iDS,4)
    
end
