function CppSettings()
%% Define the connectivity matrix


% Converging full network
writeconn  	 = [0 1 2 0
                1 3 4 0
                2 0 0 0
                3 5 6 0
                4 0 0 0
                5 7 8 0
                6 0 0 0 
                7 0 0 0
                8 0 0 0];
            
terminal 	 = [2 4 6 7 8];




% Write all this information to file. We subtract one to keep up with C++
% indexing. 
dlmwrite('connectivity.txt',writeconn,'\t');
dlmwrite('terminal_vessels.txt',terminal,'\t');

end

