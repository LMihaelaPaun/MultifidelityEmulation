% main script to run optimisation with a gradient-based algorithm for 3 emulators:
% high-fidelity, low-fidelity and objective function, and a gradient-free
% optimiser for the multifidelity emulator

clear; close all

% add path to the original GPstuff toolbox
addpath(genpath('/GPstuff-4.7'))

addpath('/CommonFunctions')

%% Generate inference data
% Run code (once only!) to obtain txt files to be used by the C++ code
CppSettings()

% Set some quantities

% no of time points in the time series
ntp = 512;

% no of vessels we use data for inference from
nv = 9;

nd = 5; % no of parameters

% Generate 300 data sets

X = sobolset(nd, 'Skip',2e13,'Leap',0.3e14);

nDS = size(X,1);

thetaStar = NaN(nDS,nd);

l = [-45 2*10^5 -45 2*10^5 0.85];
u = [-25 9*10^5 -25 9*10^5 0.94];

for i=1:nd
    thetaStar(:,i) = l(i) + (u(i)-l(i)) * X(1:nDS,i);
end

delete(gcp('nocreate'))
parpool('local', 48)

SimFlow_thetaStar = NaN(nDS,ntp);

parfor iDS=1:nDS
    
    file_id = iDS;
    
    [clean_pressureData, clean_flowData] = Run_fluidsModel(thetaStar(iDS,:), file_id, nv, ntp);
    
    SimFlow_thetaStar(iDS,:) = clean_flowData(:,1); % first flow only;
    
end

%% Load data covering whole space (10000 points), theta and fs(theta)
% useful to build classifier

load('/SignalsForEmulator_10000s_5D.mat')
theta=x;

nTheta = n;

SimFlow_theta = NaN(nTheta,ntp);
for j=1:nTheta
    SimFlow_theta(j,:) = clean_flow{j}(:,1);% use only first flow
end


ErrorSimSpace = NaN(nDS,4);
ErrorParSpace = NaN(nDS,4);

PercGoodCases = NaN(nDS,1);
KNNcorrectClassifRate = NaN(nDS,1);

parpool('local', 48)

for iDS=1:nDS
    
    %% Get RSS_sim
    
    RSS_sim = NaN(nTheta,1);
    
    for j=1:nTheta
        % residuals
        r_flow = (SimFlow_thetaStar(iDS,:) - SimFlow_theta(j,:));
        
        % RSS
        RSS_sim(j) = sum(r_flow.^2, 'all');
        
    end
    
    % Now build emulator for objective function
    x_regrRSS = theta(1:1000,:)./sc; % the same 1000 training points as emulators for LF and HF models
    
    mean_yRSS = mean(RSS_sim(1:1000));
    std_yRSS = std(RSS_sim(1:1000));
    
    % Scale y_regr
    y_regrRSS = (RSS_sim(1:1000)-mean_yRSS)./std_yRSS; % mean 0 and std 1 of of y
    
    % Fit GP
    gp_regrRSS = GPmodel(x_regrRSS, y_regrRSS, H_r(2,:));
    
    
    %% Get RSS_em
    
    RSS_em = NaN(2,nTheta);
    EmFlow_theta = cell(2,1);
    
    for emulatorAccuracyIdx = 1:2 % 1: LF, 2: HF
        
        % load emulators (obtained by running FitFidelityEmulators_GP_PCA.m)
        if emulatorAccuracyIdx == 1
            load('GP_PCA_Emulator_LF_5D.mat')
        else
            load('GP_PCA_Emulator_HF_5D.mat')
        end
        %     end
        
        GP_type = 2; % GP-PCA
        
        extra_p = {gp_regr_flow,x_regr,y_regr_flow,NC_flow,coeff_flow,mu_flow,mean_y_flow,std_y_flow};
        
        % Get RSS values for emulator
        [RSS_em(emulatorAccuracyIdx,:),EmFlow_theta{emulatorAccuracyIdx}] = ...
            GetRSS_1signal(theta./sc, SimFlow_thetaStar(iDS,:), extra_p, GP_type);
        
    end
    
    %% Get RSS_diff
    
    RSS_diff = NaN(2,nTheta);
    
    for emAccIdx=1:2
        RSS_diff(emAccIdx,:) = abs(RSS_sim'-RSS_em(emAccIdx,:));
    end
    
    RSS_diff = log(RSS_diff);
    
    
    %% Next use a classifier to learn the labels (1:HF, 0:LF) which gives which fidelity emulator we should use:
    %(HF emulator or LF). The classifier will predict the label for unseen
    %(test) parameter values, which is essential in inference, where we
    % wouldn't call simulator for new parameter values
    % possible classifiers: k-nearest neighbours (KNN), GPs, support vector machine (SVM)
    
    % K-nearest neighbours (KNN)
    
    % x_class: 5D parameter set
    k=100;
    
    x_class = theta(1:nTheta-k,:);
    
    x_class_test = theta(nTheta-k+1:end,:);
    
    % y_class: binary data
    y_class = zeros(nTheta-k,1);
    y_class(RSS_diff(1,1:nTheta-k)>RSS_diff(2,1:nTheta-k)) = 1; % cases when |OF_sim-OF_LF|>|OF_sim-OF_HF|, as desired (good instances)
    
    PercGoodCases(iDS) = sum(y_class)/(nTheta-k);
    
    y_class_test = zeros(k,1);
    y_class_test(RSS_diff(1,nTheta-k+1:end)>RSS_diff(2,nTheta-k+1:end)) = 1; % cases when |OF_sim-OF_LF|>|OF_sim-OF_HF|, as desired (good instances)
    
    % predict labels for test data
    nNeigh = 5;
    
    mdl = fitcknn(x_class,y_class,'NumNeighbors',nNeigh,'Standardize',1,...
        'Distance','mahalanobis');
    label = predict(mdl,x_class_test);
    
    % compare prediction to actual label
    % figure(20);clf(20);plot(1:nTheta,label-Y,'.r'); %should be all zero if label correctly predicted
    KNNcorrectClassifRate(iDS) = numel(find((label-y_class_test)==0))/k;
    
    %% Next run optimisation
    
    NC_flow_fid = [2,5];% LF model: 2 PCs, HF model: 5 PCs
    
    trueFlow = SimFlow_thetaStar(iDS,:);
    
    % different initialisations
    Xinit = sobolset(nd, 'Skip',2e12,'Leap',0.183e15);
    
    ninit = size(Xinit,1);
    
    par0 = NaN(ninit,nd);
    
    for i=1:nd
        par0(:,i) = l(i) + (u(i)-l(i)) * Xinit(1:ninit,i);
    end
    
    % compare to true theta
    WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));
    
    % Switching emulators?
    for switchEm = 1:2; % 1: switch between LF and HF emulators based on KNN classifier, 2: do not switch, use HF emulator only
        
        if switchEm==1
            
            HF = NaN;
            
            extra_p = {gp_regr_flow,x_regr,y_regr_flow,NC_flow_fid,coeff_flow,mu_flow,...
                mean_y_flow,std_y_flow,switchEm,HF,mdl,l,u,sc};
            
            parfor i = 1:48%ninit
                % algorithm adapted for multifidelity inference
                history(i) = GradientFreeAlgorithm_emulator_weightedSumMOO_discrepTEST(par0(i,:)./sc, trueFlow, extra_p);
            end
            
        else
            HF = 1;   
            
            extra_p = {gp_regr_flow,x_regr,y_regr_flow,NC_flow_fid,coeff_flow,mu_flow,...
                mean_y_flow,std_y_flow,switchEm,HF,mdl,l,u,sc};
            
            parfor i = 1:48%ninit
                history(i) = GradientAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, trueFlow, extra_p);
            end
            
        end
        
        parfor i=1:48
            
            [~, clean_flowData] = Run_fluidsModel(history(i).x(end,:) .*sc, iDS+i, nv, ntp);
            
            FlowALL{i} = clean_flowData(:,1); % first flow only;
            
            OFALL(i) = sum((trueFlow-(FlowALL{i})').^2);
            
        end
        
        Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
        FinalXvalue = history(Idx).x(end,:) .*sc;
        
        if switchEm==1
            FinalXvalue_switch = FinalXvalue; FinalYvalue_switch = min(OFALL);
        else
            FinalXvalue_HF = FinalXvalue; FinalYvalue_HF = min(OFALL);
        end
        
        ErrorSimSpace(iDS,switchEm) = OFALL(Idx);
        ErrorParSpace(iDS,switchEm) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);
    end
    
    % Now also run for LF model
    switchEm = 2; % do not switch between emulators
    HF = 0; % use LF
    % update extra_p
    extra_p = {gp_regr_flow,x_regr,y_regr_flow,NC_flow_fid,coeff_flow,mu_flow,...
        mean_y_flow,std_y_flow,switchEm,HF,mdl,l,u,sc};
    
    parfor i = 1:48%ninit
        history(i) = GradientAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, trueFlow, extra_p);
    end
    
    parfor i=1:48
        
        [~, clean_flowData] = Run_fluidsModel(history(i).x(end,:) .*sc, iDS+i, nv, ntp);
        
        FlowALL{i} = clean_flowData(:,1); % first flow only;
        
        OFALL(i) = sum((trueFlow-(FlowALL{i})').^2);
        
    end
    
    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;
    
    FinalXvalue_LF = FinalXvalue; FinalYvalue_LF = min(OFALL);
    
    ErrorSimSpace(iDS,3) = OFALL(Idx);
    ErrorParSpace(iDS,3) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);
    
    % Next also run for direct emulator of OF
    extra_pOF = {gp_regrRSS,x_regrRSS,y_regrRSS,mean_yRSS,std_yRSS,l,u,sc};
    
    parfor i = 1:48
        history(i) = GradientAlgorithm_emulator_OFonly(par0(i,:)./sc, extra_pOF);
    end
    
    parfor i=1:48
        
        [~, clean_flowData] = Run_fluidsModel(history(i).x(end,:) .*sc, iDS+i, nv, ntp);
        
        FlowALL{i} = clean_flowData(:,1); % first flow only;
        
        OFALL(i) = sum((trueFlow-(FlowALL{i})').^2);
        
    end
    
    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;
    
    FinalXvalue_OF = FinalXvalue; FinalYvalue_OF = min(OFALL);
    
    ErrorSimSpace(iDS,4) = OFALL(Idx);
    ErrorParSpace(iDS,4) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);
    
    % MF: ErrorSimSpace(iDS,1)
    % HF: ErrorSimSpace(iDS,2)
    % LF: ErrorSimSpace(iDS,3)
    % OF: ErrorSimSpace(iDS,4)
    
end
