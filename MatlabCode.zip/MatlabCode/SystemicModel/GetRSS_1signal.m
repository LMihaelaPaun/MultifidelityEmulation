function [ObjFct,flow] = GetRSS_1signal(param, trueFlow, extra_p, GP_type)

% GP_type --> 1:GP-time; 2:GP-PCA

if GP_type==1
    
    gp_flow = extra_p{1};
    gp1_flow = extra_p{2};
    gp2_flow = extra_p{3};
    
    input_train = extra_p{4};
    x1 = extra_p{5};
    x2 = extra_p{6};
    outputFlow_train = extra_p{7};
    mean_y_flow = extra_p{8};
    std_y_flow = extra_p{9};
    ntp = extra_p{10};
    
    % Get objective function
    nd = size(param,2);
    input_test = NaN(ntp,nd+1);
    count=0;
    for j=1:ntp
        count=count+1;
        input_test(count,:) = [param x2(j)];
    end
    
    %
    E = gp_pred(gp_flow, input_train, outputFlow_train, ...
        gp1_flow, gp2_flow, x1, x2, input_test);
    
    flow = E.*std_y_flow+mean_y_flow;
    
else %GP-PCA
    
    gp_regr_flow = extra_p{1};
    x_regr = extra_p{2};
    y_regr_flow = extra_p{3};
    NC_flow = extra_p{4};
    coeff_flow = extra_p{5};
    mu_flow = extra_p{6};
    mean_y_flow = extra_p{7};
    std_y_flow = extra_p{8};
    
    E = NaN(size(param,1), NC_flow);
    
    for i=1:NC_flow
        % Make predictions of every PC score using gp models
        
        E(:,i) = gp_pred(gp_regr_flow{i}, x_regr, y_regr_flow(:,i), param);
    end
    
    flow = (E.*std_y_flow+mean_y_flow) * coeff_flow(:,1:NC_flow)' + mu_flow;
    
end

r_flow = trueFlow - flow;

% RSS
ObjFct = sum(r_flow.^2,2);

end
