function OptimHistory = GradientFreeAlgorithm_emulator_weightedSumMOO_discrepTEST(param0, trueFlow, extra_p)
% this is a gradient-free optimiser that is adapted for multifidelity
% inference

gp_regr_flow = extra_p{1};
x_regr = extra_p{2};
y_regr_flow = extra_p{3};
NC_flow_fid = extra_p{4};
coeff_flow = extra_p{5};
mu_flow = extra_p{6};
mean_y_flow = extra_p{7};
std_y_flow = extra_p{8};
switchEm = extra_p{9};
HF = extra_p{10};
mdl = extra_p{11};
l = extra_p{12};
u = extra_p{13};
sc = extra_p{14};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient based method (sqp algorithm) or gradient-free

if switchEm == 1 % we do switching based on KNN prediction
    
    % gradient-free optimiser
    options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-6, 'TolX',1e-6);
    
    [x,fval] = fminsearchbndTEST(@(x)GetObjFct(x), param0, l./sc, u./sc, options);
    
end


    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
        
        if switchEm == 1 % we do switching based on KNN prediction
            
            ObjFctEach = NaN(2,1);
            
            for iNC=1:2 % 1: LF, 2: HF
                
                NC = NC_flow_fid(iNC);
                
                E = NaN(size(param,1), NC);
                
                for i=1:NC
                    % Make predictions of every PC score using gp models
                    
                    E(:,i) = gp_pred(gp_regr_flow{i}, x_regr, y_regr_flow(:,i), param);
                end
                
                flow = (E.*std_y_flow(1:NC)+mean_y_flow(1:NC)) * coeff_flow(:,1:NC)' + mu_flow;
                
                r_flow = trueFlow - flow;
                
                % RSS
                ObjFctEach(iNC) = sum(r_flow.^2,2);
                
            end
            %ObjFctEach
            label = predict(mdl,param.*sc); % label=1 if HF and label=0 if LF
            
            ObjFct = [ObjFctEach(1),ObjFctEach(2),label]; % OF_LF, OF_HF, label; if label=1, choose ObjFct(label+1); if label=0, choose ObjFct(label+1), so always choose ObjFct(label+1)
            
            
        end
    end

end