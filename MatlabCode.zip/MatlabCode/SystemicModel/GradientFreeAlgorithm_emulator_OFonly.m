function OptimHistory = GradientFreeAlgorithm_emulator_OFonly(param0, extra_p)
% gradient-free optimiser for objective function emulator

gp_regrRSS = extra_p{1}; 
x_regrRSS = extra_p{2}; 
y_regrRSS = extra_p{3};
mean_yRSS = extra_p{4};
std_yRSS = extra_p{5};
l = extra_p{6};
u = extra_p{7};
sc = extra_p{8};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient free method (nelder mead algorithm)

% gradient-free optimiser
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-6, 'TolX',1e-6);

[x,fval] = fminsearchbnd(@(x)GetObjFct(x), param0, l./sc, u./sc, options);

    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
%                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
        
            % use emulator of OF
            
            E = gp_pred(gp_regrRSS, x_regrRSS, y_regrRSS, param);
        
        % RSS
        ObjFct = E.*std_yRSS+mean_yRSS;
        
        end
        
end
