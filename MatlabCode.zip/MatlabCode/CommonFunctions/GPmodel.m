function [gp_regr, nlml_regr] = GPmodel(x_regr, y_regr, H_r)
% Fit and return GP regression model to x and y

% Hyperpriors
plg = prior_logunif(); % prior for lengthscale
pms = prior_logunif(); % prior for amplitude
ps = prior_logunif(); % prior for sigma2 in the likelihood

for i = 1:size(H_r,1)
%     lik = lik_gaussian('sigma2', H_r(i,end), 'sigma2_prior', ps);
        lik = lik_gaussian('sigma2', 0, 'sigma2_prior', prior_fixed);

    % use matern 3/2
    gpcf = gpcf_matern32('lengthScale', H_r(i,2:end-1), ...
        'magnSigma2', H_r(i,1),...
        'lengthScale_prior', plg, 'magnSigma2_prior', pms);
    
    % Set a small amount of jitter to be added to the diagonal elements of the
    % covariance matrix K to avoid singularities when this is inverted
    jitter=1e-9;
    
    % Create the GP structure
    gp_regr_all{i} = gp_set('lik', lik, 'cf', gpcf, 'jitterSigma2', jitter);
    
    % Set the options for the optimization
    opt=optimset('TolFun',1e-6,'TolX',1e-6);
    
    % Optimize with the scaled conjugate gradient method
    [gp_regr_all{i}, nlml_regr(i)] = ...
        gp_optim(gp_regr_all{i},x_regr,y_regr,'opt',opt);
    
end

I = find(nlml_regr == min(nlml_regr(i)));
gp_regr = gp_regr_all{I};
disp('done')

end

