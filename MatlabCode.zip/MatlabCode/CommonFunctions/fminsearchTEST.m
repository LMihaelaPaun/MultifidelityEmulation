function [x,fval,exitflag,output] = fminsearchTEST(funfcn,x,options,varargin)
% modified to accommodate multifidelity inference

%FMINSEARCH Multidimensional unconstrained nonlinear minimization (Nelder-Mead).
%   X = FMINSEARCH(FUN,X0) starts at X0 and attempts to find a local minimizer
%   X of the function FUN.  FUN is a function handle.  FUN accepts input X and
%   returns a scalar function value F evaluated at X. X0 can be a scalar, vector
%   or matrix.
%
%   X = FMINSEARCH(FUN,X0,OPTIONS)  minimizes with the default optimization
%   parameters replaced by values in the structure OPTIONS, created
%   with the OPTIMSET function.  See OPTIMSET for details.  FMINSEARCH uses
%   these options: Display, TolX, TolFun, MaxFunEvals, MaxIter, FunValCheck,
%   PlotFcns, and OutputFcn.
%
%   X = FMINSEARCH(PROBLEM) finds the minimum for PROBLEM. PROBLEM is a
%   structure with the function FUN in PROBLEM.objective, the start point
%   in PROBLEM.x0, the options structure in PROBLEM.options, and solver
%   name 'fminsearch' in PROBLEM.solver.
%
%   [X,FVAL]= FMINSEARCH(...) returns the value of the objective function,
%   described in FUN, at X.
%
%   [X,FVAL,EXITFLAG] = FMINSEARCH(...) returns an EXITFLAG that describes
%   the exit condition. Possible values of EXITFLAG and the corresponding
%   exit conditions are
%
%    1  Maximum coordinate difference between current best point and other
%       points in simplex is less than or equal to TolX, and corresponding
%       difference in function values is less than or equal to TolFun.
%    0  Maximum number of function evaluations or iterations reached.
%   -1  Algorithm terminated by the output function.
%
%   [X,FVAL,EXITFLAG,OUTPUT] = FMINSEARCH(...) returns a structure
%   OUTPUT with the number of iterations taken in OUTPUT.iterations, the
%   number of function evaluations in OUTPUT.funcCount, the algorithm name
%   in OUTPUT.algorithm, and the exit message in OUTPUT.message.
%
%   Examples
%     FUN can be specified using @:
%        X = fminsearch(@sin,3)
%     finds a minimum of the SIN function near 3.
%     In this case, SIN is a function that returns a scalar function value
%     SIN evaluated at X.
%
%     FUN can be an anonymous function:
%        X = fminsearch(@(x) norm(x),[1;2;3])
%     returns a point near the minimizer [0;0;0].
%
%     FUN can be a parameterized function. Use an anonymous function to
%     capture the problem-dependent parameters:
%        f = @(x,c) x(1).^2+c.*x(2).^2;  % The parameterized function.
%        c = 1.5;                        % The parameter.
%        X = fminsearch(@(x) f(x,c),[0.3;1])
%
%   FMINSEARCH uses the Nelder-Mead simplex (direct search) method.
%
%   See also OPTIMSET, FMINBND, FUNCTION_HANDLE.

%   Reference: Jeffrey C. Lagarias, James A. Reeds, Margaret H. Wright,
%   Paul E. Wright, "Convergence Properties of the Nelder-Mead Simplex
%   Method in Low Dimensions", SIAM Journal of Optimization, 9(1):
%   p.112-147, 1998.

%   Copyright 1984-2018 The MathWorks, Inc.

defaultopt = struct('Display','notify','MaxIter','200*numberOfVariables',...
    'MaxFunEvals','200*numberOfVariables','TolX',1e-4,'TolFun',1e-4, ...
    'FunValCheck','off','OutputFcn',[],'PlotFcns',[]);

% If just 'defaults' passed in, return the default options in X
if nargin == 1 && nargout <= 1 && strcmpi(funfcn,'defaults')
    x = defaultopt;
    return
end

if nargin < 3, options = []; end

buildOutputStruct = nargout > 3;
% Detect problem structure input
if nargin == 1
    if isa(funfcn,'struct')
        [funfcn,x,options] = separateOptimStruct(funfcn);
    else % Single input and non-structure
        error('MATLAB:fminsearch:InputArg',...
            getString(message('MATLAB:optimfun:fminsearch:InputArg')));
    end
end

if nargin == 0
    error('MATLAB:fminsearch:NotEnoughInputs',...
        getString(message('MATLAB:optimfun:fminsearch:NotEnoughInputs')));
end


% Check for non-double inputs
if ~isa(x,'double')
    error('MATLAB:fminsearch:NonDoubleInput',...
        getString(message('MATLAB:optimfun:fminsearch:NonDoubleInput')));
end

n = numel(x);
numberOfVariables = n;

% Check that options is a struct
if ~isempty(options) && ~isa(options,'struct')
    error('MATLAB:fminsearch:ArgNotStruct',...
        getString(message('MATLAB:optimfun:commonMessages:ArgNotStruct', 3)));
end

printtype = optimget(options,'Display',defaultopt,'fast');
tolx = optimget(options,'TolX',defaultopt,'fast');
tolf = optimget(options,'TolFun',defaultopt,'fast');
maxfun = optimget(options,'MaxFunEvals',defaultopt,'fast');
maxiter = optimget(options,'MaxIter',defaultopt,'fast');
funValCheck = strcmp(optimget(options,'FunValCheck',defaultopt,'fast'),'on');

% In case the defaults were gathered from calling: optimset('fminsearch'):
if ischar(maxfun) || isstring(maxfun)
    if strcmpi(maxfun,'200*numberofvariables')
        maxfun = 200*numberOfVariables;
    else
        error('MATLAB:fminsearch:OptMaxFunEvalsNotInteger',...
            getString(message('MATLAB:optimfun:fminsearch:OptMaxFunEvalsNotInteger')));
    end
end
if ischar(maxiter) || isstring(maxiter)
    if strcmpi(maxiter,'200*numberofvariables')
        maxiter = 200*numberOfVariables;
    else
        error('MATLAB:fminsearch:OptMaxIterNotInteger',...
            getString(message('MATLAB:optimfun:fminsearch:OptMaxIterNotInteger')));
    end
end

switch printtype
    case {'notify','notify-detailed'}
        prnt = 1;
    case {'none','off'}
        prnt = 0;
    case {'iter','iter-detailed'}
        prnt = 3;
    case {'final','final-detailed'}
        prnt = 2;
    case 'simplex'
        prnt = 4;
    otherwise
        prnt = 1;
end
% Handle the output
outputfcn = optimget(options,'OutputFcn',defaultopt,'fast');
if isempty(outputfcn)
    haveoutputfcn = false;
else
    haveoutputfcn = true;
    xOutputfcn = x; % Last x passed to outputfcn; has the input x's shape
    % Parse OutputFcn which is needed to support cell array syntax for OutputFcn.
    outputfcn = createCellArrayOfFunctions(outputfcn,'OutputFcn');
end

% Handle the plot
plotfcns = optimget(options,'PlotFcns',defaultopt,'fast');
if isempty(plotfcns)
    haveplotfcn = false;
else
    haveplotfcn = true;
    xOutputfcn = x; % Last x passed to plotfcns; has the input x's shape
    % Parse PlotFcns which is needed to support cell array syntax for PlotFcns.
    plotfcns = createCellArrayOfFunctions(plotfcns,'PlotFcns');
end

header = ' Iteration   Func-count     min f(x)         Procedure';

% Convert to function handle as needed.
funfcn = fcnchk(funfcn,length(varargin));
% Add a wrapper function to check for Inf/NaN/complex values
if funValCheck
    % Add a wrapper function, CHECKFUN, to check for NaN/complex values without
    % having to change the calls that look like this:
    % f = funfcn(x,varargin{:});
    % x is the first argument to CHECKFUN, then the user's function,
    % then the elements of varargin. To accomplish this we need to add the
    % user's function to the beginning of varargin, and change funfcn to be
    % CHECKFUN.
    varargin = [{funfcn}, varargin];
    funfcn = @checkfun;
end

n = numel(x);

% Initialize parameters
rho = 1; chi = 2; psi = 0.5; sigma = 0.5;
% onesn = ones(1,n);
% two2np1 = 2:n+1;
% one2n = 1:n;

% Set up a simplex near the initial guess.
xin = x(:); % Force xin to be a column vector
v = zeros(n,n+1);
% fv = zeros(1,n+1);
fv = zeros(n+1,3); %mpaun
v(:,1) = xin;    % Place input guess in the simplex! (credit L.Pfeffer at Stanford)
x(:) = xin;    % Change x to the form expected by funfcn
% fv(:,1) = funfcn(x,varargin{:});
fv(1,:) = funfcn(x,varargin{:}); % this is size (1,3) mpaun
func_evals = 1;
itercount = 0;
how = '';
% Initial simplex setup continues later

% Initialize the output and plot functions.
if haveoutputfcn || haveplotfcn
    %     [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,v(:,1),xOutputfcn,'init',itercount, ...
    %         func_evals, how, fv(:,1),varargin{:});
    
    [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,v(:,1),xOutputfcn,'init',itercount, ...
        func_evals, how, fv(1,1:2),varargin{:}); %mpaun
    
    if stop
        [x,fval,exitflag,output] = cleanUpInterrupt(xOutputfcn,optimValues);
        if  prnt > 0
            disp(output.message)
        end
        return;
    end
end

% Print out initial f(x) as 0th iteration
if prnt == 3
    disp(' ')
    disp(header)
    fprintf(' %5.0f        %5.0f     %12.6g         %s\n', itercount, func_evals, fv(1), how);
elseif prnt == 4
    formatsave.format = get(0,'format');
    formatsave.formatspacing = get(0,'formatspacing');
    % reset format when done
    oc1 = onCleanup(@()set(0,'format',formatsave.format));
    oc2 = onCleanup(@()set(0,'formatspacing',formatsave.formatspacing));
    format compact
    format short e
    disp(' ')
    disp(how)
    disp('v = ')
    disp(v)
    disp('fv = ')
    disp(fv)
    disp('func_evals = ')
    disp(func_evals)
end
% OutputFcn and PlotFcns call
if haveoutputfcn || haveplotfcn
    %     [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,v(:,1),xOutputfcn,'iter',itercount, ...
    %         func_evals, how, fv(:,1),varargin{:});
    [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,v(:,1),xOutputfcn,'iter',itercount, ...
        func_evals, how, fv(1,1:2),varargin{:}); %mpaun: storing the initial value
    
    if stop  % Stop per user request.
        [x,fval,exitflag,output] = cleanUpInterrupt(xOutputfcn,optimValues);
        if  prnt > 0
            disp(output.message)
        end
        return;
    end
end

% Continue setting up the initial simplex.
% Following improvement suggested by L.Pfeffer at Stanford
usual_delta = 0.05;             % 5 percent deltas for non-zero terms
zero_term_delta = 0.00025;      % Even smaller delta for zero elements of x
for j = 1:n
    y = xin;
    if y(j) ~= 0
        y(j) = (1 + usual_delta)*y(j);
    else
        y(j) = zero_term_delta;
    end
    v(:,j+1) = y;
    x(:) = y; f = funfcn(x,varargin{:});
    fv(j+1,:) = f; % this is size(1,3): OF_LF, OF_HF, label (this exact order)
end

% mpaun
labelsInitial = fv(:,3);
label = mode(labelsInitial); % take the label of the majority points

% % now check if all points in the initial simplex come from the same
% % fidelity region, i.e. either all HF or all LF
% % if they don't come, shrink to make them come
%
% while ~(all(labelsInitial==1) || all(labelsInitial==0)) % not same labels
%     usual_delta = usual_delta - 0.01;             % reduce this
%     for j = 1:n
%         y = xin;
%         if y(j) ~= 0
%             y(j) = (1 + usual_delta)*y(j);
%         else
%             y(j) = zero_term_delta;
%         end
%         v(:,j+1) = y;
%         x(:) = y; f = funfcn(x,varargin{:});
%         fv(j+1,:) = f; % this is size(1,3): OF_LF, OF_HF, label (this exact order)
%     end
% end

% if all(labelsInitial==1) || all(labelsInitial==0) %% same labels, so all the same
%     worstPointIdx = find(fv(:,labelsInitial(1)+1)==max(fv(:,labelsInitial(1)+1)));
% end

% sort so v(1,:) has the lowest function value %mpaun: skip ordering
% [fv,j] = sort(fv);
% v = v(:,j);

how = 'initial simplex';
itercount = itercount + 1;
func_evals = n+1;
if prnt == 3
    fprintf(' %5.0f        %5.0f     %12.6g         %s\n', itercount, func_evals, fv(1), how)
elseif prnt == 4
    disp(' ')
    disp(how)
    disp('v = ')
    disp(v)
    disp('fv = ')
    disp(fv)
    disp('func_evals = ')
    disp(func_evals)
end
% OutputFcn and PlotFcns call
if haveoutputfcn || haveplotfcn
    %     [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,v(:,1),xOutputfcn,'iter',itercount, ...
    %         func_evals, how, fv(:,1),varargin{:});
    idx = find(fv(:,label+1)==min(fv(:,label+1))); idx = idx(1);
    [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,v(:,idx),xOutputfcn,'iter',itercount, ...
        func_evals, how, fv(idx,1:2),varargin{:}); %mpaun: here need best f value
    
    if stop  % Stop per user request.
        [x,fval,exitflag,output] = cleanUpInterrupt(xOutputfcn,optimValues);
        if  prnt > 0
            disp(output.message)
        end
        return;
    end
end
exitflag = 1;

% Main algorithm: iterate until
% (a) the maximum coordinate difference between the current best point and the
% other points in the simplex is less than or equal to TolX. Specifically,
% until max(||v2-v1||,||v3-v1||,...,||v(n+1)-v1||) <= TolX,
% where ||.|| is the infinity-norm, and v1 holds the
% vertex with the current lowest value; AND
% (b) the corresponding difference in function values is less than or equal
% to TolFun. (Cannot use OR instead of AND.)
% The iteration stops if the maximum number of iterations or function evaluations
% are exceeded

while func_evals < maxfun && itercount < maxiter
    
    bestPointIdx_LF = find(fv(:,1)==min(fv(:,1))); bestPointIdx_LF = bestPointIdx_LF(1);
    bestPointIdx_HF = find(fv(:,2)==min(fv(:,2))); bestPointIdx_HF = bestPointIdx_HF(1);
    AllOthers_LF = [1:bestPointIdx_LF-1,bestPointIdx_LF+1:n+1];
    AllOthers_HF = [1:bestPointIdx_HF-1,bestPointIdx_HF+1:n+1];
    
    
    %     worstPointIdx_LF = find(fv(:,1)==max(fv(:,1)));
    %     worstPointIdx_HF = find(fv(:,2)==max(fv(:,2)));
    
    [~,TwoWorstIdx_LF] = maxk(fv(:,1),2);
    [~,TwoWorstIdx_HF] = maxk(fv(:,2),2);
    
    worstPointIdx_LF = TwoWorstIdx_LF(1);
    secondWorstPointIdx_LF = TwoWorstIdx_LF(2);
    
    worstPointIdx_HF = TwoWorstIdx_HF(1);
    secondWorstPointIdx_HF = TwoWorstIdx_HF(2);
    
    Oneton_LF = [1:worstPointIdx_LF-1,worstPointIdx_LF+1:n+1];
    Oneton_HF = [1:worstPointIdx_HF-1,worstPointIdx_HF+1:n+1];

    %     if max(abs(fv(1)-fv(two2np1))) <= max(tolf,10*eps(fv(1))) && ...
    %             max(max(abs(v(:,two2np1)-v(:,onesn)))) <= max(tolx,10*eps(max(v(:,1))))
        
        
    if (max(abs(fv(bestPointIdx_LF,1)-fv(AllOthers_LF,1))) <= max(tolf,10*eps(fv(bestPointIdx_LF,1))) && ...
            max(max(abs(v(:,AllOthers_LF)-v(:,bestPointIdx_LF)))) <= max(tolx,10*eps(max(v(:,bestPointIdx_LF))))) || ... % tolerance level either for OF_LF
            (max(abs(fv(bestPointIdx_HF,2)-fv(AllOthers_HF,2))) <= max(tolf,10*eps(fv(bestPointIdx_HF,2))) && ... % or HF
            max(max(abs(v(:,AllOthers_HF)-v(:,bestPointIdx_HF)))) <= max(tolx,10*eps(max(v(:,bestPointIdx_HF)))))     %mpaun
        break
    end
    % fv(1:(n+1),1:3)
    % Compute the reflection point
    
    % xbar = average of the n (NOT n+1) best points
    %     xbar = sum(v(:,one2n), 2)/n;
    
    %mpaun
    if label==0 %LF
        xbar = sum(v(:,Oneton_LF), 2)/n;
        
        worstPointIdx = worstPointIdx_LF;
        secondWorstPointIdx = secondWorstPointIdx_LF;
        bestPointIdx = bestPointIdx_LF;
        
        AllOthers = AllOthers_LF;
        
        Oneton = Oneton_LF;
        
    else % 1: HF
        xbar = sum(v(:,Oneton_HF), 2)/n;
        
        worstPointIdx = worstPointIdx_HF;
        secondWorstPointIdx = secondWorstPointIdx_HF;
        bestPointIdx = bestPointIdx_HF;
        
        AllOthers = AllOthers_HF;
        
        Oneton = Oneton_HF;

    end
    
    xr = (1 + rho)*xbar - rho*v(:,worstPointIdx); %mpaun
    
    %                         xr = (1 + rho)*xbar - rho*v(:,end);
    
    x(:) = xr; fxr = funfcn(x,varargin{:});
    labelxr = fxr(3); % 3rd entry is the label mpaun
    func_evals = func_evals+1;
    
    %     if fxr < fv(:,1)
    if fxr(labelxr+1) < fv(bestPointIdx,labelxr+1) %mpaun % expansion
        % Calculate the expansion point
        %         xe = (1 + rho*chi)*xbar - rho*chi*v(:,end);
        
        xe = (1 + rho*chi)*xbar - rho*chi*v(:,worstPointIdx); %mpaun
        x(:) = xe; fxe = funfcn(x,varargin{:});
        labelxe = fxe(3); % 3rd entry is the label mpaun
        
        func_evals = func_evals+1;
        %         if fxe < fxr
        if fxe(labelxe+1) < fxr(labelxe+1)% mpaun
            %             v(:,end) = xe;
            %             fv(:,end) = fxe;
            %mpaun
            v(:,worstPointIdx) = xe;
            fv(worstPointIdx,:) = fxe;
            how = 'expand';
        else
            %             v(:,end) = xr;
            %             fv(:,end) = fxr;
            %mpaun
            v(:,worstPointIdx) = xr;
            fv(worstPointIdx,:) = fxr;
            how = 'reflect';
        end
        
    else % fv(:,1) <= fxr % reflection
        %         if fxr < fv(:,n)
        if fxr(labelxr+1) < fv(secondWorstPointIdx,labelxr+1) %mpaun
            %             v(:,end) = xr;
            %             fv(:,end) = fxr;
            %mpaun
            v(:,worstPointIdx) = xr;
            fv(worstPointIdx,:) = fxr;
            how = 'reflect';
        else % fxr >= fv(:,n) % contraction
            % Perform contraction
            %             if fxr < fv(:,end)
            if fxr(labelxr+1) < fv(worstPointIdx,labelxr+1) %mpaun
                % Perform an outside contraction
                %                 xc = (1 + psi*rho)*xbar - psi*rho*v(:,end);
                xc = (1 + psi*rho)*xbar - psi*rho*v(:,worstPointIdx); %mpaun
                
                x(:) = xc; fxc = funfcn(x,varargin{:});
                labelxc = fxc(3); % 3rd entry is the label mpaun
                
                func_evals = func_evals+1;
                
                %                 if fxc <= fxr
                if fxc(labelxc+1) <= fxr(labelxc+1) %mpaun
                    %                     v(:,end) = xc;
                    %                     fv(:,end) = fxc;
                    %mpaun
                    v(:,worstPointIdx) = xc;
                    fv(worstPointIdx,:) = fxc;
                    how = 'contract outside';
                else
                    % perform a shrink
                    how = 'shrink';
                end
            else
                % Perform an inside contraction
                %                 xcc = (1-psi)*xbar + psi*v(:,end);
                xcc = (1-psi)*xbar + psi*v(:,worstPointIdx); %mpaun
                
                x(:) = xcc; fxcc = funfcn(x,varargin{:});
                labelxcc = fxcc(3); % 3rd entry is the label mpaun
                
                func_evals = func_evals+1;
                
                %                 if fxcc < fv(:,end)
                if fxcc(labelxcc+1) < fv(worstPointIdx,labelxcc+1) %mpaun
                    %                     v(:,end) = xcc;
                    %                     fv(:,end) = fxcc;
                    %mpaun
                    v(:,worstPointIdx) = xcc;
                    fv(worstPointIdx,:) = fxcc;
                    how = 'contract inside';
                else
                    % perform a shrink
                    how = 'shrink';
                end
            end
            if strcmp(how,'shrink')
                %                 for j=two2np1
                for j=AllOthers %mpaun
                    %                     v(:,j)=v(:,1)+sigma*(v(:,j) - v(:,1));
                    v(:,j)=v(:,bestPointIdx)+sigma*(v(:,j) - v(:,bestPointIdx)); %mpaun
                    
                    %                     x(:) = v(:,j); fv(:,j) = funfcn(x,varargin{:});
                    x(:) = v(:,j); fv(j,:) = funfcn(x,varargin{:}); %mpaun
                    
                end
                func_evals = func_evals + n;
            end
        end
    end
    %     [fv,j] = sort(fv); % avoid sorting
    %     v = v(:,j);
    %mpaun
    AllLabels = fv(:,3);
    label = mode(AllLabels); % choose the label of the majority points
    
%     fv
    
    itercount = itercount + 1;
    if prnt == 3
        fprintf(' %5.0f        %5.0f     %12.6g         %s\n', itercount, func_evals, fv(1), how)
    elseif prnt == 4
        disp(' ')
        disp(how)
        disp('v = ')
        disp(v)
        disp('fv = ')
        disp(fv)
        disp('func_evals = ')
        disp(func_evals)
    end
    % OutputFcn and PlotFcns call
    if haveoutputfcn || haveplotfcn
        %         [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,v(:,1),xOutputfcn,'iter',itercount, ...
        %             func_evals, how, fv(:,1),varargin{:});
        idx = find(fv(:,label+1)==min(fv(:,label+1))); idx = idx(1);
        [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,v(:,idx),xOutputfcn,'iter',itercount, ...
            func_evals, how, fv(idx,1:2),varargin{:}); %mpaun: here need best f value
        if stop  % Stop per user request.
            [x,fval,exitflag,output] = cleanUpInterrupt(xOutputfcn,optimValues);
            if  prnt > 0
                disp(output.message)
            end
            return;
        end
    end
end   % while

% x(:) = v(:,1);
% fval = fv(:,1);
%mpaun
bestPointIdx = find(fv(:,label+1)==min(fv(:,label+1))); bestPointIdx = bestPointIdx(1);
x(:) = v(:,bestPointIdx);
fval = fv(bestPointIdx,label+1);

% x
% fval

% OutputFcn and PlotFcns call
if haveoutputfcn || haveplotfcn
    callOutputAndPlotFcns(outputfcn,plotfcns,x,xOutputfcn,'done',itercount, func_evals, how, fval, varargin{:});
end

if func_evals >= maxfun
    printMsg = prnt > 0;
    if buildOutputStruct || printMsg
        msg = getString(message('MATLAB:optimfun:fminsearch:ExitingMaxFunctionEvals', sprintf('%f',fval)));
    end
    exitflag = 0;
elseif itercount >= maxiter
    printMsg = prnt > 0;
    if buildOutputStruct || printMsg
        msg = getString(message('MATLAB:optimfun:fminsearch:ExitingMaxIterations', sprintf('%f',fval)));
    end
    exitflag = 0;
else
    printMsg = prnt > 1;
    if buildOutputStruct || printMsg
        msg = ...
            getString(message('MATLAB:optimfun:fminsearch:OptimizationTerminatedXSatisfiesCriteria', ...
            sprintf('%e',tolx), sprintf('%e',tolf)));
        
    end
    exitflag = 1;
end

if buildOutputStruct
    output.iterations = itercount;
    output.funcCount = func_evals;
    output.algorithm = 'Nelder-Mead simplex direct search';
    output.message = msg;
end

if printMsg
    disp(' ')
    disp(msg)
end

%--------------------------------------------------------------------------
function [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,x,xOutputfcn,state,iter,...
    numf,how,f,varargin)
% CALLOUTPUTANDPLOTFCNS assigns values to the struct OptimValues and then calls the
% outputfcn/plotfcns.
%
% state - can have the values 'init','iter', or 'done'.

% For the 'done' state we do not check the value of 'stop' because the
% optimization is already done.
optimValues.iteration = iter;
optimValues.funccount = numf;
optimValues.fval = f;
optimValues.procedure = how;

xOutputfcn(:) = x;  % Set x to have user expected size
stop = false;
state = char(state);
% Call output functions
if ~isempty(outputfcn)
    switch state
        case {'iter','init'}
            stop = callAllOptimOutputFcns(outputfcn,xOutputfcn,optimValues,state,varargin{:}) || stop;
        case 'done'
            callAllOptimOutputFcns(outputfcn,xOutputfcn,optimValues,state,varargin{:});
    end
end
% Call plot functions
if ~isempty(plotfcns)
    switch state
        case {'iter','init'}
            stop = callAllOptimPlotFcns(plotfcns,xOutputfcn,optimValues,state,varargin{:}) || stop;
        case 'done'
            callAllOptimPlotFcns(plotfcns,xOutputfcn,optimValues,state,varargin{:});
    end
end

%--------------------------------------------------------------------------
function [x,FVAL,EXITFLAG,OUTPUT] = cleanUpInterrupt(xOutputfcn,optimValues)
% CLEANUPINTERRUPT updates or sets all the output arguments of FMINBND when the optimization
% is interrupted.

% Call plot function driver to finalize the plot function figure window. If
% no plot functions have been specified or the plot function figure no
% longer exists, this call just returns.
callAllOptimPlotFcns('cleanuponstopsignal');

x = xOutputfcn;
FVAL = optimValues.fval;
EXITFLAG = -1;
OUTPUT.iterations = optimValues.iteration;
OUTPUT.funcCount = optimValues.funccount;
OUTPUT.algorithm = 'Nelder-Mead simplex direct search';
OUTPUT.message = getString(message('MATLAB:optimfun:fminsearch:OptimizationTerminatedPrematurelyByUser'));

%--------------------------------------------------------------------------
function f = checkfun(x,userfcn,varargin)
% CHECKFUN checks for complex or NaN results from userfcn.

f = userfcn(x,varargin{:});
% Note: we do not check for Inf as FMINSEARCH handles it naturally.
if isnan(f)
    error('MATLAB:fminsearch:checkfun:NaNFval',...
        getString(message('MATLAB:optimfun:fminsearch:checkfun:NaNFval', localChar( userfcn ))));
elseif ~isreal(f)
    error('MATLAB:fminsearch:checkfun:ComplexFval',...
        getString(message('MATLAB:optimfun:fminsearch:checkfun:ComplexFval', localChar( userfcn ))));
end

%--------------------------------------------------------------------------
function strfcn = localChar(fcn)
% Convert the fcn to a character array for printing

if ischar(fcn)
    strfcn = fcn;
elseif isstring(fcn) || isa(fcn,'inline')
    strfcn = char(fcn);
elseif isa(fcn,'function_handle')
    strfcn = func2str(fcn);
else
    try
        strfcn = char(fcn);
    catch
        strfcn = getString(message('MATLAB:optimfun:fminsearch:NameNotPrintable'));
    end
end


