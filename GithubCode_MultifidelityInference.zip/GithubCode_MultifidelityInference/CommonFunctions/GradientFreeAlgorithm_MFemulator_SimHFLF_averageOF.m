function OptimHistory = GradientFreeAlgorithm_MFemulator_SimHFLF_averageOF(param0, trueData, HFem, LFem, extra_p)
% this is a gradient-free optimiser that is adapted for multifidelity
% inference when the LF and HF models are approximations to a REFERECE
% model, and we build emulators for them with a fixed no of principal
% components to ensure over e.g. 99% variance has been explained

% here an average OF is taken = prob(LF)*OF_LF + prob(HF)*OF_HF, instead of
% switching between LF and HF
mdl = extra_p{1};
l = extra_p{2};
u = extra_p{3};
sc = extra_p{4};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization

% gradient-free optimiser
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-20, 'TolX',1e-20, ...
%'MaxFunEvals',1000, 'MaxIter', 1000);

[x,fval] = fminsearchbnd(@(x)GetObjFct(x), param0, l./sc, u./sc, options); % not test


    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
        %
        ObjFctEach = NaN(2,1); % 1: LF, 2: HF
        
        % LF
        E = NaN(size(param,1), LFem.NC);
        
        for i=1:LFem.NC
            % Make predictions of every PC score using gp models   
            E(:,i) = gp_pred(LFem.gp_regr{i}, LFem.x_regr, LFem.y_regr(:,i), param);         
        end
        
        data_LF = (E.*LFem.std_y + LFem.mean_y) * LFem.coeff(:,1:LFem.NC)' + LFem.mu;
        r_data_LF = trueData - data_LF;
        ObjFctEach(1) = sum(r_data_LF.^2,2);
        
        % HF
        E = NaN(size(param,1), HFem.NC);
        
        for i=1:HFem.NC
            % Make predictions of every PC score using gp models   
            E(:,i) = gp_pred(HFem.gp_regr{i}, HFem.x_regr, HFem.y_regr(:,i), param);         
        end
        
        data_HF = (E.*HFem.std_y + HFem.mean_y) * HFem.coeff(:,1:HFem.NC)' + HFem.mu;
        r_data_HF = trueData - data_HF;
        ObjFctEach(2) = sum(r_data_HF.^2,2);
        
        % label=1 if HF and label=0 if LF
        % mdl.ClassNames gives 0 (LF) and 1 (HF) in this exact order, so 
        % prob(1): probability of class 0 = LF
        % prob(2)   % probability of class 1 = HF; and prob(1)+prob(2)=1
        [label, prob] = predict(mdl,param.*sc); 
        
        % in this exact order: [prob_LF, OF_LF] and [prob_HF, OF_HF]
        ObjFct = prob(1)*ObjFctEach(1) + prob(2)*ObjFctEach(2);
        
        
    end
end