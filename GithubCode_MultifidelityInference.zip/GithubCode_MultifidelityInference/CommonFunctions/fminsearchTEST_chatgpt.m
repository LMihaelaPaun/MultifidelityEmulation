function [x,fval,exitflag,output] = fminsearchTEST(funfcn,x,options,varargin)
% ChatGPT-adapted 

defaultopt = struct('Display','notify','MaxIter','200*numberOfVariables',...
    'MaxFunEvals','200*numberOfVariables','TolX',1e-4,'TolFun',1e-4, ...
    'FunValCheck','off','OutputFcn',[],'PlotFcns',[]);

if nargin < 3, options = []; end

n = numel(x);
numberOfVariables = n;

printtype = optimget(options,'Display',defaultopt,'fast');
tolx = optimget(options,'TolX',defaultopt,'fast');
tolf = optimget(options,'TolFun',defaultopt,'fast');
maxfun = optimget(options,'MaxFunEvals',defaultopt,'fast');
maxiter = optimget(options,'MaxIter',defaultopt,'fast');
funValCheck = strcmp(optimget(options,'FunValCheck',defaultopt,'fast'),'on');

if ischar(maxfun) || isstring(maxfun)
    maxfun = 200*numberOfVariables;
end
if ischar(maxiter) || isstring(maxiter)
    maxiter = 200*numberOfVariables;
end

switch printtype
    case {'none','off'}
        prnt = 0;
    case {'iter','iter-detailed'}
        prnt = 3;
    case {'final','final-detailed'}
        prnt = 2;
    otherwise
        prnt = 1;
end

outputfcn = optimget(options,'OutputFcn',defaultopt,'fast');
if isempty(outputfcn)
    haveoutputfcn = false;
else
    haveoutputfcn = true;
    xOutputfcn = x;
    outputfcn = createCellArrayOfFunctions(outputfcn,'OutputFcn');
end

plotfcns = optimget(options,'PlotFcns',defaultopt,'fast');
if isempty(plotfcns)
    haveplotfcn = false;
else
    haveplotfcn = true;
    xOutputfcn = x;
    plotfcns = createCellArrayOfFunctions(plotfcns,'PlotFcns');
end

funfcn = fcnchk(funfcn,length(varargin));

if funValCheck
    varargin = [{funfcn}, varargin];
    funfcn = @checkfun;
end

rho = 1; chi = 2; psi = 0.5; sigma = 0.5;

xin = x(:);
v  = zeros(n,n+1);
fv = zeros(n+1,3);   % [OF_LF, OF_HF, label]

v(:,1) = xin;
x(:) = xin;
fv(1,:) = funfcn(x,varargin{:});

func_evals = 1;
itercount = 0;
how = '';

%% Initial simplex
usual_delta = 0.05;
zero_term_delta = 0.00025;

for j = 1:n
    y = xin;
    if y(j) ~= 0
        y(j) = (1 + usual_delta)*y(j);
    else
        y(j) = zero_term_delta;
    end
    v(:,j+1) = y;
    x(:) = y;
    fv(j+1,:) = funfcn(x,varargin{:});
end

func_evals = n+1;
how = 'initial simplex';

labelsInitial = fv(:,3);
activeLabel = mode(labelsInitial);
activeCol = activeLabel + 1;
[~,idx0] = min(fv(:,activeCol));

%% Output initial state
if haveoutputfcn || haveplotfcn
    [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns( ...
        outputfcn, plotfcns, v(:,idx0), xOutputfcn, ...
        'init', itercount, func_evals, how, fv(idx0,1:2), varargin{:});

    if stop
        [x,fval,exitflag,output] = cleanUpInterrupt(xOutputfcn,optimValues);
        return;
    end
end

exitflag = 1;

%% Main loop
while func_evals < maxfun && itercount < maxiter

    activeCol = activeLabel + 1;

    [bestPointIdx,worstPointIdx,secondWorstPointIdx,AllOthers,Oneton] = ...
        get_simplex_indices(fv,activeCol,n);

    %% Stopping under active fidelity
    if max(abs(fv(bestPointIdx,activeCol) - fv(AllOthers,activeCol))) <= ...
            max(tolf,10*eps(fv(bestPointIdx,activeCol))) && ...
       max(max(abs(v(:,AllOthers) - v(:,bestPointIdx)))) <= ...
            max(tolx,10*eps(max(abs(v(:,bestPointIdx)))))
        break
    end

    %% Reflection
    xbar = mean(v(:,Oneton),2);
    xr = (1 + rho)*xbar - rho*v(:,worstPointIdx);

    x(:) = xr;
    fxr = funfcn(x,varargin{:});
    func_evals = func_evals + 1;

    proposedLabel = fxr(3);
    proposedCol = proposedLabel + 1;

    %% Recompute simplex ordering using proposed fidelity
    [bestPointIdx,worstPointIdx,secondWorstPointIdx,AllOthers,Oneton] = ...
        get_simplex_indices(fv,proposedCol,n);

    xbar = mean(v(:,Oneton),2);

    if fxr(proposedCol) < fv(bestPointIdx,proposedCol)

        %% Expansion
        xe = (1 + rho*chi)*xbar - rho*chi*v(:,worstPointIdx);
        x(:) = xe;
        fxe = funfcn(x,varargin{:});
        func_evals = func_evals + 1;

        expansionLabel = fxe(3);
        expansionCol = expansionLabel + 1;

        if fxe(expansionCol) < fxr(expansionCol)
            v(:,worstPointIdx) = xe;
            fv(worstPointIdx,:) = fxe;
            activeLabel = expansionLabel;
            how = 'expand';
        else
            v(:,worstPointIdx) = xr;
            fv(worstPointIdx,:) = fxr;
            activeLabel = proposedLabel;
            how = 'reflect';
        end

    elseif fxr(proposedCol) < fv(secondWorstPointIdx,proposedCol)

        %% Accept reflection
        v(:,worstPointIdx) = xr;
        fv(worstPointIdx,:) = fxr;
        activeLabel = proposedLabel;
        how = 'reflect';

    else

        %% Contraction
        if fxr(proposedCol) < fv(worstPointIdx,proposedCol)

            %% Outside contraction
            xc = (1 + psi*rho)*xbar - psi*rho*v(:,worstPointIdx);
            x(:) = xc;
            fxc = funfcn(x,varargin{:});
            func_evals = func_evals + 1;

            contractionLabel = fxc(3);
            contractionCol = contractionLabel + 1;

            if fxc(contractionCol) <= fxr(contractionCol)
                v(:,worstPointIdx) = xc;
                fv(worstPointIdx,:) = fxc;
                activeLabel = contractionLabel;
                how = 'contract outside';
            else
                how = 'shrink';
            end

        else

            %% Inside contraction
            xcc = (1 - psi)*xbar + psi*v(:,worstPointIdx);
            x(:) = xcc;
            fxcc = funfcn(x,varargin{:});
            func_evals = func_evals + 1;

            contractionLabel = fxcc(3);
            contractionCol = contractionLabel + 1;

            if fxcc(contractionCol) < fv(worstPointIdx,contractionCol)
                v(:,worstPointIdx) = xcc;
                fv(worstPointIdx,:) = fxcc;
                activeLabel = contractionLabel;
                how = 'contract inside';
            else
                how = 'shrink';
            end
        end

        %% Shrink under current active fidelity
        if strcmp(how,'shrink')

            activeCol = activeLabel + 1;
            [bestPointIdx,~,~,AllOthers,~] = ...
                get_simplex_indices(fv,activeCol,n);

            for j = AllOthers
                v(:,j) = v(:,bestPointIdx) + sigma*(v(:,j) - v(:,bestPointIdx));
                x(:) = v(:,j);
                fv(j,:) = funfcn(x,varargin{:});
            end

            func_evals = func_evals + n;

            [~,idxBest] = min(fv(:,activeCol));
            activeLabel = fv(idxBest,3);
        end
    end

    itercount = itercount + 1;

    %% Output trajectory point under active fidelity
    activeCol = activeLabel + 1;
    [~,idxOut] = min(fv(:,activeCol));

    if haveoutputfcn || haveplotfcn
        [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns( ...
            outputfcn, plotfcns, v(:,idxOut), xOutputfcn, ...
            'iter', itercount, func_evals, how, fv(idxOut,1:2), varargin{:});

        if stop
            [x,fval,exitflag,output] = cleanUpInterrupt(xOutputfcn,optimValues);
            return;
        end
    end
end

%% Final selection: one fidelity column only
finalCol = activeLabel + 1;
[~,bestPointIdx] = min(fv(:,finalCol));

x(:) = v(:,bestPointIdx);
fval = fv(bestPointIdx,finalCol);

%% Done output call
if haveoutputfcn || haveplotfcn
    callOutputAndPlotFcns(outputfcn,plotfcns,x,xOutputfcn, ...
        'done', itercount, func_evals, how, fval, varargin{:});
end

if func_evals >= maxfun || itercount >= maxiter
    exitflag = 0;
else
    exitflag = 1;
end

output.iterations = itercount;
output.funcCount = func_evals;
output.algorithm = 'Adapted Nelder-Mead simplex direct search';
output.final_fv = fv;
output.final_simplex = v;
output.final_labels = fv(:,3);
output.final_active_label = activeLabel;
output.final_active_column = finalCol;

if prnt >= 2
    fprintf('\nAdapted fminsearchTEST finished. fval = %.6e\n', fval);
end

end


function [bestPointIdx,worstPointIdx,secondWorstPointIdx,AllOthers,Oneton] = ...
    get_simplex_indices(fv,col,n)

[~,bestPointIdx] = min(fv(:,col));

[~,twoWorst] = maxk(fv(:,col),2);
worstPointIdx = twoWorst(1);
secondWorstPointIdx = twoWorst(2);

AllOthers = setdiff(1:n+1,bestPointIdx);
Oneton    = setdiff(1:n+1,worstPointIdx);

end


function [xOutputfcn, optimValues, stop] = callOutputAndPlotFcns(outputfcn,plotfcns,x,xOutputfcn,state,iter,...
    numf,how,f,varargin)

optimValues.iteration = iter;
optimValues.funccount = numf;
optimValues.fval = f;
optimValues.procedure = how;

xOutputfcn(:) = x;
stop = false;
state = char(state);

if ~isempty(outputfcn)
    switch state
        case {'iter','init'}
            stop = callAllOptimOutputFcns(outputfcn,xOutputfcn,optimValues,state,varargin{:}) || stop;
        case 'done'
            callAllOptimOutputFcns(outputfcn,xOutputfcn,optimValues,state,varargin{:});
    end
end

if ~isempty(plotfcns)
    switch state
        case {'iter','init'}
            stop = callAllOptimPlotFcns(plotfcns,xOutputfcn,optimValues,state,varargin{:}) || stop;
        case 'done'
            callAllOptimPlotFcns(plotfcns,xOutputfcn,optimValues,state,varargin{:});
    end
end

end


function [x,FVAL,EXITFLAG,OUTPUT] = cleanUpInterrupt(xOutputfcn,optimValues)

x = xOutputfcn;
FVAL = optimValues.fval;
EXITFLAG = -1;
OUTPUT.iterations = optimValues.iteration;
OUTPUT.funcCount = optimValues.funccount;
OUTPUT.algorithm = 'Adapted Nelder-Mead simplex direct search';
OUTPUT.message = 'Optimization terminated prematurely by output function';

end


function f = checkfun(x,userfcn,varargin)

f = userfcn(x,varargin{:});

if any(isnan(f(:)))
    error('fminsearchTEST:NaNFval','Objective returned NaN.');
elseif ~isreal(f)
    error('fminsearchTEST:ComplexFval','Objective returned complex value.');
end

end