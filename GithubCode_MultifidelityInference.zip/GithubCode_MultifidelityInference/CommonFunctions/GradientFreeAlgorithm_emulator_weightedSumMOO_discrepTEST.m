function OptimHistory = GradientFreeAlgorithm_emulator_weightedSumMOO_discrepTEST(param0, trueData, extra_p)
% this is a gradient-free optimiser that is adapted for multifidelity
% inference

gp_regr_data = extra_p{1};
x_regr = extra_p{2};
y_regr_data = extra_p{3};
NC_data_fid = extra_p{4};
coeff_data = extra_p{5};
mu_data = extra_p{6};
mean_y_data = extra_p{7};
std_y_data = extra_p{8};
switchEm = extra_p{9};
HF = extra_p{10};
mdl = extra_p{11};
l = extra_p{12};
u = extra_p{13};
sc = extra_p{14};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization

% gradient-free optimiser
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-20, 'TolX',1e-20, ...
%'MaxFunEvals',1000, 'MaxIter', 1000);

[x,fval] = fminsearchbndTEST(@(x)GetObjFct(x), param0, l./sc, u./sc, options);


    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
        %
        ObjFctEach = NaN(2,1);
        
        % 1: LF, 2: HF
        NC_LF = NC_data_fid(1);
        NC_HF = NC_data_fid(2);
        
        E = NaN(size(param,1), NC_HF);
        
        for i=1:NC_HF
            % Make predictions of every PC score using gp models
            
            E(:,i) = gp_pred(gp_regr_data{i}, x_regr, y_regr_data(:,i), param);
            
        end
        
        % HF
        data_HF = (E.*std_y_data(1:NC_HF)+mean_y_data(1:NC_HF)) * coeff_data(:,1:NC_HF)' + mu_data;
        r_data_HF = trueData - data_HF;
        ObjFctEach(2) = sum(r_data_HF.^2,2);
        
        % LF - a subset of HF
        data_LF = (E(:,1:NC_LF).*std_y_data(1:NC_LF)+mean_y_data(1:NC_LF)) * coeff_data(:,1:NC_LF)' + mu_data;
        r_data_LF = trueData - data_LF;
        ObjFctEach(1) = sum(r_data_LF.^2,2);
        
        %ObjFctEach
        label = predict(mdl,param.*sc); % label=1 if HF and label=0 if LF
        
        % in this exact order: OF_LF, OF_HF, label;
        % if label=1, choose ObjFct(label+1); if label=0, choose ObjFct(label+1), so always choose ObjFct(label+1)
        ObjFct = [ObjFctEach(1),ObjFctEach(2),label];
        
    end
end