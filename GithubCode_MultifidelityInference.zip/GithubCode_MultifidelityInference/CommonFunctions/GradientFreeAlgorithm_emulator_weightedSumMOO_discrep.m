function OptimHistory = GradientFreeAlgorithm_emulator_weightedSumMOO_discrep(param0, trueData, extra_p)
% this is a gradient-free optimiser (original form), only works for HF or
% LF emulators, not multifidelity

gp_regr_data = extra_p{1};
x_regr = extra_p{2};
y_regr_data = extra_p{3};
NC_data_fid = extra_p{4};
coeff_data = extra_p{5};
mu_data = extra_p{6};
mean_y_data = extra_p{7};
std_y_data = extra_p{8};
switchEm = extra_p{9};
HF = extra_p{10};
mdl = extra_p{11};
l = extra_p{12};
u = extra_p{13};
sc = extra_p{14};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient-free
   
% gradient-free optimiser (these low tolerances are needed for the
% sinusoidal example, for the other examples we have used default 10^(-6))
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-20, 'TolX',1e-20, ...
   % 'MaxFunEvals',1000, 'MaxIter', 1000);

[x,fval] = fminsearchbnd(@(x)GetObjFct(x), param0, l./sc, u./sc, options);

    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
                
        if switchEm ~= 1 % we do not do switching based on KNN prediction, only HF or LF

            if HF==1 % HF
                NC = NC_data_fid(2); %HF
            else % LF
                NC = NC_data_fid(1); %LF
            end
                        
            E = NaN(size(param,1), NC);
            
            for i=1:NC
                % Make predictions of every PC score using gp models
                
                E(:,i) = gp_pred(gp_regr_data{i}, x_regr, y_regr_data(:,i), param);
            end
            
            data = (E.*std_y_data(1:NC)+mean_y_data(1:NC)) * coeff_data(:,1:NC)' + mu_data;
            
            r_data = trueData - data;
            
            % RSS
            ObjFct = sum(r_data.^2,2);
            
        end
    end

end