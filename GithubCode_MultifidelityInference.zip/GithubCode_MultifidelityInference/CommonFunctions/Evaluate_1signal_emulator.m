function data = Evaluate_1signal_emulator(param, extra_p, GP_type)

% Evaluates emulator output only.
% Does not compute RSS.
%
% GP_type = 1: GP-time
% GP_type = 2: GP-PCA

if GP_type == 1

    gp_data = extra_p{1};
    gp1_data = extra_p{2};
    gp2_data = extra_p{3};

    input_train = extra_p{4};
    x1 = extra_p{5};
    x2 = extra_p{6};
    outputPressure_train = extra_p{7};
    mean_y_data = extra_p{8};
    std_y_data = extra_p{9};
    ntp = extra_p{10};

    nd = size(param,2);

    input_test = NaN(ntp, nd+1);

    for j = 1:ntp
        input_test(j,:) = [param, x2(j)];
    end

    E = gp_pred(gp_data, input_train, outputPressure_train, ...
        gp1_data, gp2_data, x1, x2, input_test);

    data = E .* std_y_data + mean_y_data;

else

    gp_regr_data = extra_p{1};
    x_regr = extra_p{2};
    y_regr_data = extra_p{3};
    NC_data = extra_p{4};
    coeff_data = extra_p{5};
    mu_data = extra_p{6};
    mean_y_data = extra_p{7};
    std_y_data = extra_p{8};

    E = NaN(size(param,1), NC_data);

    for i = 1:NC_data
        E(:,i) = gp_pred(gp_regr_data{i}, x_regr, y_regr_data(:,i), param);
    end

    data = (E .* std_y_data + mean_y_data) * coeff_data(:,1:NC_data)' + mu_data;

end

end