function GetClassificationData(theta, extra_p) 
%% ================================================================
% STEP 1: Build common stencil parameter space and evaluate REF/LF/HF data
% This does not depend on iDS.
% ================================================================

l = extra_p{1};
u = extra_p{2};
sc = extra_p{3};
GP_type = extra_p{4};
ntp = extra_p{5};
nv = extra_p{6};

%% Build local stencil around every theta point

[nTheta, nd] = size(theta);

hFrac = 0.02;          % 2% of each parameter range
h = hFrac * (u - l);   % 1 x nd

nStencil = 1 + 2*nd; % size of the stencil

ThetaStencil = NaN(nTheta, nStencil, nd);

for j = 1:nTheta
    
    theta0 = theta(j,:); % inspect theta to ensure it is on original scale - it is!
    
    stencil = theta0;
    
    for d = 1:nd
        
        theta_plus = theta0;
        theta_minus = theta0;
        
        theta_plus(d)  = min(theta0(d) + h(d), u(d));
        theta_minus(d) = max(theta0(d) - h(d), l(d));
        
        stencil = [stencil; theta_plus; theta_minus];
        
    end
    
    ThetaStencil(j,:,:) = stencil;
    
end

ThetaStencilFlat = reshape(ThetaStencil, nTheta*nStencil, nd);
nTotal = size(ThetaStencilFlat,1);

%% Load LF and HF emulators

LF = load('/SimulatorsMultifidelity/SystemicModel/GP_PCA_Emulator_LF_5D.mat');

extra_p_LF = {LF.gp_regr_flow, LF.x_regr, LF.y_regr_flow, LF.NC_flow, LF.coeff_flow, LF.mu_flow, LF.mean_y_flow, LF.std_y_flow};

HF = load('/SimulatorsMultifidelity/SystemicModel/GP_PCA_Emulator_HF_5D.mat');

extra_p_HF = {HF.gp_regr_flow, HF.x_regr, HF.y_regr_flow, HF.NC_flow, HF.coeff_flow, HF.mu_flow, HF.mean_y_flow, HF.std_y_flow};

%% Preallocate output data

REFData_classif_stencil = NaN(nTotal, ntp);
LFData_classif_stencil  = NaN(nTotal, ntp);
HFData_classif_stencil  = NaN(nTotal, ntp);

%% Evaluate REF, LF, HF outputs at all stencil points

delete(gcp('nocreate'))
parpool('local', 48)

parfor i = 1:nTotal
    
    file_id = i;
    
    param = ThetaStencilFlat(i,:); % param is on original scale
    
    %% REF model: EnvironSimulator
    [~, dataREF] = Run_fluidsModel(param, file_id, nv, ntp); % takes param on original scale
    REFData_classif_stencil(i,:) = dataREF(:,1); % first flow only
    
    %% LF emulator
    dataLF = Evaluate_1signal_emulator(param./sc, extra_p_LF, GP_type); % takes scaled param
    LFData_classif_stencil(i,:) = dataLF;
    
    %% HF emulator
    dataHF = Evaluate_1signal_emulator(param./sc, extra_p_HF, GP_type); % takes scaled param
    HFData_classif_stencil(i,:) = dataHF;
    
end

%% Reshape back to nTheta x nStencil x ntp

REFData_classif_stencil = reshape(REFData_classif_stencil, nTheta, nStencil, ntp);
LFData_classif_stencil  = reshape(LFData_classif_stencil,  nTheta, nStencil, ntp);
HFData_classif_stencil  = reshape(HFData_classif_stencil,  nTheta, nStencil, ntp);

%% Save common data

save('/SimulatorsMultifidelity/SystemicModel/ClassifierStencilModelData_Sys.mat')

end

