function GetInferenceData(thetaStar, extra_p) 
%% ================================================================
% Get inference data sets
% ================================================================

ntp = extra_p{1};
nv = extra_p{2};

nDS = size(thetaStar, 1);

delete(gcp('nocreate'))
parpool('local', 48)

SimData_thetaStar = NaN(nDS,ntp);

parfor iDS=1:nDS
    
    file_id = iDS;
    
    [~, clean_flowData] = Run_fluidsModel(thetaStar(iDS,:), file_id, nv, ntp);
    
    SimData_thetaStar(iDS,:) = clean_flowData(:,1); % first flow only;
    
end


%% Save inference data

save('/SimulatorsMultifidelity/SystemicModel/InferenceData_Sys.mat', 'SimData_thetaStar')

end