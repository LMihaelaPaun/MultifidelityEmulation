clear;close all

% add path to the original GPstuff toolbox (without the changes made to
% accommodate kronecker product for multioutput GP)
addpath(genpath('/GPstuff-4.7'))

addpath('/CommonFunctions')

load('/SignalsForEmulator_10000s_5D.mat')

nd = 5;

n_train = 1000; n_test = size(x,1) - n_train;

par_train = x(1:n_train,:);

par_test = x(n_train+1:end,:);


sc = max(abs(l),abs(u));

x_train = par_train; x_test = par_test;

x_train = x_train./sc; x_test = x_test./sc;

flow_train = NaN(n_train,ntp); flow_test = NaN(n_test,ntp);

j=1; % take first flow only

for i=1:n_train
    
    flow_train(i,:) = clean_flow{i}(:,j);
    
end

for i=1:n_test
    
    flow_test(i,:,:) = clean_flow{n_train+i}(:,j);
    
end

% PCA data (take the same as training data)
n_PCA = n_train; % no of training points
x_PCA = x_train; % this is already scaled

flow_PCA = flow_train;

%% Fit PCA
%
% Fit PCA on flow
[coeff_flow,score_flow,latent,tsquared,explained,mu_flow] = pca(flow_PCA);

meanMSE_PCA_train = NaN(min(size(coeff_flow,2),20),1);

for NC = 1:(min(size(coeff_flow,2),20))
    flow_recons = score_flow(:,1:NC)*coeff_flow(:,1:NC)'+mu_flow;
    
    MSE_PCA_train = sum((flow_PCA - flow_recons).^2,2);
    
    meanMSE_PCA_train(NC) = mean(MSE_PCA_train, "omitnan"); % !!! quantity of interest
end

% test PCA on test data
meanMSE_PCA_test = NaN(min(size(coeff_flow,2),20),1);

for NC = 1:(min(size(coeff_flow,2),20))
    PCscores_test = (flow_test - mu_flow)*coeff_flow(:, 1:NC); % using only the first NC PCs
    
    flow_test_PCA_recons = PCscores_test * coeff_flow(:,1:NC)' + mu_flow;
    
    MSE_PCA_test = sum((flow_test - flow_test_PCA_recons).^2,2);
    
    meanMSE_PCA_test(NC) = mean(MSE_PCA_test, "omitnan"); % !!! quantity of interest
end

% figure;plot(meanMSE_PCA_train,'.');hold on;plot(meanMSE_PCA_test,'.')

Fid = 1; % 2

if Fid == 1
    NC_flow = 2; % LF
else
    NC_flow = 5; % HF
end

PCscores_test = (flow_test - mu_flow)*coeff_flow(:, 1:NC_flow); % using only the first NC PCs

flow_test_PCA_recons = PCscores_test * coeff_flow(:,1:NC_flow)' + mu_flow;

figure(1);clf(1)
for j=1:10%n_test
    subplot(2,5,j);hold on
    plot(linspace(0,0.11,ntp),flow_test(j,:), '-','linewidth', 3)
    plot(linspace(0,0.11,ntp),flow_test_PCA_recons(j,:), '--','linewidth', 3)
end
legend('Original', 'Reconstructed')
title(sprintf('%d PCs', NC_flow))

%
%
%% Now emulate the PC scores for the GP training set with independent GPs for score(:,1:NC)

% settings for GP fitting
X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
n_r = size(X_r, 1);

l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
u_r = [1.5 ones(1,nd) 1];

% Initialisations for amplitude, lengthscale and likelihood noise for GP
% regression
H_r = [];
for j=1:nd+2
    H_r = [H_r, l_r(j) + (u_r(j)-l_r(j)) * X_r(:,j)];
end

x_regr = x_PCA;
%
%
%
% Flow
%
%
y_regr_flow = (flow_train - mu_flow)*coeff_flow(:, 1:NC_flow); % using only the first NC PCs

% Fit independent GPs for every PC score
for i=1:NC_flow
    mean_y_flow(i) = mean(y_regr_flow(:,i));
    std_y_flow(i) = std(y_regr_flow(:,i));
    
    % Scale y_regr
    y_regr_flow(:,i) = (y_regr_flow(:,i)-mean_y_flow(i))./std_y_flow(i); % mean 0 and std 1 of of y
    
    % Fit GP
    gp_regr_flow{i} = GPmodel(x_regr, y_regr_flow(:,i), H_r(2,:));
    
    [w,s] = gp_pak(gp_regr_flow{i});
    disp(exp(w))
    
    %Make predictions using gp_regr
    [E, Var] = gp_pred(gp_regr_flow{i}, x_regr, y_regr_flow(:,i), x_regr);
    
    figure(i); clf(i);
    plot(E,E,'-r','linewidth',2);hold on;
    plot(E, y_regr_flow(:,i), 'ob','markersize',6,'markerfacecolor',[0 0 1]);
    set(gca,'fontsize',20);grid on;
    xlabel('Train data'); ylabel('Predictions')
    
end

E = NaN(n_test, NC_flow);

for i=1:NC_flow
    % Make predictions of every PC score using gp models
    E(:,i) = gp_pred(gp_regr_flow{i}, x_regr, y_regr_flow(:,i), x_test);
end

flow_test_GP_recons = (E.*std_y_flow+mean_y_flow) * coeff_flow(:,1:NC_flow)' + mu_flow;
PCscores_test = (flow_test - mu_flow)*coeff_flow(:, 1:NC_flow); % using only the first NC PCs

figure(2);clf(2)
for i=1:NC_flow
    subplot(4,3,i)
    % Compare E (emulated test PC scores) to actual PCscores_test
    plot(E(:,i).*std_y_flow(i)+mean_y_flow(i), PCscores_test(:,i), '.r', 'Markersize', 20)
    hold on;
    plot(E(:,i).*std_y_flow(i)+mean_y_flow(i),E(:,i).*std_y_flow(i)+mean_y_flow(i), '--k', 'linewidth',2)
    xlabel('Emulated test PC scores');ylabel('Actual test PC scores')
end

prediction = flow_test_GP_recons;
data = flow_test;
figure;
for k=1:100%n_test
    subplot(10,10,k);
    plot(data(k,:),'-k');hold on;plot(prediction(k,:),'-r');
end


if Fid==1 % 2 PCs
    save('GP_PCA_Emulator_LF_5D.mat')
else % 5 PCs
    save('GP_PCA_Emulator_HF_5D.mat')
end