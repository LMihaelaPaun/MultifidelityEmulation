% main script to run optimisation with a gradient-free algorithm for 2 emulators:
% high-fidelity and low-fidelity

clear; close all

% add path to the original GPstuff toolbox
addpath(genpath('/GPstuff-4.7'))

addpath('/CommonFunctions')

%% Generate inference data
% Run code (once only!) to obtain txt files to be used by the C++ code
CppSettings()

% Set some quantities

% no of time points in the time series
ntp = 512;

% no of vessels we use data for inference from
nv = 9;

nd = 5; % no of parameters

% Generate 300 data sets

X = sobolset(nd, 'Skip',2e13,'Leap',0.3e14);

nDS = size(X,1);

thetaStar = NaN(nDS,nd);

l = [-45 2*10^5 -45 2*10^5 0.85];
u = [-25 9*10^5 -25 9*10^5 0.94];

for i=1:nd
    thetaStar(:,i) = l(i) + (u(i)-l(i)) * X(1:nDS,i);
end

generateInferenceData = 0; % 0: no, because it's already been generated, 1: yes

if generateInferenceData == 1
    GetInferenceData(thetaStar, extra_p)
else
    load('/SimulatorsMultifidelity/SystemicModel/InferenceData_Sys.mat')
end

%% Generate theta and fs(theta) for building classifier

generateClassifData = 0; % 0: no, because it's already been generated, 1: yes

if generateClassifData== 1
    X = sobolset(nd, 'Skip',2e11,'Leap',0.901e13);

    nTheta = size(X,1);

    theta = NaN(nTheta,nd);

    for i=1:nd
        theta(:,i) = l(i) + (u(i)-l(i)) * X(1:nTheta,i);
    end

    GP_type = 2; % GP-PCA

    extra_p = {l, u, sc, GP_type, ntp, nv};

    GetClassificationData(theta, extra_p);

end

% load PCA emulators
load('/home/staff3/mpaun/CompetitionModels/SimulatorsMultifidelity/SystemicModel/GP_PCA_Emulator_HF_5D.mat')
% LF is just a subset of HF (first two PCs out of 5PCs), so it will automatically get loaded

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
ErrorSimSpace = NaN(nDS,2);
ErrorParSpace = NaN(nDS,2);

parpool('local', 48)

for iDS=1:nDS


    %% run optimisation

    NC_flow_fid = [2,5]; % LF model: 2 PCs, HF model: 5 PCs

    trueFlow = SimFlow_thetaStar(iDS,:);

    % different initialisations
    Xinit = sobolset(nd, 'Skip',2e12,'Leap',0.183e15);

    ninit = size(Xinit,1);

    par0 = NaN(ninit,nd);

    for i=1:nd
        par0(:,i) = l(i) + (u(i)-l(i)) * Xinit(1:ninit,i);
    end

    % compare to true theta
    WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));

    % HF model
    switchEm = 2; % 2: do not switch, use HF emulator only

    HF = 1;

    extra_p = {gp_regr_flow,x_regr,y_regr_flow,NC_flow_fid,coeff_flow,mu_flow,...
        mean_y_flow,std_y_flow,switchEm,HF,mdl,l,u,sc};

    parfor i = 1:48%ninit
        % original algorithm
        history(i) = GradientFreeAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, trueFlow, extra_p);
    end


    parfor i=1:48

        [~, clean_flowData] = Run_fluidsModel(history(i).x(end,:) .*sc, 1000+iDS+i, nv, ntp);

        FlowALL{i} = clean_flowData(:,1); % first flow only;

        OFALL(i) = sum((trueFlow-(FlowALL{i})').^2);

    end

    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;

    if switchEm==1
        FinalXvalue_switch = FinalXvalue; FinalYvalue_switch = min(OFALL);
    else
        FinalXvalue_HF = FinalXvalue; FinalYvalue_HF = min(OFALL);
    end

    ErrorSimSpace(iDS,1) = OFALL(Idx);
    ErrorParSpace(iDS,1) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);

    % Now also run for LF model
    switchEm = 2; % do not switch between emulators
    HF = 0; % use LF
    % update extra_p
    extra_p = {gp_regr_flow,x_regr,y_regr_flow,NC_flow_fid,coeff_flow,mu_flow,...
        mean_y_flow,std_y_flow,switchEm,HF,mdl,l,u,sc};

    parfor i = 1:48%ninit
        history(i) = GradientFreeAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, trueFlow, extra_p);
    end

    parfor i=1:48

        [~, clean_flowData] = Run_fluidsModel(history(i).x(end,:) .*sc, 1000+iDS+i, nv, ntp);

        FlowALL{i} = clean_flowData(:,1); % first flow only;

        OFALL(i) = sum((trueFlow-(FlowALL{i})').^2);

    end

    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;

    FinalXvalue_LF = FinalXvalue; FinalYvalue_LF = min(OFALL);

    ErrorSimSpace(iDS,2) = OFALL(Idx);
    ErrorParSpace(iDS,2) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);

    % HF: ErrorSimSpace(iDS,1)
    % LF: ErrorSimSpace(iDS,2)

end