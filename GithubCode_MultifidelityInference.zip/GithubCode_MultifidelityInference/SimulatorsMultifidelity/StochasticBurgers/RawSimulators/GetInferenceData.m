function GetInferenceData(thetaStar, extra_p) 
%% ================================================================
% Get inference data sets
% ================================================================

ntp = extra_p{2};

nDS = size(thetaStar, 1);

SimData_thetaStar = NaN(nDS,ntp);

delete(gcp('nocreate'))
parpool('local', 48)

parfor iDS=1:nDS
    
    [SimData_thetaStar(iDS,:), ok_SimData(iDS)] = SimulatorBurgers( ...
        thetaStar(iDS,:), extra_p);
    
    if ~ok_SimData(iDS) % it gets populated with NaNs
        fprintf('  REF inference data failed for dataset %d. \n', iDS);
        
    end
    
end

%% Save inference data

save('/SimulatorsMultifidelity/StochasticBurgers/RawSimulators/InferenceData_Burgers.mat', 'SimData_thetaStar')

end