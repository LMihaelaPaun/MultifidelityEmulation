% main script to run optimisation with a gradient-free algorithm for the multifidelity emulator
clear; close all

% add path to the original GPstuff toolbox
addpath('/CommonFunctions')

addpath(genpath('/GPstuff-4.7'))

%% Generate inference (thetaStar and fs(thetaStar)) data
% space resolution for Fourier
N_highInference = 60; % inference data will be generated with this highest resolution for Fourier

N_LF  = 18; % this resolution will define the LF model
N_HF  = 20; % this resolution will define the HF model

% no of time points in the time series
ntp = 256;

nd = 2; % no of parameters

% some (non-inference) parameters for the Burgers differential eq
nu = 0.5;
T  = 1.0;

%% Generate (300) inference data sets

X = sobolset(nd, 'Skip',2e13,'Leap',0.3e14);

nDS = size(X,1);

thetaStar = NaN(nDS,nd);

l = [-sqrt(3), -sqrt(3)];
u = [sqrt(3), sqrt(3)];
sc = [1, 1];

for i=1:nd
    thetaStar(:,i) = l(i) + (u(i)-l(i)) * X(1:nDS,i);
end

extra_p = {N_highInference, ntp, nu, T};

generateInferenceData = 0; % 0: no, because it's already been generated, 1: yes

if generateInferenceData == 1
    GetInferenceData(thetaStar, extra_p)
else
    load('/SimulatorsMultifidelity/StochasticBurgers/RawSimulators/InferenceData_Burgers.mat')
end

%% Generate theta and fs(theta) for building classifier

generateClassifData = 0; % 0: no, because it's already been generated, 1: yes

if generateClassifData== 1

    X = sobolset(nd, 'Skip',2e11,'Leap',0.901e13);

    nTheta = size(X,1);

    theta = NaN(nTheta,nd);

    for i=1:nd
        theta(:,i) = l(i) + (u(i)-l(i)) * X(1:nTheta,i);
    end

    extra_p = {N_highInference, ntp, nu, T, l, u};

    GetClassificationData(theta, extra_p);

end

%% ================================================================
% Predictive accuracy checks: HF always better predictive performance than LF
%% ================================================================
extra_p_LF = {N_LF, ntp, nu, T};
extra_p_HF = {N_HF, ntp, nu, T};

for iDS = 1:nDS

    predictions_LF(iDS,:) = SimulatorBurgers(thetaStar(iDS,:), extra_p_LF);

    predictions_HF(iDS,:) = SimulatorBurgers(thetaStar(iDS,:), extra_p_HF);

end

dev_LF = sum((SimData_thetaStar(1:nDS,:)-predictions_LF).^2,2);
dev_HF = sum((SimData_thetaStar(1:nDS,:)-predictions_HF).^2,2);
%

sum(dev_LF<dev_HF) % has to be zero

if sum(dev_LF<dev_HF) ~= 0
    warning('Some LF predictive errors lower than HF predictive errors')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
ErrorSimSpace = NaN(nDS,1);
ErrorParSpace = NaN(nDS,1);

PercGoodCases = NaN(nDS,1);
KNNcorrectClassifRate = NaN(nDS,1);

delete(gcp('nocreate'))
parpool('local', 48)

for iDS=1:nDS

    trueData = SimData_thetaStar(iDS,:);

    [mdl,PercGoodCases(iDS),KNNcorrectClassifRate(iDS)] = BuildClassifier(trueData);

    %% Next run optimisation
    % different initialisations
    Xinit = sobolset(nd, 'Skip',2e12,'Leap',0.183e15);

    ninit = size(Xinit,1);

    par0 = NaN(ninit,nd);

    for i=1:nd
        par0(:,i) = l(i) + (u(i)-l(i)) * Xinit(1:ninit,i);
    end

    % compare to true theta
    WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));

    %% MF (average)
    clear history OFALL data ok

    extra_p = {mdl,l,u,sc};

    parfor i = 1:48%ninit
        % algorithm adapted for multifidelity inference
        history(i) = GradientFreeAlgorithm_MFsimulator_SimHFLF_averageOF(...
            par0(i,:)./sc, trueData, extra_p, extra_p_LF, extra_p_HF);
    end

    extra_p = {N_highInference,ntp,nu,T};

    parfor i=1:48

        [data(i,:), ok(i)] = SimulatorBurgers(history(i).x(end,:) .* sc, extra_p);

        if ~ok(i)

            fprintf('  REF data failed from MF optimisation for parameter set %d. \n', i);

            OFALL(i) = 10^10;

        else

            OFALL(i) = sum((trueData-data(i,:)).^2);

        end
    end

    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue_MF(iDS,:) = history(Idx).x(end,:) .*sc;

    ErrorSimSpace(iDS,1) = OFALL(Idx);
    ErrorParSpace(iDS,1) = WRMSE_par(thetaStar(iDS,:),FinalXvalue_MF(iDS,:));

  
    save('InferenceErrors_HFLFsimulators_onlyMFdifferent_averageOF.mat')

end

exit;
