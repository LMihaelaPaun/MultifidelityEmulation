function GetClassificationData(theta, extra_p)
%% ================================================================
% STEP 1: Build common stencil parameter space and evaluate REF/LF/HF data
% This does not depend on iDS.
% ================================================================

N_highInference = extra_p{1};
N_LF = extra_p{2};
N_HF = extra_p{3};
ntp = extra_p{4};
nu = extra_p{5};
T = extra_p{6};
l = extra_p{7};
u = extra_p{8};

extra_p_sim = {N_highInference, ntp, nu, T}; % needed when calling the (REF) simulator
extra_p_LF = {N_LF, ntp, nu, T}; % needed when calling the LF simulator
extra_p_HF = {N_HF, ntp, nu, T}; % needed when calling the HF simulator

%% Build local stencil around every theta point

[nTheta, nd] = size(theta);

hFrac = 0.02;          % 2% of each parameter range
h = hFrac * (u - l);   % 1 x nd

nStencil = 1 + 2*nd;   % for nd=4, nStencil=9

ThetaStencil = NaN(nTheta, nStencil, nd);

for j = 1:nTheta
    
    theta0 = theta(j,:);
    
    stencil = theta0;
    
    for d = 1:nd
        
        theta_plus = theta0;
        theta_minus = theta0;
        
        theta_plus(d)  = min(theta0(d) + h(d), u(d));
        theta_minus(d) = max(theta0(d) - h(d), l(d));
        
        stencil = [stencil; theta_plus; theta_minus];
        
    end
    
    ThetaStencil(j,:,:) = stencil;
    
end

ThetaStencilFlat = reshape(ThetaStencil, nTheta*nStencil, nd);
nTotal = size(ThetaStencilFlat,1);

%% Preallocate output data

REFData_classif_stencil = NaN(nTotal, ntp);
LFData_classif_stencil  = NaN(nTotal, ntp);
HFData_classif_stencil  = NaN(nTotal, ntp);

%% Evaluate REF, LF, HF outputs at all stencil points

parfor i = 1:nTotal
    
    param = ThetaStencilFlat(i,:);
    
    %% REF model: Simulator
    dataREF = SimulatorBurgers(param, extra_p_sim); % param on original scale
    REFData_classif_stencil(i,:) = dataREF;
    
    %% LF simulator
    dataLF = SimulatorBurgers(param, extra_p_LF); % param on original scale
    LFData_classif_stencil(i,:) = dataLF;
    
    %% HF simulator
    dataHF = SimulatorBurgers(param, extra_p_HF); % param on original scale
    HFData_classif_stencil(i,:) = dataHF;
    
end

%% Reshape back to nTheta x nStencil x ntp

REFData_classif_stencil = reshape(REFData_classif_stencil, nTheta, nStencil, ntp);
LFData_classif_stencil  = reshape(LFData_classif_stencil,  nTheta, nStencil, ntp);
HFData_classif_stencil  = reshape(HFData_classif_stencil,  nTheta, nStencil, ntp);

%% Save common data

save('/SimulatorsMultifidelity/StochasticBurgers/RawSimulators/ClassifierStencilModelData_Burgers.mat')

end