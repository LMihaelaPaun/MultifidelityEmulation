function OptimHistory = GradientFreeAlgorithm_MFsimulator_SimHFLF(param0, ...
    trueData, extra_p, extra_p_LF, extra_p_HF)
% this is a gradient-free optimiser that is adapted for multifidelity
% inference when the LF and HF models are approximations to a REFERECE
% model

mdl = extra_p{1};
l = extra_p{2};
u = extra_p{3};
sc = extra_p{4};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization

% gradient-free optimiser
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-20, 'TolX',1e-20, ...
%'MaxFunEvals',1000, 'MaxIter', 1000);

[x,fval] = fminsearchbndTEST(@(x)GetObjFct(x), param0, l./sc, u./sc, options);


    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
        %
        ObjFctEach = NaN(2,1); % 1: LF, 2: HF
        
        % LF
        [data_LF, ok_LF] = SimulatorBurgers(param, extra_p_LF); data_LF = data_LF';
        
        if ok_LF

            r_data_LF = trueData - data_LF;
            ObjFctEach(1) = sum(r_data_LF.^2,2);
        else

            ObjFctEach(1) = 10^10;
        end

        % HF
        [data_HF, ok_HF] = SimulatorBurgers(param, extra_p_HF); data_HF = data_HF';

        if ok_HF
            r_data_HF = trueData - data_HF;
            ObjFctEach(2) = sum(r_data_HF.^2,2);

        else

            ObjFctEach(2) = 10^10;
        end

        label = predict(mdl,param.*sc); % label=1 if HF and label=0 if LF
        
        % in this exact order: OF_LF, OF_HF, label;
        % if label=1, choose ObjFct(label+1); if label=0, choose ObjFct(label+1), so always choose ObjFct(label+1)
        ObjFct = [ObjFctEach(1),ObjFctEach(2),label];
        
    end
end