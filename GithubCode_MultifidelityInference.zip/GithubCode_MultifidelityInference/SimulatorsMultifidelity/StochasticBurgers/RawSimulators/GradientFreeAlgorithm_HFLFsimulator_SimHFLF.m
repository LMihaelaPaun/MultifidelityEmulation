function OptimHistory = GradientFreeAlgorithm_HFLFsimulator_SimHFLF(param0, trueData, extra_p, extra_p_F)
% this is a gradient-free optimiser, only works for HF or LF simulators

l = extra_p{1};
u = extra_p{2};
sc = extra_p{3};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient-free

% gradient-free optimiser (these low tolerances are needed for the
% sinusoidal example, for the other examples we have used default 10^(-6))
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-20, 'TolX',1e-20, ...
% 'MaxFunEvals',1000, 'MaxIter', 1000);

[x,fval] = fminsearchbnd(@(x)GetObjFct(x), param0, l./sc, u./sc, options);

    function stop = outfun(x,optimValues,state)

        stop = false;

        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];

                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far

            case 'done'
                hold off
            otherwise
        end

    end

    function ObjFct = GetObjFct(param)
        % Get objective function

        [data, ok] = SimulatorBurgers(param, extra_p_F); data = data';

        if ok

            r_data = trueData - data;

            % RSS
            ObjFct = sum(r_data.^2,2);

        else

            ObjFct = 10^10;

        end

    end
end