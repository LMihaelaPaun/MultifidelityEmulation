function OptimHistory = GradientAlgorithm_HFLFsimulator_SimHFLF(param0, trueData, extra_p, extra_p_F)
% this is a gradient-based optimiser, only works for HF or LF simulators

l = extra_p{1};
u = extra_p{2};
sc = extra_p{3};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient based method (sqp algorithm)
    
% sqp (gradient-based) optimiser
options=optimoptions('fmincon', 'Display','iter', 'Algorithm','sqp', ...
    'OutputFcn',@outfun, ...
    'StepTolerance',  1.0000e-6, 'OptimalityTolerance', 1.0000e-6, ...
    'ConstraintTolerance', 1.0000e-6, 'FiniteDifferenceType', 'central',...
    'MaxFunctionEvaluations',1000);

% % interior-point (gradient-based) optimiser -> this gives worse results than sqp
% options=optimoptions('fmincon', 'Display','iter', 'Algorithm','interior-point', ...
%     'OutputFcn',@outfun, ...
%     'StepTolerance',  1.0000e-6, 'OptimalityTolerance', 1.0000e-6, ...
%     'ConstraintTolerance', 1.0000e-6, 'FiniteDifferenceType', 'central',...
%     'MaxFunctionEvaluations',1000);

[x,fval] = fmincon(@(x)GetObjFct(x), ...
    param0, [], [], [], [], l./sc, u./sc, [], options);

    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];

                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function

        [data, ok] = SimulatorBurgers(param, extra_p_F); data = data';

        if ok
            
            r_data = trueData - data;

            % RSS
            ObjFct = sum(r_data.^2,2);

        else

            ObjFct = 10^10;

        end

    end
end