function ObjFct = GetRSS_fid(param, trueData, extra_p)

% param is on original scale already

nTheta = extra_p{1};
N_fid = extra_p{2};
nu = extra_p{3};
T = extra_p{4};
ntp = extra_p{5};

ObjFct = NaN(1,nTheta);

for i=1:nTheta
    
[~, prediction, ok] = solve_burgers_fourier_common_grid( ...
    N_fid, param(i,1), param(i,2), nu, T, ntp);

prediction = prediction';

if ~ok || any(~isfinite(prediction))
    ObjFct(i) = 10^10;
else
    r = trueData - prediction;
    ObjFct(i) = sum(r.^2,2);
end

end

end
