function [u_out,ok] = SimulatorBurgers(param, extra_p)
%% Solve stochastic Burgers equation at spectral resolution N,
%% then interpolate solution to common grid ntp.

xi1 = param(1);
xi2 = param(2);

N = extra_p{1};
ntp = extra_p{2};
nu = extra_p{3};
T = extra_p{4};

ok = true;
u_out = nan(ntp,1);

L = 2*pi;
x = L*(0:N-1)'/N;
x_out = L*(0:ntp-1)'/ntp;

try
    k = fourier_wavenumbers(N);
    
    %% Random initial condition
    u0 = 1 + xi1*sin(x) + xi2*cos(x);
    
    uhat0 = fft(u0);
    
    rhs = @(t,uhat) burgers_rhs(t, uhat, k, x, nu);
    
    opts = odeset( ...
        'RelTol', 1e-8, ...
        'AbsTol', 1e-10);
    
    lastwarn('');
    [tout, uhat_sol] = ode45(rhs, [0 T], uhat0, opts);
    warn_msg = lastwarn;
    
    if ~isempty(warn_msg) || tout(end) < T
        ok = false;
        return;
    end
    
    uhat_final = uhat_sol(end,:).';
    
    %% Original-grid solution
    u_final = real(ifft(uhat_final));
    
    %% Common-grid spectral interpolation
    u_out = spectral_interp_periodic(u_final, ntp);
    
    if any(~isfinite(u_out))
        ok = false;
    end
    
catch
    ok = false;
end


    function duhatdt = burgers_rhs(t, uhat, k, x, nu)
        
        %% PDE:
        %% u_t + u u_x = nu u_xx + f(x,t)
        
        u  = real(ifft(uhat));
        ux = real(ifft(1i*k.*uhat));
        
        uxx_hat = -(k.^2).*uhat;
        
        nonlinear = u .* ux;
        
        %% Forcing term
        f = 8*sin(10*x)*sin(5*t) + ...
            8*cos(7*x)*exp(-sin(t));
        
        rhs_phys = -nonlinear + real(ifft(nu*uxx_hat)) + f;
        
        duhatdt = fft(rhs_phys);
    end


    function k = fourier_wavenumbers(N)
        
        %% MATLAB FFT ordering for periodic domain [0, 2*pi)
        
        if mod(N,2)==0
            k = [0:N/2-1 0 -N/2+1:-1]';
        else
            k = [0:(N-1)/2 -(N-1)/2:-1]';
        end
    end


    function u_fine = spectral_interp_periodic(u_coarse, ntp)
        
        %% Spectral interpolation by Fourier zero-padding.
        %% Input signal is assumed periodic.
        
        N = length(u_coarse);
        
        if ntp < N
            error('ntp must be >= N.');
        end
        
        uhat = fft(u_coarse);
        uhat_fine = zeros(ntp,1);
        
        if mod(N,2)==0
            
            n2 = N/2;
            
            %% Positive modes excluding Nyquist
            uhat_fine(1:n2) = uhat(1:n2);
            
            %% Split Nyquist mode
            uhat_fine(n2+1) = uhat(n2+1)/2;
            uhat_fine(ntp-n2+1) = uhat(n2+1)/2;
            
            %% Negative modes
            uhat_fine(ntp-n2+2:end) = uhat(n2+2:end);
            
        else
            
            n2 = floor(N/2);
            
            %% Positive modes including zero
            uhat_fine(1:n2+1) = uhat(1:n2+1);
            
            %% Negative modes
            uhat_fine(ntp-n2+1:end) = uhat(n2+2:end);
            
        end
        
        %% Correct FFT scaling after zero-padding
        u_fine = real(ifft(uhat_fine)) * (ntp/N);
    end

end