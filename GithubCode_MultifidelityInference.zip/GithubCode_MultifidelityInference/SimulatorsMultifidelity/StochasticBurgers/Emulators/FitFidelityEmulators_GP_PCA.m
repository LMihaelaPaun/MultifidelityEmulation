%% Fit GP-PCA emulators for Burgers LF and HF models
% Builds independent GPs for the first 6 PC scores because they explain
% over 99% of the variance
%
% Output files:
%   GP_PCA_Emulator_LF.mat
%   GP_PCA_Emulator_HF.mat

clear; close all;

addpath('/CommonFunctions')
addpath(genpath('/GPstuff-4.7'))

%% Problem settings

nd = 2;

% Parameter bounds for xi1, xi2
l = [-sqrt(3), -sqrt(3)];
u = [ sqrt(3),  sqrt(3)];

sc = [1, 1];

% Burgers solver settings
% space resolution for Fourier
N_LF  = 18; % this resolution will define the LF model
N_HF  = 20; % this resolution will define the HF model

nu = 0.5;
T = 1;     
ntp = 256;

extra_p_LF = {N_LF, ntp, nu, T};
extra_p_HF = {N_HF, ntp, nu, T};

NC = 6;        % number of PCs for both LF and HF

n_candidate = 2000;     % total Sobol candidates
n_train_target = 1000;  % desired training size

%% Generate candidate Sobol parameter points

X = sobolset(nd, 'Skip',2e12,'Leap',4.504e12);

theta_candidate = NaN(n_candidate, nd);

for d = 1:nd
    theta_candidate(:,d) = l(d) + (u(d)-l(d)) * X(:,d);
end

%% Run LF and HF models and keep only points where both succeed

theta_valid = NaN(n_candidate, nd);
Y_LF_valid  = NaN(n_candidate, ntp);
Y_HF_valid  = NaN(n_candidate, ntp);

ok_common = false(n_candidate,1);

for i = 1:n_candidate

    [dataLF, okLF] = SimulatorBurgers(theta_candidate(i,:), extra_p_LF);

    [dataHF, okHF] = SimulatorBurgers(theta_candidate(i,:), extra_p_HF);

    if okLF && okHF && all(isfinite(dataLF)) && all(isfinite(dataHF))

        theta_valid(i,:) = theta_candidate(i,:);
        Y_LF_valid(i,:)  = dataLF(:)';
        Y_HF_valid(i,:)  = dataHF(:)';

        ok_common(i) = true;
    end
end

theta_valid = theta_valid(ok_common,:);
Y_LF_valid  = Y_LF_valid(ok_common,:);
Y_HF_valid  = Y_HF_valid(ok_common,:);

nValid = size(theta_valid,1);

%% Train/test split
% Keep training at 1000 if possible.
% Any failed points are effectively removed from the test set first.

n_train = n_train_target;
n_test  = nValid - n_train;

fprintf('Using %d training points and %d test points.\n', n_train, n_test);

x_train = theta_valid(1:n_train,:);
data_LF_train = Y_LF_valid(1:n_train,:);
data_HF_train = Y_HF_valid(1:n_train,:);

if n_test > 0
    x_test = theta_valid(n_train+1:end,:);
    data_LF_test = Y_LF_valid(n_train+1:end,:);
    data_HF_test = Y_HF_valid(n_train+1:end,:);
else
    x_test = [];
    data_LF_test = [];
    data_HF_test = [];
    warning('No test points left after keeping 1000 training points.');
end

%% Fit LF emulator

Fid = 1;
data_train = data_LF_train;
data_test  = data_LF_test;

fit_and_save_GP_PCA_burgers_emulator(Fid, x_train, data_train, x_test, data_test, NC, nd)

%% Fit HF emulator

Fid = 2;
data_train = data_HF_train;
data_test  = data_HF_test;

fit_and_save_GP_PCA_burgers_emulator(Fid, x_train, data_train, x_test, data_test, NC, nd)

