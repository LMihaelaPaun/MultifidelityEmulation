function OptimHistory = GradientFreeAlgorithm_fidelity(param0, trueData, extra_p)
% this is a gradient-free optimiser, works for HF or LF simulators

l = extra_p{1};
u = extra_p{2};
sc = extra_p{3};
N_fid = extra_p{4};
nu = extra_p{5};
T = extra_p{6};
ntp = extra_p{7};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient-free

% gradient-free optimiser
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-6, 'TolX',1e-6);

[x,fval] = fminsearchbnd(@(x)GetObjFct(x), param0, l./sc, u./sc, options);

    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
        
        [~, prediction, ok] = solve_burgers_fourier_common_grid( ...
            N_fid, param(1)*sc(1), param(2)*sc(2), nu, T, ntp);
        
        prediction = prediction';
        
        if ~ok || any(~isfinite(prediction))
            ObjFct(1) = 10^10;
        else
            r = trueData - prediction;
            ObjFct(1) = sum(r.^2, 2);
        end
        
    end
end