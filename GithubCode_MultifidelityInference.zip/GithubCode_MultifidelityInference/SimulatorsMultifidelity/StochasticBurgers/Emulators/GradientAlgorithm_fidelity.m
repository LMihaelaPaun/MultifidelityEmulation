function OptimHistory = GradientAlgorithm_fidelity(param0, trueData, extra_p)

l = extra_p{1};
u = extra_p{2};
sc = extra_p{3};
N_fid = extra_p{4};
nu = extra_p{5};
T = extra_p{6};
ntp = extra_p{7};

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization with gradient based method (sqp algorithm)

% sqp (gradient-based) optimiser
options=optimoptions('fmincon', 'Display','iter', 'Algorithm','sqp', ...
    'OutputFcn',@outfun, ...
    'StepTolerance',  1.0000e-6, 'OptimalityTolerance', 1.0000e-6, ...
    'ConstraintTolerance', 1.0000e-6, 'FiniteDifferenceType', 'central',...
    'MaxFunctionEvaluations',1000);

% % interior-point (gradient-based) optimiser -> this gives worse results than sqp
% options=optimoptions('fmincon', 'Display','iter', 'Algorithm','interior-point', ...
%     'OutputFcn',@outfun, ...
%     'StepTolerance',  1.0000e-6, 'OptimalityTolerance', 1.0000e-6, ...
%     'ConstraintTolerance', 1.0000e-6, 'FiniteDifferenceType', 'central',...
%     'MaxFunctionEvaluations',1000);

[x,fval] = fmincon(@(x)GetObjFct(x), ...
    param0, [], [], [], [], l./sc, u./sc, [], options);

    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function
        
        [~, prediction, ok] = solve_burgers_fourier_common_grid( ...
            N_fid, param(1)*sc(1), param(2)*sc(2), nu, T, ntp);
        
        prediction = prediction';
        
        if ~ok || any(~isfinite(prediction))
            ObjFct(1) = 10^10;
        else
            r = trueData - prediction;
            ObjFct(1) = sum(r.^2, 2);
        end
        
    end

end