function OptimHistory = GradientFreeAlgorithm_multifidelityModel(param0, trueData, extra_p)
% this is a gradient-free optimiser that is adapted for multifidelity
% inference; it is the equivalent of
% "GradientFreeAlgorithm_emulator_weightedSumMOO_discrepTEST" for the
% emulator versions of fidelity models

mdl = extra_p{1};
l = extra_p{2};
u = extra_p{3};
sc = extra_p{4};
N_LF = extra_p{5}; 
N_HF = extra_p{6};
nu = extra_p{7}; 
T = extra_p{8};
ntp = extra_p{9}; 

% Set up shared variables with OUTFUN
OptimHistory.x = [];
OptimHistory.fval = [];

%% Contrained optimization

% gradient-free optimiser
options=optimset('OutputFcn',@outfun);%, 'TolFun',1e-6, 'TolX',1e-6);

[x,fval] = fminsearchbndTEST(@(x)GetObjFct(x), param0, l./sc, u./sc, options);


    function stop = outfun(x,optimValues,state)
        
        stop = false;
        
        switch state
            case 'init'
                hold on
            case 'iter'
                % Concatenate current point and objective function value with history
                % x must be a row vector
                OptimHistory.fval = [OptimHistory.fval; optimValues.fval];
                %                 OptimHistory.fval = [OptimHistory.fval; optimValues.resnorm]; % for lsqnonlin
                OptimHistory.x = [OptimHistory.x; x];
                
                %save(sprintf('historySQPoptimisation %d.mat',irun)) % save the progress so far
                
            case 'done'
                hold off
            otherwise
        end
        
    end

    function ObjFct = GetObjFct(param)
        % Get objective function - this is what needs changing when we
        % define the fidelity models differently from emulators
        
        ObjFctEach = NaN(2,1);
        
        % Objective minimized during inference: RSS between inference data and LF/HF prediction.
        
        [~, prediction_LF, ok_LF] = solve_burgers_fourier_common_grid( ...
            N_LF, param(1)*sc(1), param(2)*sc(2), nu, T, ntp);
        
        prediction_LF = prediction_LF';

        if ~ok_LF
            disp('wrong')
            ObjFctEach(1) = 10^10;
        else
            r = trueData - prediction_LF;
            ObjFctEach(1) = sum(r.^2, 2);
        end
        
        [~, prediction_HF, ok_HF] = solve_burgers_fourier_common_grid( ...
            N_HF, param(1)*sc(1), param(2)*sc(2), nu, T, ntp);
        
        prediction_HF = prediction_HF';
        
        if ~ok_HF
            ObjFctEach(2) = 10^10;
        else
            r = trueData - prediction_HF;
            ObjFctEach(2) = sum(r.^2, 2);
        end
        
        % during optimisation, we will do switching based on KNN prediction of label
        
        label = predict(mdl,param.*sc); % label=1 if HF and label=0 if LF
        
        ObjFct = [ObjFctEach(1),ObjFctEach(2),label]; % OF_LF, OF_HF, label; if label=1, choose ObjFct(label+1); if label=0, choose ObjFct(label+1), so always choose ObjFct(label+1)
        
        
    end
end