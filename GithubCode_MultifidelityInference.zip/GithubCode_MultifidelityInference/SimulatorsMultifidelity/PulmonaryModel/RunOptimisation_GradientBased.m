% main script to run optimisation with a gradient-based algorithm for 3 emulators:
% high-fidelity, low-fidelity and objective function, and gradient-free for
% multifidelity

clear; close all

% add path to the original GPstuff toolbox
addpath(genpath('/GPstuff-4.7'))

addpath('/CommonFunctions')

%% Set some quantities

ntp = 512; % no of time points in the multivariate output

num_ves = 27;   % Number of large vessels in the tree

art     = 1:15; % Arteries
ven     = 16:27;% Veins

%% generate fs(thetaStar): the inference data
% Generate true data: 300 data sets

nd = 4; % no of model parameters

X = sobolset(nd, 'Skip',2e13,'Leap',0.3e14);

nDS = size(X,1);

thetaStar = NaN(nDS,nd);

l = [9e4 0.83 20 20];
u = [3e5 0.89 50 50];

sc = max(abs(l),abs(u));

for i=1:nd
    thetaStar(:,i) = l(i) + (u(i)-l(i)) * X(1:nDS,i);
end


generateInferenceData = 0; % 0: no, because it's already been generated, 1: yes

if generateInferenceData == 1
    GetInferenceData(thetaStar, extra_p)
else
    load('/SimulatorsMultifidelity/PulmonaryModel/InferenceData_Pulm.mat')
end

%% Generate theta and fs(theta) for building classifier

generateClassifData = 0; % 0: no, because it's already been generated, 1: yes

if generateClassifData== 1
    X = sobolset(nd, 'Skip',2e11,'Leap',0.901e13);
    
    nTheta = size(X,1);
    
    theta = NaN(nTheta,nd);
    
    for i=1:nd
        theta(:,i) = l(i) + (u(i)-l(i)) * X(1:nTheta,i);
    end
    
    GP_type = 2; % GP-PCA
    
    extra_p = {l, u, sc, GP_type, ntp, num_ves, art, ven};
    
    GetClassificationData(theta, extra_p);
    
end

% load PCA emulators
load('/SimulatorsMultifidelity/PulmonaryModel/GP_PCA_Emulator_HF_4D.mat')
% LF is just a subset of HF (first two PCs out of 5PCs), so it will automatically get loaded

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
ErrorSimSpace = NaN(nDS,2);
ErrorParSpace = NaN(nDS,2);

delete(gcp('nocreate'))
parpool('local', 48)

for iDS=1:nDS


    %% run optimisation

    NC_pressure_fid = [2,5]; %LF model: 2 PCs, HF model: 5 PCs

    truePressure = SimPressure_thetaStar(iDS,:);

    % different initialisations
    Xinit = sobolset(nd, 'Skip',2e12,'Leap',0.183e15);

    ninit = size(Xinit,1);

    par0 = NaN(ninit,nd);

    for i=1:nd
        par0(:,i) = l(i) + (u(i)-l(i)) * Xinit(1:ninit,i);
    end

    % compare to true theta
    WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));

    % HF model
    switchEm = 2; % 2: do not switch, use HF emulator only

    HF = 1;

    extra_p = {gp_regr_pressure,x_regr,y_regr_pressure,NC_pressure_fid,coeff_pressure,mu_pressure,...
        mean_y_pressure,std_y_pressure,switchEm,HF,mdl,l,u,sc};

    parfor i = 1:48%ninit
        % original algorithm
        history(i) = GradientAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, truePressure, extra_p);
    end


    parfor i=1:48

        clean_pressureData = Run_fluidsModel(history(i).x(end,:) .*sc, iDS+i, num_ves, art, ven, ntp);

        PressureALL{i} = clean_pressureData; % first pressure only;

        OFALL(i) = sum((truePressure-(PressureALL{i})').^2);

    end

    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;

    if switchEm==1
        FinalXvalue_switch = FinalXvalue; FinalYvalue_switch = min(OFALL);
    else
        FinalXvalue_HF = FinalXvalue; FinalYvalue_HF = min(OFALL);
    end

    ErrorSimSpace(iDS,1) = OFALL(Idx);
    ErrorParSpace(iDS,1) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);


    % Now also run for LF model
    switchEm = 2; % do not switch between emulators
    HF = 0; % use LF
    % update extra_p
    extra_p = {gp_regr_pressure,x_regr,y_regr_pressure,NC_pressure_fid,coeff_pressure,mu_pressure,...
        mean_y_pressure,std_y_pressure,switchEm,HF,mdl,l,u,sc};

    parfor i = 1:48%ninit
        history(i) = GradientAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, truePressure, extra_p);
    end

    parfor i=1:48

        clean_pressureData = Run_fluidsModel(history(i).x(end,:) .*sc, iDS+i, num_ves, art, ven, ntp);

        PressureALL{i} = clean_pressureData; % first pressure only;

        OFALL(i) = sum((truePressure-(PressureALL{i})').^2);

    end

    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;

    FinalXvalue_LF = FinalXvalue; FinalYvalue_LF = min(OFALL);

    ErrorSimSpace(iDS,2) = OFALL(Idx);
    ErrorParSpace(iDS,2) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);

    % HF: ErrorSimSpace(iDS,1)
    % LF: ErrorSimSpace(iDS,2)

end
