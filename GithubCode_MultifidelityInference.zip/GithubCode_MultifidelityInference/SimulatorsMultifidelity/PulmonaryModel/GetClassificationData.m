function GetClassificationData(theta, extra_p) 
%% ================================================================
% STEP 1: Build common stencil parameter space and evaluate REF/LF/HF data
% This does not depend on iDS.
% ================================================================

l = extra_p{1};
u = extra_p{2};
sc = extra_p{3};
GP_type = extra_p{4};
ntp = extra_p{5};
num_ves = extra_p{6};
art = extra_p{7};
ven = extra_p{8};

%% Build local stencil around every theta point

[nTheta, nd] = size(theta);

hFrac = 0.02;          % 2% of each parameter range
h = hFrac * (u - l);   % 1 x nd

nStencil = 1 + 2*nd; % size of the stencil

ThetaStencil = NaN(nTheta, nStencil, nd);

for j = 1:nTheta
    
    theta0 = theta(j,:); % inspect theta to ensure it is on original scale - it is!
    
    stencil = theta0;
    
    for d = 1:nd
        
        theta_plus = theta0;
        theta_minus = theta0;
        
        theta_plus(d)  = min(theta0(d) + h(d), u(d));
        theta_minus(d) = max(theta0(d) - h(d), l(d));
        
        stencil = [stencil; theta_plus; theta_minus];
        
    end
    
    ThetaStencil(j,:,:) = stencil;
    
end

ThetaStencilFlat = reshape(ThetaStencil, nTheta*nStencil, nd);
nTotal = size(ThetaStencilFlat,1);

%% Load LF and HF emulators

LF = load('/SimulatorsMultifidelity/PulmonaryModel/GP_PCA_Emulator_LF_4D.mat');

extra_p_LF = {LF.gp_regr_pressure, LF.x_regr, LF.y_regr_pressure, LF.NC_pressure, LF.coeff_pressure, LF.mu_pressure, LF.mean_y_pressure, LF.std_y_pressure};

HF = load('/SimulatorsMultifidelity/PulmonaryModel/GP_PCA_Emulator_HF_4D.mat');

extra_p_HF = {HF.gp_regr_pressure, HF.x_regr, HF.y_regr_pressure, HF.NC_pressure, HF.coeff_pressure, HF.mu_pressure, HF.mean_y_pressure, HF.std_y_pressure};

%% Preallocate output data

REFData_classif_stencil = NaN(nTotal, ntp);
LFData_classif_stencil  = NaN(nTotal, ntp);
HFData_classif_stencil  = NaN(nTotal, ntp);

%% Evaluate REF, LF, HF outputs at all stencil points

delete(gcp('nocreate'))
parpool('local', 48)

parfor i = 1:nTotal
    
    file_id = i;
    
    param = ThetaStencilFlat(i,:); % param is on original scale
    
    %% REF model: EnvironSimulator
    dataREF = Run_fluidsModel(param, file_id, num_ves, art, ven, ntp); % takes param on original scale
    REFData_classif_stencil(i,:) = dataREF;
    
    %% LF emulator
    dataLF = Evaluate_1signal_emulator(param./sc, extra_p_LF, GP_type); % takes scaled param
    LFData_classif_stencil(i,:) = dataLF;
    
    %% HF emulator
    dataHF = Evaluate_1signal_emulator(param./sc, extra_p_HF, GP_type); % takes scaled param
    HFData_classif_stencil(i,:) = dataHF;
    
end

%% Reshape back to nTheta x nStencil x ntp

REFData_classif_stencil = reshape(REFData_classif_stencil, nTheta, nStencil, ntp);
LFData_classif_stencil  = reshape(LFData_classif_stencil,  nTheta, nStencil, ntp);
HFData_classif_stencil  = reshape(HFData_classif_stencil,  nTheta, nStencil, ntp);

%% Save common data

save('/SimulatorsMultifidelity/PulmonaryModel/ClassifierStencilModelData_Pulm.mat')

end

