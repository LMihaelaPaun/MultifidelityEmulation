function [pressure, flow, pass] = Run_fluidsModel(x, ...
    file_id, num_ves, art, ven, ntp)

fs3_vec = x(:,1);
alpha_vec = x(:,2);
lrrA_vec = x(:,3);
lrrV_vec = x(:,4);

n = size(x,1);

pass = NaN(n,1);

for i = 1:n
    
    % call the model
    param = [fs3_vec(i), alpha_vec(i), lrrA_vec(i), lrrV_vec(i), file_id];
    
    param_str = mat2str(param);
    
    % Run the model
    % NOTE: Windows users need 'sor06.exe', Mac/Linux users need ./sor06
    cx = unix(sprintf('./sor06  %s',param_str(2:end-1)));
    
    if cx == 1 %marks a successful simulation
        
        pass(i) = 1;
        
        [pressure, flow] = ExtractData(num_ves, art, ven, file_id);
        
    else
        
        pass(i) = 0;
        
        pressure = NaN(ntp,1);
        flow = NaN(ntp,2);
        
    end
end

end