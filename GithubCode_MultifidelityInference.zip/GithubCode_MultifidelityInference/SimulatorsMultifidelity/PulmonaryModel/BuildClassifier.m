function [mdl,PercGoodCases,KNNcorrectClassifRate] = BuildClassifier(trueData)

%% ================================================================
% STEP 2: Build classifier for one inference data set iDS, called trueData
% here -- ensure trueData doesn't get overwritten anywhere (it is currently
% not in ClassifierStencilModelData_Environ.mat!)
% ================================================================

load('/SimulatorsMultifidelity/PulmonaryModel/ClassifierStencilModelData_Pulm.mat')

rho_LF = NaN(nTheta,1);
rho_HF = NaN(nTheta,1);

bestMoveMatch_LF = false(nTheta,1);
bestMoveMatch_HF = false(nTheta,1);

y_all = NaN(nTheta,1);     % 0 = LF better, 1 = HF better

eps = 1e-12;

for j = 1:nTheta
    
    J_REF = NaN(nStencil,1);
    J_LF  = NaN(nStencil,1);
    J_HF  = NaN(nStencil,1);
    
    for ss = 1:nStencil
        
        %% REF RSS
        dataREF = squeeze(REFData_classif_stencil(j,ss,:))';
        J_REF(ss) = sum((trueData - dataREF).^2, 'all');
        
        %% LF RSS
        dataLF = squeeze(LFData_classif_stencil(j,ss,:))';
        J_LF(ss) = sum((trueData - dataLF).^2, 'all');
        
        %% HF RSS
        dataHF = squeeze(HFData_classif_stencil(j,ss,:))';
        J_HF(ss) = sum((trueData - dataHF).^2, 'all');
    end
    
    %% Best local move agreement
    [~,idxBest_REF] = min(J_REF);
    [~,idxBest_LF]  = min(J_LF);
    [~,idxBest_HF]  = min(J_HF);
    
    bestMoveMatch_LF(j) = idxBest_LF == idxBest_REF;
    bestMoveMatch_HF(j) = idxBest_HF == idxBest_REF;
    
    %% Local ranking agreement
    rho_LF(j) = corr(J_REF, J_LF, 'Type', 'Spearman', 'Rows', 'complete');
    rho_HF(j) = corr(J_REF, J_HF, 'Type', 'Spearman', 'Rows', 'complete');
    
    %% Label decision
    if bestMoveMatch_HF(j) && ~bestMoveMatch_LF(j)
        y_all(j) = 1;   % HF better
    elseif bestMoveMatch_LF(j) && ~bestMoveMatch_HF(j)
        y_all(j) = 0;   % LF better 
    else
        if isfinite(rho_HF(j)) && isfinite(rho_LF(j))
            if rho_HF(j) > rho_LF(j) % HF better
                y_all(j) = 1;
            elseif rho_HF(j) < rho_LF(j) % LF better
                y_all(j) = 0;
            else % rho_HF(j) = rho_LF(j)
                % see which HF/LF has RSS closer to REF
                % Tie-breaker: compare the whole local objective shape.
                J_REF_n = (J_REF - min(J_REF)) / (max(J_REF) - min(J_REF) + eps);
                J_LF_n  = (J_LF  - min(J_LF )) / (max(J_LF ) - min(J_LF ) + eps);
                J_HF_n  = (J_HF  - min(J_HF )) / (max(J_HF ) - min(J_HF ) + eps);

                errShape_LF = norm(J_REF_n - J_LF_n);
                errShape_HF = norm(J_REF_n - J_HF_n);

                if errShape_HF < errShape_LF
                    y_all(j) = 1;   % HF better
                elseif errShape_LF < errShape_HF
                    y_all(j) = 0;   % LF better
                else
                    % Truly indistinguishable.
                    % Option 1: choose cheaper model
                    y_all(j) = 0;
                end
            end
        elseif isfinite(rho_HF(j)) && ~isfinite(rho_LF(j))
            y_all(j) = 1;
        elseif isfinite(rho_LF(j)) && ~isfinite(rho_HF(j))
            y_all(j) = 0;
        else
            y_all(j) = NaN;
        end
    end

end

%% Next use a classifier to learn the labels (1:HF, 0:LF) which gives which fidelity emulator we should use:
%(HF emulator or LF). The classifier will predict the label for unseen
%(test) parameter values, which is essential in inference, where we
% wouldn't call simulator for new parameter values
% possible classifiers: k-nearest neighbours (KNN), GPs, support vector machine (SVM)

% K-nearest neighbours (KNN)
k = 100; % size of test dataset

x_class = theta(1:nTheta-k,:);
y_class = y_all(1:nTheta-k);

x_class_test = theta(nTheta-k+1:end,:);
y_class_test = y_all(nTheta-k+1:end);

PercGoodCases = sum(y_class == 1) / numel(y_class); % HF better

% predict labels for test data
% KNN classifier
nNeigh = 5;
mdl = fitcknn(x_class, y_class,'NumNeighbors', nNeigh, ...
    'Standardize', true, 'Distance', 'mahalanobis');

label = predict(mdl, x_class_test);

% compare prediction to actual label
% figure(20);clf(20);plot(1:nTheta,label-Y,'.r'); %should be all zero if label correctly predicted
KNNcorrectClassifRate = sum(label == y_class_test) / numel(y_class_test);

end
