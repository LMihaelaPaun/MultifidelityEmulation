function GetInferenceData(thetaStar, extra_p) 
%% ================================================================
% Get inference data sets
% ================================================================

ntp = extra_p{1};
num_ves = extra_p{2};
art = extra_p{3};
ven = extra_p{4};

nDS = size(thetaStar, 1);

delete(gcp('nocreate'))
parpool('local', 48)

SimData_thetaStar = NaN(nDS,ntp);

parfor iDS=1:nDS
    
    file_id = iDS;
    
    clean_pressureData = Run_fluidsModel(thetaStar(iDS,:), file_id, num_ves, art, ven, ntp);
    
    SimData_thetaStar(iDS,:) = clean_pressureData;
    
end

%% Save inference data

save('/SimulatorsMultifidelity/PulmonaryModel/InferenceData_Pulm.mat', 'SimData_thetaStar')

end