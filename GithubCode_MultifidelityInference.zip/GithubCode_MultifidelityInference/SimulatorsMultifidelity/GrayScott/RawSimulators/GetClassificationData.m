function GetClassificationData(theta, extra_p)
% Generate classifier data (uses raw simulators instead of emulators)

%% ================================================================
% STEP 1: Build common stencil parameter space and evaluate REF/LF/HF data
% This does not depend on iDS.
%% ================================================================

fidelity = extra_p{1};
opts = extra_p{2};
ntp = extra_p{3};
tObs = extra_p{4};
obsVar = extra_p{5};
l = extra_p{6};
u = extra_p{7};
sc = extra_p{8};
GP_type = extra_p{9};

extra_p_sim = {'REF', opts, ntp, tObs, obsVar};
extra_p_LF = {'LF', opts, ntp, tObs, obsVar};
extra_p_HF = {'HF', opts, ntp, tObs, obsVar};

%% Build local stencil around every theta point

[nTheta, nd] = size(theta);

hFrac = 0.02;          % 2% of each parameter range
h = hFrac * (u - l);   % 1 x nd

nStencil = 1 + 2*nd;

ThetaStencil = NaN(nTheta, nStencil, nd);

for j = 1:nTheta

    theta0 = theta(j,:);

    stencil = theta0;

    for d = 1:nd

        theta_plus = theta0;
        theta_minus = theta0;

        theta_plus(d)  = min(theta0(d) + h(d), u(d));
        theta_minus(d) = max(theta0(d) - h(d), l(d));

        stencil = [stencil; theta_plus; theta_minus];

    end

    ThetaStencil(j,:,:) = stencil;

end

ThetaStencilFlat = reshape(ThetaStencil, nTheta*nStencil, nd);
nTotal = size(ThetaStencilFlat,1);

%% Preallocate output data

REFData_classif_stencil = NaN(nTotal, ntp);
LFData_classif_stencil  = NaN(nTotal, ntp);
HFData_classif_stencil  = NaN(nTotal, ntp);

%% Evaluate REF, LF, HF outputs at all stencil points

parfor i = 1:nTotal

    param = ThetaStencilFlat(i,:);

    %% REF model: Gray-Scott REF simulator
    [dataREF, okREF] = SimulatorGrayScottCommonGrid(param, extra_p_sim);

    if okREF
        REFData_classif_stencil(i,:) = dataREF;
    end

    %% LF model: Gray-Scott LF simulator
    dataLF = SimulatorGrayScottCommonGrid(param, extra_p_LF);

    LFData_classif_stencil(i,:) = dataLF;

    %% HF model: Gray-Scott HF simulator
    dataHF = SimulatorGrayScottCommonGrid(param, extra_p_HF);
    
    HFData_classif_stencil(i,:) = dataHF;

end

%% Reshape back to nTheta x nStencil x ntp

REFData_classif_stencil = reshape(REFData_classif_stencil, nTheta, nStencil, ntp);
LFData_classif_stencil  = reshape(LFData_classif_stencil,  nTheta, nStencil, ntp);
HFData_classif_stencil  = reshape(HFData_classif_stencil,  nTheta, nStencil, ntp);

%% Save common data

save('/SimulatorsMultifidelity/GrayScott/RawSimulators/ClassifierStencilModelData_GrayScott.mat')

end