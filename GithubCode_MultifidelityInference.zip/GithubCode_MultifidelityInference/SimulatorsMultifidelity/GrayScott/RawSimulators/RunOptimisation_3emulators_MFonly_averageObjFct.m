%% main script to run optimisation with a gradient-free algorithm for the multifidelity emulator
clear; close all

% add path to the original GPstuff toolbox
addpath('/CommonFunctions')

addpath(genpath('/GPstuff-4.7'))

%% ================================================================
% Generate inference (thetaStar and fs(thetaStar)) data
%% ================================================================

% no of parameters
nd = 2; % theta = [f,k]

% Gray-Scott physical settings
opts.L  = 50.0;
opts.ru = 1.0;
opts.rv = 0.1;
opts.T  = 50.0;

% Gray-Scott fidelity settings
opts.LF.N  = 20;
opts.LF.dt = 1.0;

opts.HF.N  = 40;
opts.HF.dt = 1.0;

opts.REF.N  = 60; % 80 also works, bur fewer cases of LF better
opts.REF.dt = 1.0;

% Observation design
tObs = opts.T;
ntp = 256; % no of time points in the time series

obsVar = 'v';          % choose 'u' or 'v'

%% Generate inference parameter values

X = sobolset(nd, 'Skip',2e13,'Leap',0.3e14);

nDS = size(X,1);

thetaStar = NaN(nDS,nd);

% parameter bounds for Gray-Scott
l = [0.075, -0.025];
u = [0.125,  0.025];
sc = [1, 1];

for i=1:nd
    thetaStar(:,i) = l(i) + (u(i)-l(i)) * X(1:nDS,i);
end

extra_p = {'REF', opts, ntp, tObs, obsVar};

generateInferenceData = 0; % 0: no, because it's already been generated, 1: yes

if generateInferenceData == 1
    GetInferenceData(thetaStar, extra_p)
end

load('/SimulatorsMultifidelity/GrayScott/RawSimulators/InferenceData_GrayScott.mat')

%% ================================================================
% Generate theta and fs(theta) for building classifier
%% ================================================================

generateClassifData = 0; % 0: no, because it's already been generated, 1: yes

if generateClassifData == 1

    X = sobolset(nd, 'Skip',2e11,'Leap',0.901e13);

    nTheta = size(X,1);

    theta = NaN(nTheta,nd);

    for i=1:nd
        theta(:,i) = l(i) + (u(i)-l(i)) * X(1:nTheta,i);
    end

    GP_type = 2; % GP-PCA

    extra_p = {'REF', opts, ntp, tObs, obsVar, l, u, sc, GP_type};

    GetClassificationData(theta, extra_p);

end

%% ================================================================
% Predictive accuracy checks: HF always better predictive performance than LF
%% ================================================================
extra_p_LF = {'LF', opts, ntp, tObs, obsVar};
extra_p_HF = {'HF', opts, ntp, tObs, obsVar};

for iDS = 1:nDS

    predictions_LF(iDS,:) = SimulatorGrayScottCommonGrid(thetaStar(iDS,:), extra_p_LF);

    predictions_HF(iDS,:) = SimulatorGrayScottCommonGrid(thetaStar(iDS,:), extra_p_HF);

end

dev_LF = sum((SimData_thetaStar(1:nDS,:)-predictions_LF).^2,2);
dev_HF = sum((SimData_thetaStar(1:nDS,:)-predictions_HF).^2,2);
%

sum(dev_LF<dev_HF) % has to be zero

if sum(dev_LF<dev_HF) ~= 0
    warning('Some LF predictive errors lower than HF predictive errors')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%

ErrorSimSpace = NaN(nDS,1);
ErrorParSpace = NaN(nDS,1);

PercGoodCases = NaN(nDS,1);
KNNcorrectClassifRate = NaN(nDS,1);

FinalXvalue_MF = NaN(nDS,nd);

delete(gcp('nocreate'))
parpool('local', 48)

for iDS=1:nDS
    
    trueData = SimData_thetaStar(iDS,:);
    
    [mdl,PercGoodCases(iDS),KNNcorrectClassifRate(iDS)] = BuildClassifier(trueData);
    
    %% Next run optimisation
    % different initialisations
    Xinit = sobolset(nd, 'Skip',2e12,'Leap',0.183e15);
    
    ninit = 48;
    
    par0 = NaN(ninit,nd);
    
    for i=1:nd
        par0(:,i) = l(i) + (u(i)-l(i)) * Xinit(1:ninit,i);
    end
    
    % compare to true theta
    WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));
    
    %% ================================================================
    % MF (average approach)
    %% ================================================================
    
    clear history OFALL data ok

    extra_p_alg = {mdl,l,u,sc};
    
    parfor i = 1:48
        % algorithm adapted for multifidelity inference
        history(i) = GradientFreeAlgorithm_MFsimulator_SimHFLF_averageOF(...
            par0(i,:)./sc, trueData, extra_p_alg, extra_p_LF, extra_p_HF);
    end
    
    extra_p_sim = {'REF', opts, ntp, tObs, obsVar};
    
    parfor i=1:48
        
        [data(i,:), ok(i)] = SimulatorGrayScottCommonGrid(history(i).x(end,:) .* sc, extra_p_sim);
        
        if ~ok(i)
            
            fprintf('  REF data failed from MF optimisation for parameter set %d. \n', i);
            
            OFALL(i) = 10^10;
            
        else
        
            OFALL(i) = sum((trueData-data(i,:)).^2);
        
        end
    end
    
    Idx = find(min(OFALL)==OFALL); 
    Idx = Idx(1);
    
    FinalXvalue_MF(iDS,:) = history(Idx).x(end,:) .* sc;

    ErrorSimSpace(iDS,1) = OFALL(Idx);
    ErrorParSpace(iDS,1) = WRMSE_par(thetaStar(iDS,:),FinalXvalue_MF(iDS,:));

    save('InferenceErrors_HFLFsimulators_onlyMFdifferent_averageOF.mat')

end

exit;


