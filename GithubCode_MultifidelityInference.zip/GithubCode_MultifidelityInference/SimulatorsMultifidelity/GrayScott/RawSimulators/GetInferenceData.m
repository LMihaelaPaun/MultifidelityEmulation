function GetInferenceData(thetaStar, extra_p)
% Get inference data sets

fidelity = extra_p{1};
opts = extra_p{2};
ntp = extra_p{3};
tObs = extra_p{4};
obsVar = extra_p{5};

nDS = size(thetaStar, 1);

SimData_thetaStar = NaN(nDS,ntp);
    ok_SimData = false(nDS,1);

%     delete(gcp('nocreate'))
%     parpool('local', 48)

    parfor iDS=1:nDS
        
        [SimData_thetaStar(iDS,:), ok_SimData(iDS)] = SimulatorGrayScottCommonGrid(...
            thetaStar(iDS,:), extra_p);
        
        if ~ok_SimData(iDS)
            fprintf('  REF inference data failed for dataset %d. \n', iDS);
        end
        
    end

    %% Save inference data

    save('/SimulatorsMultifidelity/GrayScott/RawSimulators/InferenceData_GrayScott.mat', ...
        'SimData_thetaStar', 'ok_SimData', 'thetaStar', 'opts', 'tObs')

end