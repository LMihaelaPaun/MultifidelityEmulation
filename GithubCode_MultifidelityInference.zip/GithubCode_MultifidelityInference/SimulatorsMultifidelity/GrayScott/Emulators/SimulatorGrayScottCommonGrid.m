function [data, ok] = SimulatorGrayScottCommonGrid(theta, extra_p)

fidelity = extra_p{1};
opts     = extra_p{2};
Nout     = extra_p{3};   % number of common output grid points
tObs     = extra_p{4};   % can be one time point or several
obsVar   = extra_p{5};   % 'u', 'v', or 'both'

ok = true;

try
    switch upper(fidelity)
        case 'LF'
            N  = opts.LF.N;
            dt = opts.LF.dt;
        case 'HF'
            N  = opts.HF.N;
            dt = opts.HF.dt;
        case 'REF'
            N  = opts.REF.N;
            dt = opts.REF.dt;
        otherwise
            error('Unknown fidelity: %s', fidelity);
    end

    f = theta(1);
    k = theta(2);

    L  = opts.L;
    ru = opts.ru;
    rv = opts.rv;
    T  = opts.T;

    %% Construct common output grid inside the simulator
    %
    % Periodic grid on [-L,L), with Nout points.
    %
    % Example:
    %   Nout = 10 gives 10 common output locations.
    %
    xOut = linspace(-L, L, Nout+1);
    xOut = xOut(1:end-1);

    %% Periodic simulation domain [-L,L)
    domainLength = 2*L;

    x = linspace(-L, L, N+1);
    x = x(1:end-1);

    if mod(N,2) ~= 0
        error('N must be even.');
    end

    if mod(Nout,1) ~= 0 || Nout <= 0
        error('Nout must be a positive integer.');
    end

    %% FFT wave numbers
    kk = (2*pi/domainLength) * [0:(N/2-1), -N/2:-1]';
    lap = -(kk.^2);

    %% Initial condition
    u = 1 - 0.5*sin(pi*(x(:)-L)/(2*L)).^2;
    v = 0.25*sin(pi*(x(:)-L)/(2*L)).^2;

    %% Time stepping
    Nt = round(T/dt);
    tStore = (0:Nt)*dt;

    Uhist = zeros(Nt+1,N);
    Vhist = zeros(Nt+1,N);

    Uhist(1,:) = u(:)';
    Vhist(1,:) = v(:)';

    %% Semi-implicit Euler
    denom_u = 1 - dt*ru*lap;
    denom_v = 1 - dt*rv*lap;

    for n = 1:Nt

        uvv = u .* (v.^2);

        rhs_u = u + dt*(-uvv + f*(1-u));
        rhs_v = v + dt*( uvv - (f+k)*v);

        uhat = fft(rhs_u);
        vhat = fft(rhs_v);

        u = real(ifft(uhat ./ denom_u));
        v = real(ifft(vhat ./ denom_v));

        if any(~isfinite(u)) || any(~isfinite(v)) || ...
           max(abs(u)) > 1e6 || max(abs(v)) > 1e6
            ok = false;
            break;
        end

        Uhist(n+1,:) = u(:)';
        Vhist(n+1,:) = v(:)';
    end

    nout = Nout * numel(tObs);

    if ~ok
        switch lower(obsVar)
            case {'u','v'}
                data = NaN(1,nout);
            case 'both'
                data = NaN(1,2*nout);
            otherwise
                data = NaN(1,nout);
        end
        return;
    end

    %% Interpolate to requested output times
    U_tObs = interp1(tStore, Uhist, tObs, 'linear');
    V_tObs = interp1(tStore, Vhist, tObs, 'linear');

    if numel(tObs) == 1
        U_tObs = reshape(U_tObs, 1, []);
        V_tObs = reshape(V_tObs, 1, []);
    end

    %% Interpolate each selected time to common spatial grid xOut
    Y_u = zeros(numel(tObs), Nout);
    Y_v = zeros(numel(tObs), Nout);

    for it = 1:numel(tObs)
        Y_u(it,:) = interp_periodic_1d(x, U_tObs(it,:), xOut, L);
        Y_v(it,:) = interp_periodic_1d(x, V_tObs(it,:), xOut, L);
    end

    %% Output on common grid
    %
    % For one time point:
    %
    %   data = [v(x1,T), v(x2,T), ..., v(xNout,T)]
    %
    % For several time points:
    %
    %   data = [v(x1,t1), ..., v(xNout,t1), ...
    %           v(x1,t2), ..., v(xNout,t2), ...]
    %
    % Y_v is time x space.
    % reshape(Y_v.',[],1)' gives time-block ordering.
    switch lower(obsVar)

        case 'u'
            data = reshape(Y_u.', [], 1)';

        case 'v'
            data = reshape(Y_v.', [], 1)';

        case 'both'
            data_u = reshape(Y_u.', [], 1)';
            data_v = reshape(Y_v.', [], 1)';
            data = [data_u, data_v];

        otherwise
            error('obsVar must be ''u'', ''v'', or ''both''.');
    end

    if any(~isfinite(data))
        ok = false;
    end

catch ME
    warning('GrayScottSimulator failed for %s: %s', fidelity, ME.message);

    if exist('Nout','var') && isfinite(Nout)
        nout = Nout * numel(tObs);
    else
        nout = numel(tObs);
    end

    switch lower(obsVar)
        case {'u','v'}
            data = NaN(1,nout);
        case 'both'
            data = NaN(1,2*nout);
        otherwise
            data = NaN(1,nout);
    end

    ok = false;
end
end


function yq = interp_periodic_1d(x, y, xq, L)

period = 2*L;

xq_wrap = mod(xq + L, period) - L;

x_ext = [x(:); L];
y_ext = [y(:); y(1)];

yq = interp1(x_ext, y_ext, xq_wrap(:), 'linear');

yq = yq(:)';

end