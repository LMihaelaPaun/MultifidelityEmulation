function fit_and_save_GP_PCA_grayscott_emulator(Fid, x_train, data_train, x_test, data_test, NC, nd)

%% ================================================================
% Fit GP-PCA emulator for current data_train/data_test
% ================================================================

%% PCA
[coeff, score, latent, tsquared, explained, mu] = pca(data_train);

maxPCcheck = min(size(coeff,2),20);

meanMSE_PCA_train = NaN(maxPCcheck,1);
meanMSE_PCA_test  = NaN(maxPCcheck,1);

for npc = 1:maxPCcheck

    data_recons_train = score(:,1:npc) * coeff(:,1:npc)' + mu;

    MSE_train = sum((data_train - data_recons_train).^2, 2);
    meanMSE_PCA_train(npc) = mean(MSE_train, 'omitnan');

    PCscores_test = (data_test - mu) * coeff(:,1:npc);
    data_recons_test = PCscores_test * coeff(:,1:npc)' + mu;

    MSE_test = sum((data_test - data_recons_test).^2, 2);
    meanMSE_PCA_test(npc) = mean(MSE_test, 'omitnan');

end

figure;
semilogy(1:maxPCcheck, meanMSE_PCA_train, 'ob-', 'LineWidth', 2);
hold on;
semilogy(1:maxPCcheck, meanMSE_PCA_test, 'sr-', 'LineWidth', 2);
xlabel('Number of PCs');
ylabel('Mean reconstruction RSS');
legend('Train','Test');
grid on;
title(sprintf('PCA reconstruction error, Fid = %g', Fid));

%% Check reconstruction with NC = 6

PCscores_test = (data_test - mu) * coeff(:,1:NC);
data_test_PCA_recons = PCscores_test * coeff(:,1:NC)' + mu;

figure;
for j = 1:min(10,size(data_test,1))
    subplot(2,5,j);
    plot(data_test(j,:), '-k', 'LineWidth', 2);
    hold on;
    plot(data_test_PCA_recons(j,:), '--r', 'LineWidth', 2);
    title(sprintf('Test %d', j));
end
sgtitle(sprintf('PCA reconstruction using %d PCs, Fid = %g', NC, Fid));
legend('Original','PCA recon');

%% GP regression for PC scores

x_regr = x_train;

y_regr = (data_train - mu) * coeff(:,1:NC);

%% GP hyperparameter initialisation

% settings for GP fitting
X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
n_r = size(X_r, 1);

l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
u_r = [1.5 ones(1,nd) 1];

% Initialisations for amplitude, lengthscale and likelihood noise for GP
% regression
H_r = [];
for j=1:nd+2
    H_r = [H_r, l_r(j) + (u_r(j)-l_r(j)) * X_r(:,j)];
end
H_r(end+1,:) = [1 repmat(0.1,1,nd) 10^(-6)];

gp_regr = cell(NC,1);
mean_y = NaN(1,NC);
std_y  = NaN(1,NC);

%% Fit independent GP for each PC score

for pc = 1:NC

    fprintf('Fitting GP for PC %d / %d, Fid = %g\n', pc, NC, Fid);

    mean_y(pc) = mean(y_regr(:,pc));
    std_y(pc)  = std(y_regr(:,pc));

    if std_y(pc) == 0 || ~isfinite(std_y(pc))
        error('PC score %d has zero or invalid standard deviation.', pc);
    end

    y_regr(:,pc) = (y_regr(:,pc) - mean_y(pc)) ./ std_y(pc);

    gp_regr{pc} = GPmodel(x_regr, y_regr(:,pc), H_r(1,:));

    [w, s] = gp_pak(gp_regr{pc});
    disp(exp(w));

    %% Training prediction diagnostic
    E_train = gp_pred(gp_regr{pc}, x_regr, y_regr(:,pc), x_regr);

    figure;
    plot(y_regr(:,pc), E_train, 'ob', 'MarkerFaceColor', 'b');
    hold on;
    plot(y_regr(:,pc), y_regr(:,pc), '-r', 'LineWidth', 2);
    xlabel('Actual scaled PC score');
    ylabel('Predicted scaled PC score');
    title(sprintf('Training GP prediction, PC %d, Fid = %g', pc, Fid));
    grid on;

end

%% Test emulator predictions

E_test = NaN(size(x_test,1), NC);

for pc = 1:NC
    E_test(:,pc) = gp_pred(gp_regr{pc}, x_regr, y_regr(:,pc), x_test);
end

data_test_GP_recons = (E_test .* std_y + mean_y) * coeff(:,1:NC)' + mu;

PCscores_test_actual = (data_test - mu) * coeff(:,1:NC);
PCscores_test_pred   = E_test .* std_y + mean_y;

%% PC score test diagnostics

figure;
for pc = 1:NC
    subplot(3,4,pc);
    plot(PCscores_test_pred(:,pc), PCscores_test_actual(:,pc), '.r', 'MarkerSize', 14);
    hold on;
    plot(PCscores_test_actual(:,pc), PCscores_test_actual(:,pc), '--k', 'LineWidth', 2);
    xlabel('Predicted PC score');
    ylabel('Actual PC score');
    title(sprintf('PC %d', pc));
    grid on;
end
sgtitle(sprintf('Test PC score predictions, Fid = %g', Fid));

%% Output reconstruction diagnostic

figure;
for k = 1:min(100,size(data_test,1))
    subplot(10,10,k);
    plot(data_test(k,:), '-k');
    hold on;
    plot(data_test_GP_recons(k,:), '-r');
    axis tight;
end
sgtitle(sprintf('GP-PCA emulator predictions, Fid = %g', Fid));

dev = sum((data_test - data_test_GP_recons).^2, 2);

fprintf('Mean test RSS, Fid = %g: %.6e\n', Fid, mean(dev,'omitnan'));
fprintf('Median test RSS, Fid = %g: %.6e\n', Fid, median(dev,'omitnan'));

%% Save emulator

switch upper(Fid)
    case 'LF'

        save('GP_PCA_Emulator_LF.mat');

    case 'HF'

        save('GP_PCA_Emulator_HF.mat');

    otherwise
        error('Unknown fidelity: %s', fidelity);
end

end