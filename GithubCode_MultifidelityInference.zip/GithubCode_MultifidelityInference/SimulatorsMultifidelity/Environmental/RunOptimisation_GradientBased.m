% main script to run optimisation with a gradient-based algorithm for 2 emulators:
% high-fidelity, low-fidelity
clear; close all

% add path to the original GPstuff toolbox
addpath('/CommonFunctions')

addpath(genpath('/GPstuff-4.7'))

% Set some quantities

% no of time points in the time series
ntp = 200;

nd = 4; % no of parameters

l = [7, 0.02, 0.01, 30.01];
u = [13, 0.12, 3, 30.295];
sc = [1, 1, 1, 1];

% run simulator at locations
s = [0.5, 1, 1.5, 2, 2.5];
spaceIndex = 1;
space = s(spaceIndex);

%% Generate inference data

X = sobolset(nd, 'Skip',2e13,'Leap',0.3e14);

nDS = size(X,1);

thetaStar = NaN(nDS,nd);

for i=1:nd
    thetaStar(:,i) = l(i) + (u(i)-l(i)) * X(1:nDS,i);
end

generateInferenceData = 0; % 0: no, because it's already been generated, 1: yes

if generateInferenceData == 1
    GetInferenceData(thetaStar, space, ntp)
end

load('/SimulatorsMultifidelity/Environmental/InferenceData_Environ.mat')


% load PCA emulators
load('/SimulatorsMultifidelity/Environmental/GP_PCA_Emulator_HF.mat') 
% LF is just a subset of HF (first two PCs out of 5PCs), so it will automatically get loaded

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
ErrorSimSpace = NaN(nDS,2);
ErrorParSpace = NaN(nDS,2);

parpool('local', 48)

for iDS=1:nDS

    trueData = SimData_thetaStar(iDS,:);

    %% Next run optimisation

    NC_fid = [2,5];% LF model: 2 PCs, HF model: 5 PCs

    % different initialisations
    Xinit = sobolset(nd, 'Skip',2e12,'Leap',0.183e15);

    ninit = size(Xinit,1);

    par0 = NaN(ninit,nd);

    for i=1:nd
        par0(:,i) = l(i) + (u(i)-l(i)) * Xinit(1:ninit,i);
    end

    % compare to true theta
    WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));

    % HF model
    switchEm = 2; % do not switch between emulators

    HF = 1;

    extra_p = {gp_regr,x_regr,y_regr,NC_fid,coeff,mu,...
        mean_y,std_y,switchEm,HF,mdl,l,u,sc};

    parfor i = 1:48%ninit
        history(i) = GradientAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, trueData, extra_p);
    end

    parfor i=1:48

        data(i,:) = EnvironSimulator(history(i).x(end,:) .*sc, space);

        OFALL(i) = sum((trueData-data(i,:)).^2);

    end

    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;

    if switchEm==1
        FinalXvalue_switch = FinalXvalue; FinalYvalue_switch = min(OFALL);
    else
        FinalXvalue_HF = FinalXvalue; FinalYvalue_HF = min(OFALL);
    end

    ErrorSimSpace(iDS,1) = OFALL(Idx);
    ErrorParSpace(iDS,1) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);

    % Now also run for LF model
    HF = 0; % use LF
    % update extra_p
    extra_p = {gp_regr,x_regr,y_regr,NC_fid,coeff,mu,...
        mean_y,std_y,switchEm,HF,mdl,l,u,sc};

    parfor i = 1:48%ninit
        history(i) = GradientAlgorithm_emulator_weightedSumMOO_discrep(par0(i,:)./sc, trueData, extra_p);
    end

    parfor i=1:48

        data(i,:) = EnvironSimulator(history(i).x(end,:) .*sc, space);

        OFALL(i) = sum((trueData-data(i,:)).^2);

    end

    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;

    FinalXvalue_LF = FinalXvalue; FinalYvalue_LF = min(OFALL);

    ErrorSimSpace(iDS,2) = OFALL(Idx);
    ErrorParSpace(iDS,2) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);

    % HF: ErrorSimSpace(iDS,1)
    % LF: ErrorSimSpace(iDS,2)

    save('InferenceErrors_GradientBased.mat')
end
