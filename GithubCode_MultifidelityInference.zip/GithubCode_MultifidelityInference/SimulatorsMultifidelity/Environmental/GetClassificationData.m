function GetClassificationData(theta, extra_p)
%% ================================================================
% STEP 1: Build common stencil parameter space and evaluate REF/LF/HF data
% This does not depend on iDS.
% ================================================================

space = extra_p{1};
ntp = extra_p{2};
l = extra_p{3};
u = extra_p{4};
sc = extra_p{5};
GP_type = extra_p{6};

%% Build local stencil around every theta point

[nTheta, nd] = size(theta);

hFrac = 0.02;          % 2% of each parameter range
h = hFrac * (u - l);   % 1 x nd

nStencil = 1 + 2*nd;   % for nd=4, nStencil=9

ThetaStencil = NaN(nTheta, nStencil, nd);

for j = 1:nTheta
    
    theta0 = theta(j,:);
    
    stencil = theta0;
    
    for d = 1:nd
        
        theta_plus = theta0;
        theta_minus = theta0;
        
        theta_plus(d)  = min(theta0(d) + h(d), u(d));
        theta_minus(d) = max(theta0(d) - h(d), l(d));
        
        stencil = [stencil; theta_plus; theta_minus];
        
    end
    
    ThetaStencil(j,:,:) = stencil;
    
end

ThetaStencilFlat = reshape(ThetaStencil, nTheta*nStencil, nd);
nTotal = size(ThetaStencilFlat,1);

%% Load LF and HF emulators

LF = load('/SimulatorsMultifidelity/Environmental/GP_PCA_Emulator_LF.mat');

extra_p_LF = {LF.gp_regr, LF.x_regr, LF.y_regr, LF.NC, LF.coeff, LF.mu, LF.mean_y, LF.std_y};

HF = load('/SimulatorsMultifidelity/Environmental/GP_PCA_Emulator_HF.mat');

extra_p_HF = {HF.gp_regr, HF.x_regr, HF.y_regr, HF.NC, HF.coeff, HF.mu, HF.mean_y, HF.std_y};

%% Preallocate output data

REFData_classif_stencil = NaN(nTotal, ntp);
LFData_classif_stencil  = NaN(nTotal, ntp);
HFData_classif_stencil  = NaN(nTotal, ntp);

%% Evaluate REF, LF, HF outputs at all stencil points

parfor i = 1:nTotal
    
    param = ThetaStencilFlat(i,:);
    
    %% REF model: EnvironSimulator
    dataREF = EnvironSimulator(param, space); % param on original scale
    REFData_classif_stencil(i,:) = dataREF;
    
    %% LF emulator
    dataLF = Evaluate_1signal_emulator(param./sc, extra_p_LF, GP_type); % scaled param
    LFData_classif_stencil(i,:) = dataLF;
    
    %% HF emulator
    dataHF = Evaluate_1signal_emulator(param./sc, extra_p_HF, GP_type); % scaled param
    HFData_classif_stencil(i,:) = dataHF;
    
end

%% Reshape back to nTheta x nStencil x ntp

REFData_classif_stencil = reshape(REFData_classif_stencil, nTheta, nStencil, ntp);
LFData_classif_stencil  = reshape(LFData_classif_stencil,  nTheta, nStencil, ntp);
HFData_classif_stencil  = reshape(HFData_classif_stencil,  nTheta, nStencil, ntp);

%% Save common data

save('/SimulatorsMultifidelity/Environmental/ClassifierStencilModelData_Environ.mat')

end

