clear; close all
addpath(genpath('/GPstuff-4.7'))

% xx = [M, D, L, tau]
%[y] = EnvironSimulator(xx, s, t)
%Its structure is:
%     y(s_1, t_1), y(s_1, t_2), ..., y(s_1, t_dt), y(s_2, t_1), ...,
%     y(s_2,t_dt), ..., y(s_ds, t_1), ..., y(s_ds, t_dt)

s = [0.5, 1, 1.5, 2, 2.5]; 
% % take t default
% M = 10; D = 0.07; L = 1.505; tau = 30.1525;
% xx = [M, D, L, tau];
% 
% for i=1:numel(s)
%     y = EnvironSimulator(xx, s(i));
% 
%     figure;plot(y)
% end

%% do pca
Fid = 2; % 1: LF, 2: HF

% parameter ranges
% M ∈ [7, 13]	mass of pollutant spilled at each location
% D ∈ [0.02, 0.12]	diffusion rate in the channel
% L ∈ [0.01, 3]	location of the second spill
% τ ∈ [30.01, 30.295]   	time of the second spill
l = [7, 0.02, 0.01, 30.01]; 
u = [13, 0.12, 3, 30.295];

% % Parameter scaling for emulation
% sc = [max(abs(l),abs(u))];

% parameter dimensionality
nd = 4;

% no of time points
ntp = 200;

% get data
% no of signal samples for training data
n = 2000;

X = sobolset(nd, 'Skip',2e12,'Leap',4.504e12);

x = NaN(n,nd);

for i=1:nd
    x(:,i) = l(i) + (u(i)-l(i)) * X(1:n,i);
end

% run simulator for inputs x
spaceIndex = 1;
space = s(spaceIndex);
y = NaN(n,ntp);
for i=1:n
y(i,:) = EnvironSimulator(x(i,:), space);
end

figure;
for i=1:20
    subplot(4,5,i)
    plot(y(i,:))
end

n_train = 1000; n_test = size(x,1) - n_train;

par_train = x(1:n_train,:); par_test = x(n_train+1:n_train+n_test,:);

x_train = par_train; x_test = par_test;

data_train = y(1:n_train,:); data_test = y(n_train+1:end,:);

% PCA data (take the same as training data)
n_PCA = n_train; % no of training points
x_PCA = x_train; % this is already scaled

data_PCA = data_train;

% Fit PCA on data
[coeff,score,latent,tsquared,explained,mu] = pca(data_PCA);

meanMSE_PCA_train = NaN(min(size(coeff,2),20),1);

for NC = 1:(min(size(coeff,2),20))
    data_recons = score(:,1:NC)*coeff(:,1:NC)'+mu;
    
    MSE_PCA_train = sum((data_PCA - data_recons).^2,2);
    
    meanMSE_PCA_train(NC) = mean(MSE_PCA_train, "omitnan"); % !!! quantity of interest
end

% test PCA on test data
meanMSE_PCA_test = NaN(min(size(coeff,2),20),1);

for NC = 1:(min(size(coeff,2),20))
    PCscores_test = (data_test - mu)*coeff(:, 1:NC); % using only the first NC PCs
    
    data_test_PCA_recons = PCscores_test * coeff(:,1:NC)' + mu;
    
    MSE_PCA_test = sum((data_test - data_test_PCA_recons).^2,2);
    
    meanMSE_PCA_test(NC) = mean(MSE_PCA_test, "omitnan"); % !!! quantity of interest
end
    
figure;plot(meanMSE_PCA_train,'.');hold on;plot(meanMSE_PCA_test,'.')

if Fid == 1
    NC = 2; % 8 PCs leads to very good predictions, choose 2 and 5 like for systemic and pulmonary problems
else
    NC = 5;
end

PCscores_test = (data_test - mu)*coeff(:, 1:NC); % using only the first NC PCs

data_test_PCA_recons = PCscores_test * coeff(:,1:NC)' + mu;

figure(i);clf(i)
for j=1:10%n_test
    subplot(2,5,j);hold on
    plot(linspace(0,0.11,ntp),data_test(j,:), '-','linewidth', 3)
    plot(linspace(0,0.11,ntp),data_test_PCA_recons(j,:), '--','linewidth', 3)
end
legend('Original', 'Reconstructed')
title(sprintf('%d PCs', NC))

%% Now emulate the PC scores for the GP training set with independent GPs for score(:,1:NC)

% settings for GP fitting
X_r = sobolset(nd+2, 'Skip',2e12,'Leap',0.45e15); % draw 10 values
n_r = size(X_r, 1);

l_r = [0.5 repmat(0.1,1,nd) 10^(-6)];
u_r = [1.5 ones(1,nd) 1];

% Initialisations for amplitude, lengthscale and likelihood noise for GP
% regression
H_r = [];
for j=1:nd+2
    H_r = [H_r, l_r(j) + (u_r(j)-l_r(j)) * X_r(:,j)];
end

x_regr = x_PCA;
%
y_regr = (data_train - mu)*coeff(:, 1:NC); % using only the first NC PCs

% Fit independent GPs for every PC score
for i=1:NC
    mean_y(i) = mean(y_regr(:,i));
    std_y(i) = std(y_regr(:,i));
    
    % Scale y_regr
    y_regr(:,i) = (y_regr(:,i)-mean_y(i))./std_y(i); % mean 0 and std 1 of of y
    
    % Fit GP
    gp_regr{i} = GPmodel(x_regr, y_regr(:,i), H_r(2,:));
    
    [w,s] = gp_pak(gp_regr{i});
    disp(exp(w))
    
    %Make predictions using gp_regr
    [E, Var] = gp_pred(gp_regr{i}, x_regr, y_regr(:,i), x_regr);
    
    figure(i); clf(i);
    plot(E,E,'-r','linewidth',2);hold on;
    plot(E, y_regr(:,i), 'ob','markersize',6,'markerfacecolor',[0 0 1]);
    set(gca,'fontsize',20);grid on;
    xlabel('Train data'); ylabel('Predictions')
    
end

E = NaN(n_test, NC);

for i=1:NC
    % Make predictions of every PC score using gp models
    E(:,i) = gp_pred(gp_regr{i}, x_regr, y_regr(:,i), x_test);
end

data_test_GP_recons = (E.*std_y+mean_y) * coeff(:,1:NC)' + mu;
PCscores_test = (data_test - mu)*coeff(:, 1:NC); % using only the first NC PCs

figure(2);clf(2)
for i=1:NC
    subplot(4,3,i)
    % Compare E (emulated test PC scores) to actual PCscores_test
    plot(E(:,i).*std_y(i)+mean_y(i), PCscores_test(:,i), '.r', 'Markersize', 20)
    hold on;
    plot(E(:,i).*std_y(i)+mean_y(i),E(:,i).*std_y(i)+mean_y(i), '--k', 'linewidth',2)
    xlabel('Emulated test PC scores');ylabel('Actual test PC scores')
end

prediction = data_test_GP_recons;

figure;
for k=1:100%n_test
    subplot(10,10,k);
    plot(data_test(k,:),'-k');hold on;plot(prediction(k,:),'-r');
end

if Fid==1 % 2PCs
    save('GP_PCA_Emulator_LF.mat')
else % 5 PCs
    save('GP_PCA_Emulator_HF.mat')
end