function GetInferenceData(thetaStar, space, ntp) 
%% ================================================================
% Get inference data sets
% ================================================================

nDS = size(thetaStar, 1);

SimData_thetaStar = NaN(nDS,ntp);

delete(gcp('nocreate'))
parpool('local', 48)

SimData_thetaStar = NaN(nDS,ntp);

parfor iDS=1:nDS
    SimData_thetaStar(iDS,:) = EnvironSimulator(thetaStar(iDS,:), space);
end

%% Save inference data

save('/SimulatorsMultifidelity/Environmental/InferenceData_Environ.mat', 'SimData_thetaStar')

end