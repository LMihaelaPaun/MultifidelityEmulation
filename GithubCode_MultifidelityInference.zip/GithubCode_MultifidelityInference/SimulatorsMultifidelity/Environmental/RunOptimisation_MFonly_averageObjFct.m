% main script to run optimisation with a gradient-free algorithm for the multifidelity emulator
clear; close all

% add path to the original GPstuff toolbox
addpath('/GithubCode_MultifidelityInference/CommonFunctions')

addpath(genpath('/GPstuff-4.7'))

% Set some quantities

% no of time points in the time series
ntp = 200;

nd = 4; % no of parameters

l = [7, 0.02, 0.01, 30.01];
u = [13, 0.12, 3, 30.295];
sc = [1, 1, 1, 1];

% run simulator at locations
s = [0.5, 1, 1.5, 2, 2.5];
spaceIndex = 1;
space = s(spaceIndex);

%% Generate inference data

X = sobolset(nd, 'Skip',2e13,'Leap',0.3e14);

nDS = size(X,1);

thetaStar = NaN(nDS,nd);

for i=1:nd
    thetaStar(:,i) = l(i) + (u(i)-l(i)) * X(1:nDS,i);
end

generateInferenceData = 0; % 0: no, because it's already been generated, 1: yes

if generateInferenceData == 1
    GetInferenceData(thetaStar, space, ntp)
end

load('/SimulatorsMultifidelity/Environmental/InferenceData_Environ.mat')

%% Generate theta and fs(theta) for building classifier

generateClassifData = 0; % 0: no, because it's already been generated, 1: yes

if generateClassifData== 1
    X = sobolset(nd, 'Skip',2e11,'Leap',0.901e13);
    
    nTheta = size(X,1);
    
    theta = NaN(nTheta,nd);
    
    for i=1:nd
        theta(:,i) = l(i) + (u(i)-l(i)) * X(1:nTheta,i);
    end
    
    GP_type = 2; % GP-PCA
    
    extra_p = {space, ntp, l, u, sc, GP_type};
    
    GetClassificationData(theta, extra_p);
    
end

% load PCA emulators
load('/SimulatorsMultifidelity/Environmental/GP_PCA_Emulator_HF.mat') 
% LF is just a subset of HF (first two PCs out of 5PCs), so it will automatically get loaded

ErrorSimSpace = NaN(nDS,1);
ErrorParSpace = NaN(nDS,1);

PercGoodCases = NaN(nDS,1);
KNNcorrectClassifRate = NaN(nDS,1);

delete(gcp('nocreate'))
parpool('local', 48)

for iDS=1:nDS
    
    trueData = SimData_thetaStar(iDS,:);
    
    [mdl,PercGoodCases(iDS),KNNcorrectClassifRate(iDS)] = BuildClassifier(trueData);
    
    %% Next run optimisation
    
    NC_fid = [2,5];% LF model: 2 PCs, HF model: 5 PCs
    
    % different initialisations
    Xinit = sobolset(nd, 'Skip',2e12,'Leap',0.183e15);
    
    ninit = size(Xinit,1);
    
    par0 = NaN(ninit,nd);
    
    for i=1:nd
        par0(:,i) = l(i) + (u(i)-l(i)) * Xinit(1:ninit,i);
    end
    
    % compare to true theta
    WRMSE_par = @(p1,p2) sqrt(sum(((p1-p2)./p1).^2));
    
    switchEm = 1; %1: switch between LF and HF emulators based on KNN classifier,

    HF = NaN;
    
    extra_p = {gp_regr,x_regr,y_regr,NC_fid,coeff,mu,...
        mean_y,std_y,switchEm,HF,mdl,l,u,sc};
    
    parfor i = 1:48%ninit
        % algorithm adapted for multifidelity inference
        history(i) = GradientFreeAlgorithm_emulator_MF_averageOF(par0(i,:)./sc, trueData, extra_p);
    end

    parfor i=1:48
        
        data(i,:) = EnvironSimulator(history(i).x(end,:) .*sc, space);
        
        OFALL(i) = sum((trueData-data(i,:)).^2);
        
    end
    
    Idx = find(min(OFALL)==OFALL); Idx = Idx(1);
    FinalXvalue = history(Idx).x(end,:) .*sc;
    
    if switchEm==1
        FinalXvalue_MF(iDS,:) = FinalXvalue; FinalYvalue_switch = min(OFALL);
    else
        FinalXvalue_HF(iDS,:) = FinalXvalue; FinalYvalue_HF = min(OFALL);
    end
    
    ErrorSimSpace(iDS,switchEm) = OFALL(Idx);
    ErrorParSpace(iDS,switchEm) = WRMSE_par(thetaStar(iDS,:),FinalXvalue);
    
    save('InferenceErrors_MFmodified_averageOF.mat')
    
end

exit;