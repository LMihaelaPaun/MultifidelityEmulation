%% Determine project location
scriptFile = mfilename('fullpath');
projectDir = fileparts(scriptFile);

%% Add common functions
commonFunctionsDir = fullfile(projectDir, 'CommonFunctions');

assert(isfolder(commonFunctionsDir), ...
    'CommonFunctions directory not found: %s', commonFunctionsDir);

addpath(commonFunctionsDir);

%% Add GPstuff
gpstuffDir = fullfile(projectDir, 'external', 'GPstuff-4.7');

assert(isfolder(gpstuffDir), ...
    ['GPstuff was not found at:\n%s\n' ...
    'Place GPstuff-4.7 in the external directory.'], gpstuffDir);

addpath(genpath(gpstuffDir));

%% Figure output directory
figureDir = fullfile(projectDir, 'FiguresMultifidelityEmulation');

if ~isfolder(figureDir)
    mkdir(figureDir);
end

%%

nDS = 300;

applicationNames = { ...
    'Environmental', ...
    'Systemic', ...
    'Pulmonary', ...
    'Burgers', ...
    'Gray-Scott'};

%% Predictive performance

%% ================================================================
% Storage for selected data sets / predictive errors
% ================================================================

selectedDataSet = zeros(1,5);

selectedLFDev = zeros(1,5);
selectedHFDev = zeros(1,5);

selectedDevDifference = zeros(1,5);


%% ================================================================
% Predictive-error figure
% ================================================================

figure(100)
set(gcf, 'Color', 'w')
set(gcf, 'Position', [100 100 1500 350])


%% ================================================================
% Loop through five applications
% ================================================================

for example = 1:5

    clearvars -except example nDS applicationNames ...
        selectedDataSet selectedLFDev selectedHFDev ...
        selectedDevDifference figureDir


    %% Project directory
    scriptDir = fileparts(mfilename('fullpath'));

    % Change this to fileparts(scriptDir) if the script is inside a subfolder.
    projectDir = scriptDir;

    simulatorDir = fullfile(projectDir, 'SimulatorsMultifidelity');

    %% Select application directory
    switch example
        case 1  % Environmental
            applicationDir = fullfile( ...
                simulatorDir, 'Environmental');

        case 2  % Systemic
            applicationDir = fullfile( ...
                simulatorDir, 'SystemicModel');

        case 3  % Pulmonary
            applicationDir = fullfile( ...
                simulatorDir, 'PulmonaryModel');

        case 4  % Burgers
            applicationDir = fullfile( ...
                simulatorDir, 'StochasticBurgers', 'Emulators');

        case 5  % Gray-Scott
            applicationDir = fullfile( ...
                simulatorDir, 'GrayScott', ...
                'Emulators');

        otherwise
            error('Unknown example number: %d. Expected an integer from 1 to 5.', ...
                example);
    end

    assert(isfolder(applicationDir), ...
        'Application directory not found: %s', applicationDir);

    cd(applicationDir);


    predictions = cell(2,1);
    dev = cell(2,1);


    %% ============================================================
    % Environmental, systemic and pulmonary
    % ================================================================

    if example == 1 || example == 2 || example == 3

        % Load data
        load('InferenceErrors_GradientBased.mat')


        %% --------------------------------------------------------
        % Application-specific quantities
        % --------------------------------------------------------

        if example == 3

            gp_regr = gp_regr_pressure;
            y_regr = y_regr_pressure;

            mean_y = mean_y_pressure;
            std_y = std_y_pressure;

            mu = mu_pressure;
            coeff = coeff_pressure;

            SimData_thetaStar = SimPressure_thetaStar;


        elseif example == 2

            nDS = 300;

            gp_regr = gp_regr_flow;
            y_regr = y_regr_flow;

            mean_y = mean_y_flow;
            std_y = std_y_flow;

            mu = mu_flow;
            coeff = coeff_flow;

            SimData_thetaStar = SimFlow_thetaStar;

        end


        %% --------------------------------------------------------
        % LF and HF emulator predictions
        %
        % emulatorAccuracyIdx = 1 -> LF
        % emulatorAccuracyIdx = 2 -> HF
        % --------------------------------------------------------

        for emulatorAccuracyIdx = 1:2

            if emulatorAccuracyIdx == 1

                % Low-fidelity emulator
                NC = 2;

            else

                % High-fidelity emulator
                NC = 5;

            end


            E = NaN(nDS, NC);

            for i = 1:NC

                E(:,i) = gp_pred( ...
                    gp_regr{i}, ...
                    x_regr, ...
                    y_regr(:,i), ...
                    thetaStar(1:nDS,:)./sc);

            end


            % Back-transform into original output space
            predictions{emulatorAccuracyIdx} = ...
                (E .* std_y(1:NC) + mean_y(1:NC)) * ...
                coeff(:,1:NC)' + mu;


            % Predictive squared error
            dev{emulatorAccuracyIdx} = ...
                sum( ...
                (SimData_thetaStar(1:nDS,:) - ...
                predictions{emulatorAccuracyIdx}).^2, ...
                2);

        end


        %% ============================================================
        % Burgers and Gray-Scott
        % ================================================================

    else

        load('InferenceErrors_HFLFemulators_onlyMFdifferent_averageOF.mat')


        %% --------------------------------------------------------
        % LF predictions
        % --------------------------------------------------------

        E = NaN(nDS, LFem.NC);

        for i = 1:LFem.NC

            E(:,i) = gp_pred( ...
                LFem.gp_regr{i}, ...
                LFem.x_regr, ...
                LFem.y_regr(:,i), ...
                thetaStar(1:nDS,:)./sc);

        end

        predictions{1} = ...
            (E .* LFem.std_y + LFem.mean_y) * ...
            LFem.coeff(:,1:LFem.NC)' + LFem.mu;


        %% --------------------------------------------------------
        % HF predictions
        % --------------------------------------------------------

        E = NaN(nDS, HFem.NC);

        for i = 1:HFem.NC

            E(:,i) = gp_pred( ...
                HFem.gp_regr{i}, ...
                HFem.x_regr, ...
                HFem.y_regr(:,i), ...
                thetaStar(1:nDS,:)./sc);

        end

        predictions{2} = ...
            (E .* HFem.std_y + HFem.mean_y) * ...
            HFem.coeff(:,1:HFem.NC)' + HFem.mu;


        %% --------------------------------------------------------
        % Predictive squared errors
        % --------------------------------------------------------

        dev{1} = sum( ...
            (SimData_thetaStar(1:nDS,:) - predictions{1}).^2, ...
            2);

        dev{2} = sum( ...
            (SimData_thetaStar(1:nDS,:) - predictions{2}).^2, ...
            2);

    end


    %% ============================================================
    % Difference between LF and HF predictive errors
    %
    % dev{1} = LF error
    % dev{2} = HF error
    %
    % Positive value means LF is worse than HF
    % ================================================================

    devDifference = dev{1} - dev{2};


    %% ============================================================
    % Sort discrepancy from largest to smallest
    % ================================================================

    [sortedDevDifference, sortedIdx] = ...
        sort(devDifference, 'descend');


    %% ============================================================
    % Select data set
    %
    % Examples 1,2,3,5:
    %       largest discrepancy
    %
    % Burgers:
    %       10th-largest discrepancy
    % ================================================================

    if example == 4

        selectedRank = 10;

    else

        selectedRank = 1;

    end


    idxSelected = sortedIdx(selectedRank);

    selectedDifference = ...
        sortedDevDifference(selectedRank);


    %% ============================================================
    % Store selected quantities
    % ================================================================

    selectedDataSet(example) = idxSelected;

    selectedLFDev(example) = ...
        dev{1}(idxSelected);

    selectedHFDev(example) = ...
        dev{2}(idxSelected);

    selectedDevDifference(example) = ...
        selectedDifference;


    %% ============================================================
    % Print information to command window
    % ================================================================

    fprintf('\n====================================================\n')
    fprintf('%s\n', applicationNames{example})
    fprintf('====================================================\n')

    if example == 4

        fprintf('Using 10th-largest LF-HF predictive discrepancy\n')

    else

        fprintf('Using largest LF-HF predictive discrepancy\n')

    end

    fprintf('Selected data set: %d\n', idxSelected)

    fprintf('LF predictive error: %.6g\n', ...
        dev{1}(idxSelected))

    fprintf('HF predictive error: %.6g\n', ...
        dev{2}(idxSelected))

    fprintf('LF - HF predictive error: %.6g\n', ...
        selectedDifference)


    %% ============================================================
    % FIGURE 100
    % Predictive errors: LF versus HF
    % ================================================================

    figure(100)

    subplot(1,5,example)

    plot(dev{2}, dev{1}, '.', ...
        'MarkerSize', 12)

    hold on


    %% ------------------------------------------------------------
    % Axis limits
    % ------------------------------------------------------------

    if example == 1

        xlim([0 200])
        ylim([0 200])

    elseif example == 2

        xlim([0 160])
        ylim([0 160])

    elseif example == 3

        xlim([0 160])
        ylim([0 160])

    elseif example == 4

        xlim([0 160])
        ylim([0 160])

    else

        xlim([0 7])
        ylim([0 7])

    end


    %% ------------------------------------------------------------
    % Equality line
    % ------------------------------------------------------------

    xl = xlim;

    plot(xl, xl, '-r', ...
        'LineWidth', 2)



    %% ------------------------------------------------------------
    % Labels
    % ------------------------------------------------------------

    title(applicationNames{example}, ...
        'FontSize', 20, ...
        'FontWeight', 'normal')

    xlabel('HF')

    if example == 1
        ylabel('LF')
    end

    set(gca, 'FontSize', 20)

    box on


    sgtitle('Predictive errors: LF vs HF', ...
        'Color', 'red', ...
        'FontSize', 20)


    %% ============================================================
    % Extract selected outputs
    % ================================================================

    trueOutput = ...
        SimData_thetaStar(idxSelected,:);

    lfOutput = ...
        predictions{1}(idxSelected,:);

    hfOutput = ...
        predictions{2}(idxSelected,:);

    if example == 1
        outputCoordinate = linspace(0.3, 60, 200);
    elseif example == 2 || example == 3
        outputCoordinate = linspace(0, 0.85, 512);
    elseif example == 4
        outputCoordinate = linspace(0, 2*pi, 256);
    else
        outputCoordinate = linspace(-50, 50, 256);
    end

    %% ============================================================
    % SEPARATE OUTPUT-SPACE FIGURE FOR EACH APPLICATION
    % ================================================================

    figure(200 + example)

    set(gcf, 'Color', 'w')
    set(gcf, 'Position', [150 150 900 550])


    %% ------------------------------------------------------------
    % Plot the three outputs
    % ------------------------------------------------------------

    plot( ...
        outputCoordinate, ...
        trueOutput, ...
        'k-', ...
        'LineWidth', 2.5)

    hold on


    plot( ...
        outputCoordinate, ...
        hfOutput, ...
        'g-.', ...
        'LineWidth', 2)


    plot( ...
        outputCoordinate, ...
        lfOutput, ...
        'r--', ...
        'LineWidth', 2)


    %% ------------------------------------------------------------
    % Labels
    % ------------------------------------------------------------

    title(applicationNames{example}, ...
        'FontSize', 20, ...
        'FontWeight', 'normal')

    if example == 1 || example ==2 || example == 3
        xlabel('Time', ...
            'FontSize', 20)
    else
        xlabel('Location', ...
            'FontSize', 20)
    end

    ylabel('Output', ...
        'FontSize', 20)

    legend( ...
        'Simulator', ...
        'HF', ...
        'LF', ...
        'Location', 'best', ...
        'FontSize', 20)

    set(gca, ...
        'FontSize', 20, ...
        'LineWidth', 1)

    box on
    axis tight


    %% ============================================================
    % Save individual output-space figures
    % ================================================================

    outputFilename = sprintf( ...
        'Predictions_LF_HF_vs_Simulator_%s.eps', ...
        strrep(applicationNames{example}, '-', '_'));

    exportgraphics( ...
        gcf, ...
        fullfile(figureDir, outputFilename), ...
        'ContentType', 'vector');


    %% ============================================================
    % Save predictive-error figure after final application
    % ================================================================
    if example == 5

        figure(100)

        exportgraphics( ...
            gcf, ...
            fullfile(figureDir, 'PredictiveErrors_LF_vs_HF.eps'), ...
            'ContentType', 'vector');

    end

end
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Inference plotting of results
clear
clc
close all

%% ================================================================
% Application names
% ================================================================

applicationNames = { ...
    'Environmental', ...
    'Systemic', ...
    'Pulmonary', ...
    'Burgers', ...
    'Gray-Scott', ...
    'Burgers simulator', ...
    'Gray-Scott simulator'};


%% ================================================================
% Storage for inference errors
% ================================================================

hfErrorsAll = cell(1,7);
lfErrorsAll = cell(1,7);

mfBestErrorsAll      = cell(1,7);
mfAverageErrorsAll   = cell(1,7);
mfSwitchingErrorsAll = cell(1,7);


%% ================================================================
% Storage for GF/GB inference errors
% Examples 1--5 only
% ================================================================

hfErrorsGFAll = cell(1,5);
hfErrorsGBAll = cell(1,5);

lfErrorsGFAll = cell(1,5);
lfErrorsGBAll = cell(1,5);


%% ================================================================
% Storage for LF vs HF percentages
% Examples 1--7
%
% For examples 1--5:
% HF and LF are the best available results across GF and GB
%
% For examples 6--7:
% HF and LF are the simulator results
% ================================================================

fractionLFBetterThanHFAll = zeros(1,7);
fractionLFWorseThanHFAll  = zeros(1,7);
fractionLFEqualToHFAll    = zeros(1,7);


%% ================================================================
% Storage for optimizer-specific comparisons
% Examples 1--5
% ================================================================

% LF vs HF using GF for both
fractionLFBetterThanHF_GF_All = zeros(1,5);
fractionLFWorseThanHF_GF_All  = zeros(1,5);

% LF vs HF using GB for both
fractionLFBetterThanHF_GB_All = zeros(1,5);
fractionLFWorseThanHF_GB_All  = zeros(1,5);

% Best MF vs HF obtained with GF
fractionMFBestBetterThanHF_GF_All = zeros(1,5);
fractionMFBestWorseThanHF_GF_All  = zeros(1,5);

% Best MF vs HF obtained with GB
fractionMFBestBetterThanHF_GB_All = zeros(1,5);
fractionMFBestWorseThanHF_GB_All  = zeros(1,5);

% Best MF vs best HF across GF/GB
fractionMFBestBetterThanBestHFAll = zeros(1,5);
fractionMFBestWorseThanBestHFAll  = zeros(1,5);


%% ================================================================
% Loop over all applications
% ================================================================

for example = 1:7

    clearvars -except example applicationNames ...
        hfErrorsAll lfErrorsAll ...
        mfBestErrorsAll mfAverageErrorsAll mfSwitchingErrorsAll ...
        hfErrorsGFAll hfErrorsGBAll ...
        lfErrorsGFAll lfErrorsGBAll ...
        fractionLFBetterThanHFAll ...
        fractionLFWorseThanHFAll ...
        fractionLFEqualToHFAll ...
        fractionLFBetterThanHF_GF_All ...
        fractionLFWorseThanHF_GF_All ...
        fractionLFBetterThanHF_GB_All ...
        fractionLFWorseThanHF_GB_All ...
        fractionMFBestBetterThanHF_GF_All ...
        fractionMFBestWorseThanHF_GF_All ...
        fractionMFBestBetterThanHF_GB_All ...
        fractionMFBestWorseThanHF_GB_All ...
        fractionMFBestBetterThanBestHFAll ...
        fractionMFBestWorseThanBestHFAll


    %% ============================================================
    % Select application directory
    % =============================================================

    % Assuming projectDir has already been defined:
    % scriptDir = fileparts(mfilename('fullpath'));
    % projectDir = scriptDir;

    simulatorDir = fullfile(projectDir, 'SimulatorsMultifidelity');

    switch example
        case 1  % Environmental emulator
            applicationDir = fullfile( ...
                simulatorDir, 'Environmental');

        case 2  % Systemic emulator
            applicationDir = fullfile( ...
                simulatorDir, 'SystemicModel');

        case 3  % Pulmonary emulator
            applicationDir = fullfile( ...
                simulatorDir, 'PulmonaryModel');

        case 4  % Burgers emulator
            applicationDir = fullfile( ...
                simulatorDir, 'StochasticBurgers', 'Emulators');

        case 5  % Gray-Scott emulator
            applicationDir = fullfile( ...
                simulatorDir, 'GrayScott', ...
                'Emulators');

        case 6  % Burgers raw simulator
            applicationDir = fullfile( ...
                simulatorDir, 'StochasticBurgers', 'RawSimulators');

        case 7  % Gray-Scott raw simulator
            applicationDir = fullfile( ...
                simulatorDir, 'GrayScott', 'RawSimulators');

        otherwise
            error(['Invalid example value: %g. ' ...
                'Expected an integer from 1 to 7.'], example);
    end

    if ~isfolder(applicationDir)
        error('Application directory not found:\n%s', applicationDir);
    end

    cd(applicationDir);


    %% ============================================================
    % EXAMPLES 1--3
    % Environmental, systemic and pulmonary
    % ================================================================

    if example <= 3

        %% --------------------------------------------------------
        % MF: average objective function
        % --------------------------------------------------------

        load('InferenceErrors_MFmodified_averageOF.mat')
        mfAverageErrors = ErrorSimSpace;


        %% --------------------------------------------------------
        % MF: switching strategy
        % --------------------------------------------------------

        load('InferenceErrors_MFmodified.mat')
        mfSwitchingErrors = ErrorSimSpace;


        %% --------------------------------------------------------
        % Gradient-free HF/LF errors
        %
        % column 2 = HF
        % column 3 = LF
        % --------------------------------------------------------

        load('InferenceErrors_GradientFree.mat')
        gradientFreeErrors = ErrorSimSpace;

        hfErrorsGF = gradientFreeErrors(:,2);
        lfErrorsGF = gradientFreeErrors(:,3);


        %% --------------------------------------------------------
        % Gradient-based HF/LF errors
        %
        % column 2 = HF
        % column 3 = LF
        % --------------------------------------------------------

        load('InferenceErrors_GradientBased.mat')
        gradientBasedErrors = ErrorSimSpace;

        hfErrorsGB = gradientBasedErrors(:,2);
        lfErrorsGB = gradientBasedErrors(:,3);


        %% --------------------------------------------------------
        % Best available inference error for each fidelity
        %
        % The preferred optimizer is allowed to differ between
        % HF and LF for each data set.
        % --------------------------------------------------------

        hfErrors = min(hfErrorsGF, hfErrorsGB);
        lfErrors = min(lfErrorsGF, lfErrorsGB);


        %% ============================================================
        % EXAMPLES 4--5
        % Burgers and Gray-Scott emulators
        % ================================================================

    elseif example == 4 || example == 5

        %% --------------------------------------------------------
        % MF: average objective function
        % --------------------------------------------------------

        load('InferenceErrors_HFLFemulators_onlyMFdifferent_averageOF.mat')
        mfAverageErrors = ErrorSimSpace(:,1);


        %% --------------------------------------------------------
        % MF: switching strategy
        %
        % This file also contains ErrorSimSpace_GF_GB
        % --------------------------------------------------------

        load('InferenceErrors_HFLFemulators_MFdifferent.mat')
        mfSwitchingErrors = ErrorSimSpace(:,1);


        %% --------------------------------------------------------
        % Individual GF/GB inference errors
        %
        % ErrorSimSpace_GF_GB(:,1) = HF, gradient free
        % ErrorSimSpace_GF_GB(:,2) = HF, gradient based
        % ErrorSimSpace_GF_GB(:,3) = LF, gradient free
        % ErrorSimSpace_GF_GB(:,4) = LF, gradient based
        % --------------------------------------------------------

        hfErrorsGF = ErrorSimSpace_GF_GB(:,1);
        hfErrorsGB = ErrorSimSpace_GF_GB(:,2);

        lfErrorsGF = ErrorSimSpace_GF_GB(:,3);
        lfErrorsGB = ErrorSimSpace_GF_GB(:,4);


        %% --------------------------------------------------------
        % Best available HF and LF inference errors
        %
        % Again, GF/GB is selected independently for HF and LF.
        % --------------------------------------------------------

        hfErrors = min(hfErrorsGF, hfErrorsGB);
        lfErrors = min(lfErrorsGF, lfErrorsGB);


        %% ============================================================
        % EXAMPLES 6--7
        % Burgers and Gray-Scott raw simulators
        % ================================================================

    else

        %% --------------------------------------------------------
        % MF: average objective function
        % --------------------------------------------------------

        load('InferenceErrors_HFLFsimulators_onlyMFdifferent_averageOF.mat')
        mfAverageErrors = ErrorSimSpace;


        %% --------------------------------------------------------
        % MF: switching strategy + HF/LF simulator errors
        % --------------------------------------------------------

        load('InferenceErrors_HFLFsimulators_MFdifferent.mat')

        mfSwitchingErrors = ErrorSimSpace(:,1);

        hfErrors = ErrorSimSpace(:,2);
        lfErrors = ErrorSimSpace(:,3);

    end


    %% ============================================================
    % Ensure all arrays are column vectors
    % ================================================================

    hfErrors          = hfErrors(:);
    lfErrors          = lfErrors(:);
    mfAverageErrors   = mfAverageErrors(:);
    mfSwitchingErrors = mfSwitchingErrors(:);

    if example <= 5

        hfErrorsGF = hfErrorsGF(:);
        hfErrorsGB = hfErrorsGB(:);

        lfErrorsGF = lfErrorsGF(:);
        lfErrorsGB = lfErrorsGB(:);

    end


    %% ============================================================
    % Best MF strategy
    %
    % For each data set, choose the lower inference error between:
    %
    % 1. average-objective-function MF
    % 2. switching MF
    % ================================================================

    mfBestErrors = min(mfAverageErrors, mfSwitchingErrors);


    %% ============================================================
    % LF vs HF
    %
    % For examples 1--5:
    %
    % LF = best LF result across GF and GB
    % HF = best HF result across GF and GB
    %
    % The preferred optimizer may therefore differ between
    % LF and HF.
    % ================================================================

    fractionLFBetterThanHF = ...
        mean(lfErrors < hfErrors);

    fractionLFWorseThanHF = ...
        mean(lfErrors > hfErrors);

    fractionLFEqualToHF = ...
        mean(lfErrors == hfErrors);


    %% ============================================================
    % MF vs HF using best available HF
    % ================================================================

    fractionMFBestBetterThanHF = ...
        mean(mfBestErrors < hfErrors);

    fractionMFBestWorseThanHF = ...
        mean(mfBestErrors > hfErrors);

    fractionMFBestEqualToHF = ...
        mean(mfBestErrors == hfErrors);


    %% ============================================================
    % Average MF vs HF
    % ================================================================

    fractionMFAverageBetterThanHF = ...
        mean(mfAverageErrors < hfErrors);

    fractionMFAverageWorseThanHF = ...
        mean(mfAverageErrors > hfErrors);


    %% ============================================================
    % Switching MF vs HF
    % ================================================================

    fractionMFSwitchingBetterThanHF = ...
        mean(mfSwitchingErrors < hfErrors);

    fractionMFSwitchingWorseThanHF = ...
        mean(mfSwitchingErrors > hfErrors);


    %% ============================================================
    % Optimizer-specific comparisons
    % Examples 1--5 only
    % ================================================================

    if example <= 5

        %% --------------------------------------------------------
        % LF vs HF:
        % Gradient-free optimizer for BOTH fidelities
        % --------------------------------------------------------

        fractionLFBetterThanHF_GF = ...
            mean(lfErrorsGF < hfErrorsGF);

        fractionLFWorseThanHF_GF = ...
            mean(lfErrorsGF > hfErrorsGF);

        fractionLFEqualToHF_GF = ...
            mean(lfErrorsGF == hfErrorsGF);


        %% --------------------------------------------------------
        % LF vs HF:
        % Gradient-based optimizer for BOTH fidelities
        % --------------------------------------------------------

        fractionLFBetterThanHF_GB = ...
            mean(lfErrorsGB < hfErrorsGB);

        fractionLFWorseThanHF_GB = ...
            mean(lfErrorsGB > hfErrorsGB);

        fractionLFEqualToHF_GB = ...
            mean(lfErrorsGB == hfErrorsGB);


        %% --------------------------------------------------------
        % Best MF vs HF obtained using gradient-free optimizer
        % --------------------------------------------------------

        fractionMFBestBetterThanHF_GF = ...
            mean(mfBestErrors < hfErrorsGF);

        fractionMFBestWorseThanHF_GF = ...
            mean(mfBestErrors > hfErrorsGF);


        %% --------------------------------------------------------
        % Best MF vs HF obtained using gradient-based optimizer
        % --------------------------------------------------------

        fractionMFBestBetterThanHF_GB = ...
            mean(mfBestErrors < hfErrorsGB);

        fractionMFBestWorseThanHF_GB = ...
            mean(mfBestErrors > hfErrorsGB);


        %% --------------------------------------------------------
        % Best MF vs best HF across GF/GB
        % --------------------------------------------------------

        fractionMFBestBetterThanBestHF = ...
            mean(mfBestErrors < hfErrors);

        fractionMFBestWorseThanBestHF = ...
            mean(mfBestErrors > hfErrors);

    end


    %% ============================================================
    % Display application-specific results
    % ================================================================

    fprintf('\n')
    fprintf('============================================================\n')
    fprintf('%s\n', applicationNames{example})
    fprintf('============================================================\n')


    %% ------------------------------------------------------------
    % Main LF vs HF comparison
    % ------------------------------------------------------------

    if example <= 5

        fprintf('\nLF vs HF -- best available optimizer for each fidelity:\n')

    else

        fprintf('\nLF vs HF:\n')

    end

    fprintf('  LF better than HF = %5.1f%%\n', ...
        100*fractionLFBetterThanHF)

    fprintf('  LF worse than HF  = %5.1f%%\n', ...
        100*fractionLFWorseThanHF)

    fprintf('  LF equal to HF    = %5.1f%%\n', ...
        100*fractionLFEqualToHF)


    %% ------------------------------------------------------------
    % GF/GB-specific comparisons
    % ------------------------------------------------------------

    if example <= 5

        fprintf('\nLF vs HF -- gradient free for both:\n')

        fprintf('  LF better = %5.1f%%\n', ...
            100*fractionLFBetterThanHF_GF)

        fprintf('  LF worse  = %5.1f%%\n', ...
            100*fractionLFWorseThanHF_GF)

        fprintf('  Equal     = %5.1f%%\n', ...
            100*fractionLFEqualToHF_GF)


        fprintf('\nLF vs HF -- gradient based for both:\n')

        fprintf('  LF better = %5.1f%%\n', ...
            100*fractionLFBetterThanHF_GB)

        fprintf('  LF worse  = %5.1f%%\n', ...
            100*fractionLFWorseThanHF_GB)

        fprintf('  Equal     = %5.1f%%\n', ...
            100*fractionLFEqualToHF_GB)


        fprintf('\nBest MF vs HF -- gradient-free HF:\n')

        fprintf('  MF better = %5.1f%%\n', ...
            100*fractionMFBestBetterThanHF_GF)

        fprintf('  MF worse  = %5.1f%%\n', ...
            100*fractionMFBestWorseThanHF_GF)


        fprintf('\nBest MF vs HF -- gradient-based HF:\n')

        fprintf('  MF better = %5.1f%%\n', ...
            100*fractionMFBestBetterThanHF_GB)

        fprintf('  MF worse  = %5.1f%%\n', ...
            100*fractionMFBestWorseThanHF_GB)


        fprintf('\nBest MF vs best HF across GF/GB:\n')

        fprintf('  MF better = %5.1f%%\n', ...
            100*fractionMFBestBetterThanBestHF)

        fprintf('  MF worse  = %5.1f%%\n', ...
            100*fractionMFBestWorseThanBestHF)

    end


    %% ------------------------------------------------------------
    % MF strategy comparison
    % ------------------------------------------------------------

    fprintf('\nMF vs HF:\n')

    fprintf('  Best MF:      better = %5.1f%%, worse = %5.1f%%, equal = %5.1f%%\n', ...
        100*fractionMFBestBetterThanHF, ...
        100*fractionMFBestWorseThanHF, ...
        100*fractionMFBestEqualToHF)

    fprintf('  Average MF:   better = %5.1f%%, worse = %5.1f%%\n', ...
        100*fractionMFAverageBetterThanHF, ...
        100*fractionMFAverageWorseThanHF)

    fprintf('  Switching MF: better = %5.1f%%, worse = %5.1f%%\n', ...
        100*fractionMFSwitchingBetterThanHF, ...
        100*fractionMFSwitchingWorseThanHF)


    %% ============================================================
    % Store LF vs HF percentages
    % ================================================================

    fractionLFBetterThanHFAll(example) = ...
        fractionLFBetterThanHF;

    fractionLFWorseThanHFAll(example) = ...
        fractionLFWorseThanHF;

    fractionLFEqualToHFAll(example) = ...
        fractionLFEqualToHF;


    %% ============================================================
    % Store GF/GB-specific results
    % ================================================================

    if example <= 5

        fractionLFBetterThanHF_GF_All(example) = ...
            fractionLFBetterThanHF_GF;

        fractionLFWorseThanHF_GF_All(example) = ...
            fractionLFWorseThanHF_GF;


        fractionLFBetterThanHF_GB_All(example) = ...
            fractionLFBetterThanHF_GB;

        fractionLFWorseThanHF_GB_All(example) = ...
            fractionLFWorseThanHF_GB;


        fractionMFBestBetterThanHF_GF_All(example) = ...
            fractionMFBestBetterThanHF_GF;

        fractionMFBestWorseThanHF_GF_All(example) = ...
            fractionMFBestWorseThanHF_GF;


        fractionMFBestBetterThanHF_GB_All(example) = ...
            fractionMFBestBetterThanHF_GB;

        fractionMFBestWorseThanHF_GB_All(example) = ...
            fractionMFBestWorseThanHF_GB;


        fractionMFBestBetterThanBestHFAll(example) = ...
            fractionMFBestBetterThanBestHF;

        fractionMFBestWorseThanBestHFAll(example) = ...
            fractionMFBestWorseThanBestHF;


        %% Store individual optimizer errors

        hfErrorsGFAll{example} = hfErrorsGF;
        hfErrorsGBAll{example} = hfErrorsGB;

        lfErrorsGFAll{example} = lfErrorsGF;
        lfErrorsGBAll{example} = lfErrorsGB;

    end


    %% ============================================================
    % Store inference errors for plotting
    % ================================================================

    hfErrorsAll{example} = hfErrors;
    lfErrorsAll{example} = lfErrors;

    mfBestErrorsAll{example} = mfBestErrors;

    mfAverageErrorsAll{example} = ...
        mfAverageErrors;

    mfSwitchingErrorsAll{example} = ...
        mfSwitchingErrors;

end


%% =================================================================
% SUMMARY 1
% LF vs HF for all seven applications
% =================================================================

fprintf('\n\n')
fprintf('==========================================================================\n')
fprintf('SUMMARY: LF versus HF inference accuracy\n')
fprintf('==========================================================================\n')

fprintf('%-22s %12s %12s %12s\n', ...
    'Application', ...
    'LF better', ...
    'LF worse', ...
    'Equal')

fprintf('%s\n', repmat('-',1,62))

for example = 1:7

    fprintf('%-22s %11.1f%% %11.1f%% %11.1f%%\n', ...
        applicationNames{example}, ...
        100*fractionLFBetterThanHFAll(example), ...
        100*fractionLFWorseThanHFAll(example), ...
        100*fractionLFEqualToHFAll(example))

end


%% =================================================================
% SUMMARY 2
% Examples 1--5:
% LF vs HF using GF, GB, and best available optimizer
% =================================================================

fprintf('\n\n')
fprintf('============================================================================================\n')
fprintf('LF vs HF: optimizer-specific and best-optimizer comparisons\n')
fprintf('============================================================================================\n')

fprintf('%-15s %13s %13s %17s\n', ...
    'Application', ...
    'LF<HF GF', ...
    'LF<HF GB', ...
    'LF<HF best')

fprintf('%s\n', repmat('-',1,65))

for example = 1:5

    fprintf('%-15s %12.1f%% %12.1f%% %16.1f%%\n', ...
        applicationNames{example}, ...
        100*fractionLFBetterThanHF_GF_All(example), ...
        100*fractionLFBetterThanHF_GB_All(example), ...
        100*fractionLFBetterThanHFAll(example))

end


%% =================================================================
% SUMMARY 3
% Examples 1--5:
% Best MF vs HF
% =================================================================

fprintf('\n\n')
fprintf('============================================================================================\n')
fprintf('Best MF versus HF inference accuracy\n')
fprintf('============================================================================================\n')

fprintf('%-15s %13s %13s %17s\n', ...
    'Application', ...
    'MF<HF GF', ...
    'MF<HF GB', ...
    'MF<HF best')

fprintf('%s\n', repmat('-',1,65))

for example = 1:5

    fprintf('%-15s %12.1f%% %12.1f%% %16.1f%%\n', ...
        applicationNames{example}, ...
        100*fractionMFBestBetterThanHF_GF_All(example), ...
        100*fractionMFBestBetterThanHF_GB_All(example), ...
        100*fractionMFBestBetterThanBestHFAll(example))

end


%% =================================================================
% FIGURE 1
% Inference errors: LF versus HF
% Examples 1--5
%
% x = best HF error across GF/GB
% y = best LF error across GF/GB
%
% Below equality line -> LF better
% Above equality line -> HF better
% =================================================================

figure('Color','w');

tiledlayout(1,5, ...
    'TileSpacing','compact', ...
    'Padding','compact');

% Axis limits in application order:
% Environmental, Systemic, Pulmonary, Burgers, Gray-Scott
axisLimits_LF_HF = [15, 15, 2.5, 1, 0.2];

for example = 1:5

    nexttile

    x = hfErrorsAll{example};
    y = lfErrorsAll{example};

    scatter(x, y, 20, 'filled');
    hold on

    lim = axisLimits_LF_HF(example);

    % Equality line over displayed range
    plot([0 lim], [0 lim], ...
        'r-', 'LineWidth', 2);

    xlim([0 lim])
    ylim([0 lim])

    title(applicationNames{example}, ...
        'FontWeight','normal', ...
        'FontSize',20)

    xlabel('HF', ...
        'FontSize',20)

    if example == 1
        ylabel('LF', ...
            'FontSize',20)
    end

    set(gca, ...
        'FontSize',20)

    box on

end

sgtitle('Inference errors: LF vs HF', ...
    'Color','r', ...
    'FontWeight','normal', ...
    'FontSize',20)


%% =================================================================
% FIGURE 2
% Inference errors: HF versus best MF
% Examples 1--5
%
% x = best MF error
% y = best HF error across GF/GB
%
% Above equality line -> MF better
% Below equality line -> HF better
% =================================================================

figure('Color','w');

tiledlayout(1,5, ...
    'TileSpacing','compact', ...
    'Padding','compact');

% Axis limits in application order:
% Environmental, Systemic, Pulmonary, Burgers, Gray-Scott
axisLimits_HF_MF = [10, 10, 2, 1.65, 0.21];

for example = 1:5

    nexttile

    x = mfBestErrorsAll{example};
    y = hfErrorsAll{example};

    scatter(x, y, 20, 'filled');
    hold on

    lim = axisLimits_HF_MF(example);

    % Equality line over displayed range
    plot([0 lim], [0 lim], ...
        'r-', 'LineWidth', 2);

    xlim([0 lim])
    ylim([0 lim])

    title(applicationNames{example}, ...
        'FontWeight','normal', ...
        'FontSize',20)

    xlabel('MF', ...
        'FontSize',20)

    if example == 1
        ylabel('HF', ...
            'FontSize',20)
    end

    set(gca, ...
        'FontSize',20)

    box on

end

sgtitle('Inference errors: HF vs MF', ...
    'Color','r', ...
    'FontWeight','normal', ...
    'FontSize',20)


%% =================================================================
% FIGURE 3
% Inference errors: LF versus best MF
% Examples 1--5
%
% x = best MF
% y = best LF across GF/GB
%
% Above equality line -> MF better
% Below equality line -> LF better
% =================================================================

figure('Color','w');

tiledlayout(1,5, ...
    'TileSpacing','compact', ...
    'Padding','compact');

% Axis limits in application order:
% Environmental, Systemic, Pulmonary, Burgers, Gray-Scott
axisLimits_LF_MF = [10, 20, 3.5, 10, 0.3];

for example = 1:5

    nexttile

    x = mfBestErrorsAll{example};
    y = lfErrorsAll{example};

    scatter(x, y, 20, 'filled');
    hold on

    lim = axisLimits_LF_MF(example);

    % Equality line over displayed range
    plot([0 lim], [0 lim], ...
        'r-', 'LineWidth', 2);

    xlim([0 lim])
    ylim([0 lim])

    title(applicationNames{example}, ...
        'FontWeight','normal', ...
        'FontSize',20)

    xlabel('MF', ...
        'FontSize',20)

    if example == 1
        ylabel('LF', ...
            'FontSize',20)
    end

    set(gca, ...
        'FontSize',20)

    box on

end

sgtitle('Inference errors: LF vs MF', ...
    'Color','r', ...
    'FontWeight','normal', ...
    'FontSize',20)


%% =================================================================
% FIGURE 4
% Inference errors: LF versus HF
% Raw simulators, examples 6--7
% =================================================================

figure('Color','w');

tiledlayout(1,2, ...
    'TileSpacing','compact', ...
    'Padding','compact');

for example = 6:7

    nexttile

    x = hfErrorsAll{example};
    y = lfErrorsAll{example};

    scatter(x, y, 20, 'filled');
    hold on

    maxVal = max([x; y]);

    if maxVal > 0
        maxVal = 1.05 * maxVal;
    else
        maxVal = 1;
    end

    plot([0 maxVal], [0 maxVal], ...
        'r-', 'LineWidth', 2);

    xlim([0 maxVal])
    ylim([0 maxVal])

    title(applicationNames{example}, ...
        'FontWeight','normal', ...
        'FontSize',20)

    xlabel('HF', ...
        'FontSize',20)

    if example == 6
        ylabel('LF', ...
            'FontSize',20)
    end

    set(gca, ...
        'FontSize',20)

    box on

end

sgtitle('Inference errors: LF vs HF -- simulators', ...
    'Color','r', ...
    'FontWeight','normal', ...
    'FontSize',20)


%% =================================================================
% FIGURE 5
% Switching MF versus average MF
% Examples 1--5
%
% x = Average MF
% y = Switching MF
%
% Below equality line -> Switching MF better
% Above equality line -> Average MF better
% =================================================================

figure('Color','w');

tiledlayout(1,5, ...
    'TileSpacing','compact', ...
    'Padding','compact');

% Axis limits:
% Environmental, Systemic, Pulmonary, Burgers, Gray-Scott
axisLimits_Switch_Average = [2.5, 7, 2, 1, 0.16];

for example = 1:5

    nexttile

    x = mfAverageErrorsAll{example};
    y = mfSwitchingErrorsAll{example};

    scatter(x, y, 20, 'filled');
    hold on

    lim = axisLimits_Switch_Average(example);

    % Equality line over displayed range
    plot([0 lim], [0 lim], ...
        'r-', 'LineWidth', 2);

    xlim([0 lim])
    ylim([0 lim])

    title(applicationNames{example}, ...
        'FontWeight','normal', ...
        'FontSize',20)

    xlabel('Average MF', ...
        'FontSize',20)

    if example == 1
        ylabel('Switching MF', ...
            'FontSize',20)
    end

    set(gca, ...
        'FontSize',20)

    box on

end

sgtitle('Inference errors: Switching MF vs Average MF', ...
    'Color','r', ...
    'FontWeight','normal', ...
    'FontSize',20)
%
%
%
%% ================================================================
% Conditional median inference errors and contrast scores
%
% Comparisons:
%
%   1. LF versus HF
%   2. Best MF versus HF
%
% Examples 1--5:
%   Environmental
%   Systemic
%   Pulmonary
%   Burgers
%   Gray-Scott
%
% For HF and LF, the best inference result across the
% gradient-free (GF) and gradient-based (GB) optimizers is used
% independently for each fidelity and each data set.
%
% Best MF = minimum error between:
%   - switching MF
%   - average-objective-function MF
% ================================================================

clear
clc


%% ================================================================
% Application names
% ================================================================

applicationNames = { ...
    'Environmental', ...
    'Systemic', ...
    'Pulmonary', ...
    'Burgers', ...
    'Gray-Scott'};


%% ================================================================
% Storage: LF versus HF
% ================================================================

% ------------------------------------------------
% Cases where HF is poorer:
%
% LF error < HF error
% ------------------------------------------------

medianHF_whenHFpoorer_LFHF = NaN(1,5);
medianLF_whenHFpoorer_LFHF = NaN(1,5);

contrastHFoverLF_whenHFpoorer = NaN(1,5);

numberHFpoorer_LFHF = zeros(1,5);


% ------------------------------------------------
% Cases where LF is poorer:
%
% LF error > HF error
% ------------------------------------------------

medianLF_whenLFpoorer_LFHF = NaN(1,5);
medianHF_whenLFpoorer_LFHF = NaN(1,5);

contrastLFoverHF_whenLFpoorer = NaN(1,5);

numberLFpoorer_LFHF = zeros(1,5);


%% ================================================================
% Storage: Best MF versus HF
% ================================================================

% ------------------------------------------------
% Cases where HF is poorer:
%
% MF error < HF error
% ------------------------------------------------

medianHF_whenHFpoorer_MFHF = NaN(1,5);
medianMF_whenHFpoorer_MFHF = NaN(1,5);

contrastHFoverMF_whenHFpoorer = NaN(1,5);

numberHFpoorer_MFHF = zeros(1,5);


% ------------------------------------------------
% Cases where MF is poorer:
%
% MF error > HF error
% ------------------------------------------------

medianMF_whenMFpoorer_MFHF = NaN(1,5);
medianHF_whenMFpoorer_MFHF = NaN(1,5);

contrastMFoverHF_whenMFpoorer = NaN(1,5);

numberMFpoorer_MFHF = zeros(1,5);


%% ================================================================
% Store the errors as well, if needed for further analysis
% ================================================================

hfErrorsAll = cell(1,5);
lfErrorsAll = cell(1,5);

mfAverageErrorsAll   = cell(1,5);
mfSwitchingErrorsAll = cell(1,5);
mfBestErrorsAll      = cell(1,5);


%% ================================================================
% Loop over five emulator applications
% ================================================================

for example = 1:5

    clearvars -except example applicationNames ...
        medianHF_whenHFpoorer_LFHF ...
        medianLF_whenHFpoorer_LFHF ...
        contrastHFoverLF_whenHFpoorer ...
        numberHFpoorer_LFHF ...
        medianLF_whenLFpoorer_LFHF ...
        medianHF_whenLFpoorer_LFHF ...
        contrastLFoverHF_whenLFpoorer ...
        numberLFpoorer_LFHF ...
        medianHF_whenHFpoorer_MFHF ...
        medianMF_whenHFpoorer_MFHF ...
        contrastHFoverMF_whenHFpoorer ...
        numberHFpoorer_MFHF ...
        medianMF_whenMFpoorer_MFHF ...
        medianHF_whenMFpoorer_MFHF ...
        contrastMFoverHF_whenMFpoorer ...
        numberMFpoorer_MFHF ...
        hfErrorsAll lfErrorsAll ...
        mfAverageErrorsAll ...
        mfSwitchingErrorsAll ...
        mfBestErrorsAll


    %% Determine project directory
    scriptDir = fileparts(mfilename('fullpath'));
    projectDir = scriptDir;  % Use fileparts(scriptDir) if inside Scripts/

    %% Application directory
    simulatorDir = fullfile(projectDir, 'SimulatorsMultifidelity');

    relativeApplicationDirs = {
        'Environmental'
        'SystemicModel'
        'PulmonaryModel'
        fullfile('StochasticBurgers', 'Emulators')
        fullfile('GrayScott', 'Emulators')
        };

    if ~isscalar(example) || ~isnumeric(example) || ...
            example ~= fix(example) || ...
            example < 1 || example > numel(relativeApplicationDirs)
        error('Invalid example value. Expected an integer from 1 to 5.');
    end

    applicationDir = fullfile( ...
        simulatorDir, relativeApplicationDirs{example});

    if ~isfolder(applicationDir)
        error('Application directory not found:\n%s', applicationDir);
    end

    cd(applicationDir);

    %% ============================================================
    % EXAMPLES 1--3
    % Environmental, systemic and pulmonary
    % ================================================================

    if example <= 3

        %% --------------------------------------------------------
        % MF: average objective function
        % --------------------------------------------------------

        load('InferenceErrors_MFmodified_averageOF.mat')

        mfAverageErrors = ErrorSimSpace;


        %% --------------------------------------------------------
        % MF: switching
        % --------------------------------------------------------

        load('InferenceErrors_MFmodified.mat')

        mfSwitchingErrors = ErrorSimSpace;


        %% --------------------------------------------------------
        % Gradient-free HF and LF inference errors
        %
        % column 2 = HF
        % column 3 = LF
        % --------------------------------------------------------

        load('InferenceErrors_GradientFree.mat')

        hfErrorsGF = ErrorSimSpace(:,2);
        lfErrorsGF = ErrorSimSpace(:,3);


        %% --------------------------------------------------------
        % Gradient-based HF and LF inference errors
        %
        % column 2 = HF
        % column 3 = LF
        % --------------------------------------------------------

        load('InferenceErrors_GradientBased.mat')

        hfErrorsGB = ErrorSimSpace(:,2);
        lfErrorsGB = ErrorSimSpace(:,3);


        %% --------------------------------------------------------
        % Best available error for HF and LF
        %
        % Optimizer can differ between fidelities and data sets
        % --------------------------------------------------------

        hfErrors = min(hfErrorsGF, hfErrorsGB);

        lfErrors = min(lfErrorsGF, lfErrorsGB);


        %% ============================================================
        % EXAMPLES 4--5
        % Burgers and Gray-Scott
        % ================================================================

    else

        %% --------------------------------------------------------
        % MF: average objective function
        % --------------------------------------------------------

        load('InferenceErrors_HFLFemulators_onlyMFdifferent_averageOF.mat')

        mfAverageErrors = ErrorSimSpace(:,1);


        %% --------------------------------------------------------
        % MF: switching
        %
        % ErrorSimSpace_GF_GB is also stored in this file.
        % --------------------------------------------------------

        load('InferenceErrors_HFLFemulators_MFdifferent.mat')

        mfSwitchingErrors = ErrorSimSpace(:,1);


        %% --------------------------------------------------------
        % Individual optimizer errors
        %
        % column 1 = HF gradient-free
        % column 2 = HF gradient-based
        % column 3 = LF gradient-free
        % column 4 = LF gradient-based
        % --------------------------------------------------------

        hfErrorsGF = ErrorSimSpace_GF_GB(:,1);
        hfErrorsGB = ErrorSimSpace_GF_GB(:,2);

        lfErrorsGF = ErrorSimSpace_GF_GB(:,3);
        lfErrorsGB = ErrorSimSpace_GF_GB(:,4);


        %% --------------------------------------------------------
        % Best available HF and LF inference errors
        %
        % GF/GB selected independently
        % --------------------------------------------------------

        hfErrors = min(hfErrorsGF, hfErrorsGB);

        lfErrors = min(lfErrorsGF, lfErrorsGB);

    end


    %% ============================================================
    % Convert everything to column vectors
    % ================================================================

    hfErrors = hfErrors(:);
    lfErrors = lfErrors(:);

    mfAverageErrors = mfAverageErrors(:);
    mfSwitchingErrors = mfSwitchingErrors(:);


    %% ============================================================
    % Best MF strategy
    %
    % Best MF = best result between average and switching
    % for each individual data set.
    % ================================================================

    mfBestErrors = ...
        min(mfAverageErrors, mfSwitchingErrors);


    %% ============================================================
    % Store errors
    % ================================================================

    hfErrorsAll{example} = hfErrors;
    lfErrorsAll{example} = lfErrors;

    mfAverageErrorsAll{example} = mfAverageErrors;
    mfSwitchingErrorsAll{example} = mfSwitchingErrors;
    mfBestErrorsAll{example} = mfBestErrors;


    %% ============================================================
    %
    % PART 1
    %
    % LF versus HF
    %
    % ================================================================


    %% ------------------------------------------------------------
    % CASE A:
    %
    % HF is poorer in the inverse sense
    %
    % LF error < HF error
    % ------------------------------------------------------------

    idxHFpoorer = ...
        lfErrors < hfErrors;


    numberHFpoorer_LFHF(example) = ...
        sum(idxHFpoorer);


    if any(idxHFpoorer)

        medianHF_whenHFpoorer_LFHF(example) = ...
            median( ...
            hfErrors(idxHFpoorer), ...
            'omitnan');


        medianLF_whenHFpoorer_LFHF(example) = ...
            median( ...
            lfErrors(idxHFpoorer), ...
            'omitnan');


        % Contrast:
        %
        % How many times as large is the HF median error
        % compared with the LF median error?
        contrastHFoverLF_whenHFpoorer(example) = ...
            medianHF_whenHFpoorer_LFHF(example) / ...
            medianLF_whenHFpoorer_LFHF(example);

    end


    %% ------------------------------------------------------------
    % CASE B:
    %
    % LF is poorer in the inverse sense
    %
    % LF error > HF error
    % ------------------------------------------------------------

    idxLFpoorer = ...
        lfErrors > hfErrors;


    numberLFpoorer_LFHF(example) = ...
        sum(idxLFpoorer);


    if any(idxLFpoorer)

        medianLF_whenLFpoorer_LFHF(example) = ...
            median( ...
            lfErrors(idxLFpoorer), ...
            'omitnan');


        medianHF_whenLFpoorer_LFHF(example) = ...
            median( ...
            hfErrors(idxLFpoorer), ...
            'omitnan');


        % Contrast:
        %
        % How many times as large is the LF median error
        % compared with the HF median error?
        contrastLFoverHF_whenLFpoorer(example) = ...
            medianLF_whenLFpoorer_LFHF(example) / ...
            medianHF_whenLFpoorer_LFHF(example);

    end


    %% ============================================================
    %
    % PART 2
    %
    % Best MF versus HF
    %
    % ================================================================


    %% ------------------------------------------------------------
    % CASE A:
    %
    % HF is poorer
    %
    % MF error < HF error
    % ------------------------------------------------------------

    idxHFpoorerMF = ...
        mfBestErrors < hfErrors;


    numberHFpoorer_MFHF(example) = ...
        sum(idxHFpoorerMF);


    if any(idxHFpoorerMF)

        medianHF_whenHFpoorer_MFHF(example) = ...
            median( ...
            hfErrors(idxHFpoorerMF), ...
            'omitnan');


        medianMF_whenHFpoorer_MFHF(example) = ...
            median( ...
            mfBestErrors(idxHFpoorerMF), ...
            'omitnan');


        % Contrast:
        %
        % How many times as large is HF median error
        % compared with MF median error?
        contrastHFoverMF_whenHFpoorer(example) = ...
            medianHF_whenHFpoorer_MFHF(example) / ...
            medianMF_whenHFpoorer_MFHF(example);

    end


    %% ------------------------------------------------------------
    % CASE B:
    %
    % MF is poorer
    %
    % MF error > HF error
    % ------------------------------------------------------------

    idxMFpoorer = ...
        mfBestErrors > hfErrors;


    numberMFpoorer_MFHF(example) = ...
        sum(idxMFpoorer);


    if any(idxMFpoorer)

        medianMF_whenMFpoorer_MFHF(example) = ...
            median( ...
            mfBestErrors(idxMFpoorer), ...
            'omitnan');


        medianHF_whenMFpoorer_MFHF(example) = ...
            median( ...
            hfErrors(idxMFpoorer), ...
            'omitnan');


        % Contrast:
        %
        % How many times as large is MF median error
        % compared with HF median error?
        contrastMFoverHF_whenMFpoorer(example) = ...
            medianMF_whenMFpoorer_MFHF(example) / ...
            medianHF_whenMFpoorer_MFHF(example);

    end


end


%% =================================================================
%
% TABLE 1:
% LF versus HF
%
% =================================================================

fprintf('\n\n')
fprintf('=============================================================================================\n')
fprintf('LF VERSUS HF: CONDITIONAL MEDIAN INFERENCE ERRORS\n')
fprintf('=============================================================================================\n')

fprintf(['%-15s | ' ...
    '%10s %12s %12s %10s | ' ...
    '%10s %12s %12s %10s\n'], ...
    'Application', ...
    'N', ...
    'HF median', ...
    'LF median', ...
    'HF/LF', ...
    'N', ...
    'LF median', ...
    'HF median', ...
    'LF/HF')


fprintf(['%-15s | ' ...
    '%10s %12s %12s %10s | ' ...
    '%10s %12s %12s %10s\n'], ...
    '', ...
    'HF poorer', ...
    'HF poorer', ...
    'HF poorer', ...
    'contrast', ...
    'LF poorer', ...
    'LF poorer', ...
    'LF poorer', ...
    'contrast')


fprintf('%s\n', repmat('-',1,120))


for example = 1:5

    fprintf(['%-15s | ' ...
        '%10d %12.4g %12.4g %10.3f | ' ...
        '%10d %12.4g %12.4g %10.3f\n'], ...
        applicationNames{example}, ...
        numberHFpoorer_LFHF(example), ...
        medianHF_whenHFpoorer_LFHF(example), ...
        medianLF_whenHFpoorer_LFHF(example), ...
        contrastHFoverLF_whenHFpoorer(example), ...
        numberLFpoorer_LFHF(example), ...
        medianLF_whenLFpoorer_LFHF(example), ...
        medianHF_whenLFpoorer_LFHF(example), ...
        contrastLFoverHF_whenLFpoorer(example))

end


%% =================================================================
%
% TABLE 2:
% Best MF versus HF
%
% =================================================================

fprintf('\n\n')
fprintf('=============================================================================================\n')
fprintf('BEST MF VERSUS HF: CONDITIONAL MEDIAN INFERENCE ERRORS\n')
fprintf('=============================================================================================\n')


fprintf(['%-15s | ' ...
    '%10s %12s %12s %10s | ' ...
    '%10s %12s %12s %10s\n'], ...
    'Application', ...
    'N', ...
    'HF median', ...
    'MF median', ...
    'HF/MF', ...
    'N', ...
    'MF median', ...
    'HF median', ...
    'MF/HF')


fprintf(['%-15s | ' ...
    '%10s %12s %12s %10s | ' ...
    '%10s %12s %12s %10s\n'], ...
    '', ...
    'HF poorer', ...
    'HF poorer', ...
    'HF poorer', ...
    'contrast', ...
    'MF poorer', ...
    'MF poorer', ...
    'MF poorer', ...
    'contrast')


fprintf('%s\n', repmat('-',1,120))


for example = 1:5

    fprintf(['%-15s | ' ...
        '%10d %12.4g %12.4g %10.3f | ' ...
        '%10d %12.4g %12.4g %10.3f\n'], ...
        applicationNames{example}, ...
        numberHFpoorer_MFHF(example), ...
        medianHF_whenHFpoorer_MFHF(example), ...
        medianMF_whenHFpoorer_MFHF(example), ...
        contrastHFoverMF_whenHFpoorer(example), ...
        numberMFpoorer_MFHF(example), ...
        medianMF_whenMFpoorer_MFHF(example), ...
        medianHF_whenMFpoorer_MFHF(example), ...
        contrastMFoverHF_whenMFpoorer(example))

end


%% =================================================================
%
% Contrast-score ranges for manuscript
%
% =================================================================


%% -----------------------------------------------------------------
% LF versus HF:
%
% HF poorer
%
% HF median / LF median
% -----------------------------------------------------------------

x = min( ...
    contrastHFoverLF_whenHFpoorer, ...
    [], ...
    'omitnan');

y = max( ...
    contrastHFoverLF_whenHFpoorer, ...
    [], ...
    'omitnan');


%% -----------------------------------------------------------------
% LF versus HF:
%
% LF poorer
%
% LF median / HF median
% -----------------------------------------------------------------

a = min( ...
    contrastLFoverHF_whenLFpoorer, ...
    [], ...
    'omitnan');

b = max( ...
    contrastLFoverHF_whenLFpoorer, ...
    [], ...
    'omitnan');


%% -----------------------------------------------------------------
% Best MF versus HF:
%
% HF poorer
%
% HF median / MF median
% -----------------------------------------------------------------

z = max( ...
    contrastHFoverMF_whenHFpoorer, ...
    [], ...
    'omitnan');


%% -----------------------------------------------------------------
% Best MF versus HF:
%
% MF poorer
%
% MF median / HF median
% -----------------------------------------------------------------

w = max( ...
    contrastMFoverHF_whenMFpoorer, ...
    [], ...
    'omitnan');


%% =================================================================
% Print manuscript-ready summary
% =================================================================

fprintf('\n\n')
fprintf('====================================================================\n')
fprintf('CONTRAST-SCORE SUMMARY FOR MANUSCRIPT\n')
fprintf('====================================================================\n')


fprintf('\nLF versus HF:\n')

fprintf( ...
    ['  When HF is poorer, its median inference error is ' ...
    'between %.2f and %.2f times as large as the LF median error.\n'], ...
    x, y)


fprintf( ...
    ['  When LF is poorer, its median inference error is ' ...
    'between %.2f and %.2f times as large as the HF median error.\n'], ...
    a, b)


fprintf('\nBest MF versus HF:\n')

fprintf( ...
    ['  When HF is poorer, its median inference error is ' ...
    'up to %.2f times as large as the MF median error.\n'], ...
    z)


fprintf( ...
    ['  When MF is poorer, its median inference error is ' ...
    'up to %.2f times as large as the HF median error.\n'], ...
    w)
%
%
%
%